%% TopologyTracer2D3D
% PRX2D_BKvsLocalProperties_01
% Author: m.kuehbach (at) mpie.de, 09/08/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize evolution of successful grains size in instantaneous 
% evolution of size to matrix exclusive survivors
% as a function of time in relation current HAGB, nfaces, SEE

clear;
clc;
format long;
digits(32);

prefix_ngrains = 'E:\LongRangePaperFINAL\AGG2D\1Coarsening\';
prefix_tri = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\UnbiasedGrowthMeasures\TopoTracer2D3D.SimID.10509500.LR2D.FID.';
prefix_tri = 'E:\LongRangePaperFINAL\PRX2D\2DataAnalysis\UnbiasedGrowthMeasures\TopoTracer2D3D.SimID.1005200.LR2D.FID.';
first = 100;
offset = 100;
last = 5200;

%% load triangle data
NTRI = 0;
for fid=first:offset:last
    filename = [prefix_tri num2str(fid) '.RCLASS.0.csv'];
    delimiter = ';';
    endRow = 11;
    formatSpec = '%s%s%[^\n\r]';
    fileID = fopen(filename,'r');
    if fileID ~= -1
        dataArray = textscan(fileID, formatSpec, endRow, 'Delimiter', delimiter, 'TextType', 'string', 'ReturnOnError', false, 'EndOfLine', '\r\n');
        fclose(fileID);
        raw = repmat({''},length(dataArray{1}),length(dataArray)-1);
        for col=1:length(dataArray)-1
            raw(1:length(dataArray{col}),col) = mat2cell(dataArray{col}, ones(length(dataArray{col}), 1));
        end
        numericData = NaN(size(dataArray{1},1),size(dataArray,2));
        for col=[1,2]
            % Converts text in the input cell array to numbers. Replaced non-numeric
            % text with NaN.
            rawData = dataArray{col};
            for row=1:size(rawData, 1)
                % Create a regular expression to detect and remove non-numeric prefixes and
                % suffixes.
                regexstr = '(?<prefix>.*?)(?<numbers>([-]*(\d+[\,]*)+[\.]{0,1}\d*[eEdD]{0,1}[-+]*\d*[i]{0,1})|([-]*(\d+[\,]*)*[\.]{1,1}\d+[eEdD]{0,1}[-+]*\d*[i]{0,1}))(?<suffix>.*)';
                try
                    result = regexp(rawData(row), regexstr, 'names');
                    numbers = result.numbers;

                    % Detected commas in non-thousand locations.
                    invalidThousandsSeparator = false;
                    if numbers.contains(',')
                        thousandsRegExp = '^\d+?(\,\d{3})*\.{0,1}\d*$';
                        if isempty(regexp(numbers, thousandsRegExp, 'once'))
                            numbers = NaN;
                            invalidThousandsSeparator = true;
                        end
                    end
                    % Convert numeric text to numbers.
                    if ~invalidThousandsSeparator
                        numbers = textscan(char(strrep(numbers, ',', '')), '%f');
                        numericData(row, col) = numbers{1};
                        raw{row, col} = numbers{1};
                    end
                catch
                    raw{row, col} = rawData{row};
                end
            end
        end
        R = cellfun(@(x) ~isnumeric(x) && ~islogical(x),raw); % Find non-numeric cells
        raw(R) = {NaN}; % Replace non-numeric cells
        TMP = table;
        TMP.Grain = cell2mat(raw(:, 1));
        TMP.x = cell2mat(raw(:, 2));

        NTRI = NTRI + TMP.x(11);
    end
    clearvars filename delimiter endRow formatSpec fileID dataArray ans raw col numericData rawData row regexstr result numbers invalidThousandsSeparator thousandsRegExp R;
end

%% load realtime
filename = [prefix_ngrains 'NrGrains&EnergyStatistics.txt'];
delimiter = '\t';
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN, 'ReturnOnError', false);
fclose(fileID);
TMP = [dataArray{1:end-1}];
clearvars filename delimiter formatSpec fileID dataArray ans;

%% count how many grains to process in collection of snapshots
NGR = 0;
for fid=first:offset:last
    NGR = NGR + TMP(fid,2);
end


%% set up ID vector as a tool to allowing plotting
ID = zeros(nrows,ncols);
for t=1:ncols
    ID(:,t) = TMP(first+(t-1)*offset,1);
end
'Real time loaded'

save('PRX2D_BKLocalPropertiesEvoAndCurv_01.mat');
load('PRX2D_BKLocalPropertiesEvoAndCurv_01.mat');

%%


fontsz = 22;
fontnm = 'Calibri Light';
cut = 1925; %at which matrix population is last 1000 grains
Vm = mean(VOLUME(:,cut));
Vmax = max(VOLUME(:,cut));

PLOTORDER = zeros(nrows,2);
PLOTORDER(:,1) = SIZEGAINBK(:,cut); %SizeGain vs Matrix
PLOTORDER(:,2) = 1:1:nrows; %LineID
PLOTORDER = sortrows(PLOTORDER,1);

% data inconsistence NFACES(:,240) = nan;
NFACES(:,240) = nan;

alpha = 0.2;
figure('Position',[100 100 1200 1000]);
hold('on');
xlabel({'m\cdot0.5Gb^2\cdot\Delta\rho (\mum/s)'},'FontSize',fontsz,'FontName',fontnm)
ylabel({'N_{faces}'},'FontSize',fontsz,'FontName',fontnm)
if Dimension == 2
zlabel({'A / A^{matr}_m'},'FontSize',fontsz,'FontName',fontnm)
end
if Dimension == 3
zlabel({'V / V^{matr}_m'},'FontSize',fontsz,'FontName',fontnm)
end
grid('on')
box('on')
view(53,22)

%sorted list of grain size gains, -50 / +50 about 25% quantile of final sizes
color = parula;
ncolor = 64;
colorbar;
%h = colorbar; %set( h, 'YDir', 'reverse' );
ntotal = 5750;
quant=0.25;
for g=int32((ntotal*quant)-50):1:int32((ntotal*quant)+50) %hardcoded because grains which died prior 10
    id = PLOTORDER(g,2);
    gp = plot3(MOBDSEE(id,1:cut),NFACES(id,1:cut),SIZEGAINBK(id,1:cut),'LineWidth',3,'Color',color(1+(1-0.25)*64,:)); %[0 0 1]); %alpha]);
    gp.Color(4) = alpha;
%    gp = plot3(MOBDSEE(id,1),NFACES(id,1),SIZEGAINBK(id,1),'.','MarkerSize',20,'Color',color(1+(1-0.25)*64,:)); %[0 0 1]); %alpha]);
%    %gp.Color(4) = alpha;  
end
% quant=0.5;
% for g=int32((ntotal*quant)-50):1:int32((ntotal*quant)+50)
%     id = PLOTORDER(g,2);
%     gp = plot3(MOBDSEE(id,1:cut),NFACES(id,1:cut),SIZEGAINBK(id,1:cut),'LineWidth',3,'Color',color(1+(1-0.50)*64,:)); %[0 0 1]); %alpha]);
%     gp.Color(4) = alpha;
% %    gp = plot3(MOBDSEE(id,1),NFACES(id,1),SIZEGAINBK(id,1),'.','MarkerSize',20,'Color',color(1+(1-0.50)*64,:)); %[0 0 1]); %alpha]);
% %    %gp.Color(4) = alpha;
% end
% quant=0.75;
% for g=int32((ntotal*quant)-50):1:int32((ntotal*quant)+50)
%     id = PLOTORDER(g,2);
%     gp = plot3(MOBDSEE(id,1:cut),NFACES(id,1:cut),SIZEGAINBK(id,1:cut),'LineWidth',3,'Color',color(1+(1-0.75)*64,:)); %[0 0 1]); %alpha]);
%     gp.Color(4) = alpha;
% end
quant=1.00; %100largest in color parula color(0,:)
for g=int32(ntotal-10):ntotal %hardcoded because grains which died prior 10
    id = PLOTORDER(g,2);
    gp = plot3(MOBDSEE(id,1:cut),NFACES(id,1:cut),SIZEGAINBK(id,1:cut),'LineWidth',3,'Color',color(1+(1-1.00)*64,:)); %[0 0 1]); %alpha]);
    gp.Color(4) = alpha;
end
%overlap with full lines for largest of sub-populations
lid = PLOTORDER(int32((ntotal*0.25)+50),2);
gp = plot3(MOBDSEE(lid,1:cut),NFACES(lid,1:cut),SIZEGAINBK(lid,1:cut),'LineWidth',3,'Color',color(1+(1-0.25)*64,:)); %[0 0 1]); %alpha]);
lid = PLOTORDER(int32((ntotal*0.50)+50),2);
gp = plot3(MOBDSEE(lid,1:cut),NFACES(lid,1:cut),SIZEGAINBK(lid,1:cut),'LineWidth',3,'Color',color(1+(1-0.50)*64,:)); %[0 0 1]); %alpha]);
lid = PLOTORDER(int32((ntotal*0.75)+50),2);
gp = plot3(MOBDSEE(lid,1:cut),NFACES(lid,1:cut),SIZEGAINBK(lid,1:cut),'LineWidth',3,'Color',color(1+(1-0.75)*64,:)); %[0 0 1]); %alpha]);
lid = PLOTORDER(ntotal,2);
gp = plot3(MOBDSEE(lid,1:cut),NFACES(lid,1:cut),SIZEGAINBK(lid,1:cut),'LineWidth',3,'Color',color(1+(1-1.00)*64,:)); %[0 0 1]); %alpha]);

zmi = 0;
zmx = 350;
ymi = 0;
ymx = 30;
xmi = -0.07;
xmx = +0.07;

set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[30 30])
pbaspect([1 1 1])
set(gcf,'color','w')
zlim([zmi zmx]);
zt = [0:50:350];
zticks(zt);
ylim([ymi ymx]);
yt = [0:5:30];
yticks(yt);
xlim([xmi xmx]);
xt = [-0.07:0.02:0.07];
xticks(xt);
print(gcf,['PRX2D_TrackingBK_SzGainvsLocalCond5LargestOfSubPop.png'],'-dpng','-r500')
close(gcf);

%% persistence of values
NFSUM = zeros(nrows,1);
MOBSUM = zeros(nrows,1);
% summation works because we have data for all grains for the same time
% stepping!
for r=1:nrows
    NFSUM(r,1) = sum(NFACES(r,~isnan(NFACES(r,:))));
    MOBSUM(r,1) = sum(MOBDSEE(r,~isnan(MOBDSEE(r,:))));
end

color = parula;
ncolor = 64;
colorbar;
alpha = 0.2;
figure('Position',[100 100 1200 1000]);
hold('on');
xlabel({'\Sigma_i m\cdot0.5Gb^2\cdot\Delta\rho (\mum/s)'},'FontSize',fontsz,'FontName',fontnm)
ylabel({'\Sigma_i N_{faces}'},'FontSize',fontsz,'FontName',fontnm)
if Dimension == 2
zlabel({'A / A^{matr}_m normalized to maximum'},'FontSize',fontsz,'FontName',fontnm)
end
if Dimension == 3
zlabel({'V / V^{matr}_m normalized to maximum'},'FontSize',fontsz,'FontName',fontnm)
end
grid('on')
box('on')
view(0,90)

SZMAX = max(SIZEGAINBK(:,cut));
for r=1:nrows
    col = int32((SIZEGAINBK(r,cut)/SZMAX)*64);
    if col == 0
        col = 1;
    end
    plot3(MOBSUM(r,1),NFSUM(r,1),SIZEGAINBK(r,cut),'.','MarkerSize',15,'Color',color(col,:));
end
%zmi = 0; zmx = 350;
ymi = 0;
ymx = 4.5e4;
xmi = 0.0;
xmx = 80.0;

set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[30 30])
pbaspect([1 1 1])
set(gcf,'color','w')
zlim([zmi zmx]);
%zt = [0:50:350]; zticks(zt);
ylim([ymi ymx]);
yt = [0.0:1.0e4:4.5e4];
yticks(yt);
xlim([xmi xmx]);
xt = [0:10:80];
xticks(xt);
view(40,15)
print(gcf,['PRX2D_TrackingBK_SzGainvsLocalCondIntegratedAll.png'],'-dpng','-r500');
close(gcf);

save('PRX2D_BKLocalPropertiesEvoAndCurv_01.mat');


%%%%%%%%%%%%%% DEBUG DEBUG DEBUG
%%%%%%%%%%%%%% DEBUG DEBUG DEBUG
%%%%%%%%%%%%%% DEBUG DEBUG DEBUG
%%%%%%%%%%%%%% DEBUG DEBUG DEBUG
%%%%%%%%%%%%%% DEBUG DEBUG DEBUG
%%%%%%%%%%%%%% DEBUG DEBUG DEBUG
%%%%%%%%%%%%%% DEBUG DEBUG DEBUG
%%%%%%%%%%%%%% DEBUG DEBUG DEBUG

%% exemplary plot
gidx=find(VOLUME(:,tcutoff)==Vmax); %1599401;
%cut=min[find(isnan(VOLUME(gid,:)))]
plot3(MOBDSEE(gidx,:),CURV_SPEED(gidx,:),VOLUME(gidx,:),'-o')
fontsz = 20;
fontnm = 'Calibri Light';
xlabel({'v_{SEE} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
ylabel({'v_{cap} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
if Dimension == 2
zlabel({'A (\mum^2)'},'FontSize',fontsz,'FontName',fontnm)
end
if Dimension == 3
zlabel({'V (\mum^3)'},'FontSize',fontsz,'FontName',fontnm)
end
grid('on')
box('on')
view(-90,0)
view(0,0)
set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[20 20])
pbaspect([1 1 1])
set(gcf,'color','w')
view(-49,19)
xlim([-1.0e-11 +1.0e-7])
ylim([-1.0e-11 +1.0e-7])

clearvars ans c fid i id naggr optgridcm resu_new_lineid resu_old_lineid val1 val2 val3 where;

save('PRX2D_BKLocalPropertiesEvo_Time_01.mat');

%% correlations of local properties as a function of time (grain history)
optgridcm = 0;
figure('Position',[100 100 1200 1000])
for i=1:nrows
    id = i;
    %if 1==1
    %if  mod(id,100) == 0
    %if VOLUME(id,tcutoff) == Vmax & ~isnan(CURV_SPEED(i,:))
    if VOLUME(id,tcutoff) >= 3.0*Vm %& ~isnan(CURV_SPEED(i,:))
        hold on
        %%plot3(CURV_SPEED(id,1),NFACES(id,1),SZGAIN(id,tcutoff),'.','Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        plot3(MOBDSEE(id,1:tcutoff),CURV_SPEED(id,1:tcutoff),VOLUME(id,1:tcutoff),'Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        %plot3(CURV_DRVFRC(id,1:tcutoff),NFACES(id,1:tcutoff),SZGAIN(id,1:tcutoff),'-o','Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        %plot3(NFACES(id,1:tcutoff),HAGB(id,1:tcutoff),VOLUME(id,1:tcutoff),'Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
 
        if optgridcm == 1
            for t=1:tcutoff-1
                %was a grid coarsement step done between t and t+1?
                resu_old_lineid = find(TMP(:,1)==ID(id,t));
                resu_new_lineid = find(TMP(:,1)==ID(id,t+1));
                if TMP(resu_old_lineid,4) ~= TMP(resu_new_lineid,4)
                    %resu_old_lineid
                    hold on
                    plot3(CURV_SPEED(id,t),NFACES(id,t),SZGAIN(id,t),'+','Color',[1 0 0])
                    %plot3(NFACES(id,t),HAGB(id,t),VOLUME(id,t),'+','Color',[1 0 0])
                 end
            end
        end 
    end
end
fontsz = 20;
fontnm = 'Calibri Light';
xlabel({'v_{SEE} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
ylabel({'v_{cap} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
if Dimension == 2
zlabel({'A (\mum^2)'},'FontSize',fontsz,'FontName',fontnm)
end
if Dimension == 3
zlabel({'V (\mum^3)'},'FontSize',fontsz,'FontName',fontnm)
end
%% POSITIVE DRIVING FORCES MEAN PROMOTING GROWTH NOW FOR BOTH CAP AND SEE!!!!
grid('on')
box('on')
view(-90,0)
view(0,0)
set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[20 20])
pbaspect([1 1 1])
set(gcf,'color','w')
view(-49,19)
print(gcf,['PRX2D_VolumeEvoSpeedSEEandCAP_LargestGrain.png'],'-dpng','-r500')

figure
plot(MOBDSEE(:,1),CURV_SPEED(:,1),'.','MarkerSize')
