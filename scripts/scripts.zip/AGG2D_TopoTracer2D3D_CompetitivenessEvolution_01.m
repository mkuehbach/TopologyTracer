%% TopologyTracer2D3D
% AGG2D_CompetitivenessEvolution
% Author: m.kuehbach (at) mpie.de, 09/06/2017
% MinRequirement: Matlab v2017a
% Purpose: does the arrival time scheme integral value change over time for grains?
clear;
clc;
format long;
digits(32);

%% user interaction
prefix_comp = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\UnbiasedGrowthMeasures\';
firstlr = 50;
offsetlr = 50;
lastlr = 1000;
simid = 10509500;
PhysDomainSize = 2.83592616e-3; %meter
HAGBEnergy = 0.324; %J/m^2
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
LargestGrainID = 2560000; %meter


%% end of user interaction

% build hash of competitiveness values
ngr = 1+LargestGrainID;
nfid = (lastlr-firstlr)/offsetlr+1;
COMPRES = nan(1+nfid,ngr);
COMPRES(1,:) = 1:1:LargestGrainID+1;

for fid=firstlr:offsetlr:lastlr
    filename = ['E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\UnbiasedGrowthMeasures\TopoTracer2D3D.SimID.10509500.LR2D.FID.' num2str(fid) '.RCLASS.0.csv'];
    delimiter = ';';
    startRow = 15;
    formatSpec = '%f%f%f%f%f%f%f%f%f%f%[^\n\r]';
    fileID = fopen(filename,'r');
    textscan(fileID, '%[^\n\r]', startRow-1, 'WhiteSpace', '', 'ReturnOnError', false, 'EndOfLine', '\r\n');
    dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'ReturnOnError', false);
    fclose(fileID);
    TMP = [dataArray{1:end-1}];
    clearvars filename delimiter startRow formatSpec fileID dataArray ans;
   
    for i=1:length(TMP(:,1))
        gid = TMP(i,1); %grainID
        COMPRES(1+((fid-firstlr)/offsetlr+1),gid) = TMP(i,10); %m^4/Js
    end
    clearvars TMP;
    fid
end

%load the unsuccessful ones
filename = 'D:\Testenvironment\DevBranchTopoTracer\AGG2D_UnsuccessfulTargets.dat';
delimiter = {''};
formatSpec = '%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN,  'ReturnOnError', false);
fclose(fileID);
ZOMBIES = [dataArray{1:end-1}];
clearvars filename delimiter formatSpec fileID dataArray ans;

%eliminate for all unsuccessful ones
TakeThese = logical(zeros(1,1+LargestGrainID));
for i=1:length(ZOMBIES(:,1))
    TakeThese(1,ZOMBIES(i,1)) = 1;
end
COMPRES_THESE = COMPRES(:,TakeThese);

EXTREMA_THESE(1,:) = COMPRES_THESE(2,:); %initial
EXTREMA_THESE(2,:) = min(COMPRES_THESE(2:21,:))./EXTREMA_THESE(1,:); %maximum is so much of initial
EXTREMA_THESE(3,:) = max(COMPRES_THESE(2:21,:))./EXTREMA_THESE(1,:); %minimum is so much of initial
hist(EXTREMA_THESE(2,:),100)
cdfplot(EXTREMA_THESE(2,:)) %assess distribution of grain resolved reduction of epsilon compared to t0
hold on
cdfplot(EXTREMA_THESE(3,:)) %assess evolution


%% check evolution of curvature distribution for the ZOMBIES/Unsuccessful Grains
CURVRES = nan(1+nfid,ngr);
CURVRES(1,:) = 1:1:LargestGrainID+1;

for fid=firstlr:offsetlr:lastlr
    filename = ['E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\CurvatureEvolution\TopoTracer2D3D.SimID.1009550.OMP3.FID.' num2str(fid) '.CurvApprx.csv'];
    delimiter = ';';
    startRow = 3;
    formatSpec = '%f%f%f%f%f%f%f%f%f%[^\n\r]';
    fileID = fopen(filename,'r');
    dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
    fclose(fileID);
    TMP = [dataArray{1:end-1}];
    clearvars filename delimiter startRow formatSpec fileID dataArray ans;
   
    for i=1:length(TMP(:,1))
        gid = TMP(i,1); %grainID
        CURVRES(1+((fid-firstlr)/offsetlr+1),gid) = TMP(i,2); %Pa
    end
    clearvars TMP;
    fid
end

CURVRES(2:1+nfid,:) = CURVRES(2:1+nfid,:).*-1.0; %change sign such that negative is promoting shrinkage
CURVSUM(1,:) = sum(~isnan(CURVRES(2:1+nfid,:)));
plot(2:1+nfid,CURVRES(2:1+nfid,1))


save('AGG2D_TopoTracer2D3D_CompEvolution_01.mat');









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

EliminateColumns = any(isnan(COMPRES));
COMPRES = COMPRES(:,~EliminateColumns);
mean(COMPRES(1,:))
mean(COMPRES(15,:))
clearvars EliminateColumns;

%COMPRES = transpose(COMPRES);

% load mxszgain
filename = [prefix_comp 'TopoTracer2D3D.SimID.' num2str(simid) '.Competitiveness.FID.' num2str(50) '.csv'];
delimiter = ';';
startRow = 2;
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
fclose(fileID);
COMP = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;
MAXSZGAIN = nan(1,ngr);
for i=1:length(COMP(:,1))
    gid = COMP(i,1);
    MAXSZGAIN(1,gid) = COMP(i,4); %maxszgain
end
clearvars COMP;
maxpos = find(MAXSZGAIN(1,:)==max(MAXSZGAIN(1,:)));

plot(1:15,reshape(COMPRES(:,maxpos),[1, 15]));

save('AGG_CompetitivenessEvolution_01.mat');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
