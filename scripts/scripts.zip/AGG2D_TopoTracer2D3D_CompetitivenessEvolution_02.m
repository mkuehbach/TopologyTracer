%% TopologyTracer2D3D
% AGG2D_CompetitivenessEvolution
% Author: m.kuehbach (at) mpie.de, 09/06/2017
% MinRequirement: Matlab v2017a
% Purpose: does the arrival time scheme integral value change over time for grains?
clear;
clc;
format long;
digits(32);

%% user interaction
prefix_comp = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\UnbiasedGrowthMeasures\';
firstlr = 50;
offsetlr = 50;
lastlr = 750;
simid = 509500;
PhysDomainSize = 2.83592616e-3; %meter
HAGBEnergy = 0.324; %J/m^2
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
LargestGrainID = 2560000;PhysDomainSize = 2.83592616e-3; %meter
HAGBEnergy = 0.324; %J/m^2
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;

%% endf of user interaction

% build hash of competitiveness values
ngr = 1+LargestGrainID;
nfid = (lastlr-firstlr)/offsetlr+1;
COMPRES = nan(nfid,ngr);

for fid=firstlr:offsetlr:lastlr
        %% load competitiveness file
        filename = [prefix_comp 'TopoTracer2D3D.SimID.' num2str(simid) '.Competitiveness.FID.' num2str(fid) '.csv'];
        delimiter = ';';
        startRow = 2;
        formatSpec = '%f%f%f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
        fclose(fileID);
        COMP = [dataArray{1:end-1}];
        clearvars filename delimiter startRow formatSpec fileID dataArray ans;
   
        for i=1:length(COMP(:,1))
            gid = COMP(i,1); %grainID
            COMPRES((fid-firstlr)/offsetlr+1,gid) = COMP(i,3); %integralvalue
        end
        clearvars COMP;
        fid
end

EliminateColumns = any(isnan(COMPRES));
COMPRES = COMPRES(:,~EliminateColumns);
mean(COMPRES(1,:))
mean(COMPRES(15,:))
clearvars EliminateColumns;

%COMPRES = transpose(COMPRES);

% load mxszgain
filename = [prefix_comp 'TopoTracer2D3D.SimID.' num2str(simid) '.Competitiveness.FID.' num2str(50) '.csv'];
delimiter = ';';
startRow = 2;
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
fclose(fileID);
COMP = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;
MAXSZGAIN = nan(1,ngr);
for i=1:length(COMP(:,1))
    gid = COMP(i,1);
    MAXSZGAIN(1,gid) = COMP(i,4); %maxszgain
end
clearvars COMP;
maxpos = find(MAXSZGAIN(1,:)==max(MAXSZGAIN(1,:)));

plot(1:15,reshape(COMPRES(:,maxpos),[1, 15]));

save('AGG_CompetitivenessEvolution_01.mat');

load('AGG_CompetitivenessEvolution_01.mat');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
