%% TopologyTracer2D3D
% PRX2D_MaxSzGainVsCompetitivenessVsLR2D
% Author: m.kuehbach (at) mpie.de, 10/19/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize logic AND between arrival time and long range quantities
clear;
clc;
format long;
digits(32);
load('AGG2D_MaxSzGainFWvsLR2D_01.mat');
load('AGG2D_MaxSzGainFWvsCOMPvsNFACES_01.mat');

%%load difference of face count to nearest neighbors = f(t) --> aim
%%quantify topological advantage
prefix_trackfw = 'E:\LongRangePaperFINAL\PRX2D\2DataAnalysis\TrackingParallel\TrackingFW_Resolution_100\';
nfdiff_ngr = 1 + 2560000;
nfdiff_nrows = 2548493;
nfdiff_ncols = 91;
prgnm_fw = 'TopoTracer2D3D.SimID.11.';
suffix_fw = ['.F.10.O.1.L.100.NC.' num2str(nfdiff_ncols) '.NR.' num2str(nfdiff_nrows) '.bin'];

fileID = fopen([prgnm_fw 'FW.NFDIFF' suffix_fw]);
NFDIFF = fread(fileID,[nfdiff_nrows,nfdiff_ncols],'int32');
fclose(fileID);


%%load which row of NFDIFF maps to which grain ID
filename = 'D:\Testenvironment\DevBranchTopoTracer\AGG2D\TopoTracer2D3D.SimID.11.FWTargets.All.GrainsElimbnd.Rank.0.csv';
delimiter = {''};
startRow = 2;
formatSpec = '%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
fclose(fileID);
NFDIFF2GID = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;

%% build hash of comp and longrange
logic_and = nan(7,ngr);
for g=1:length(MXSZGAIN(:,1))
    logic_and(1,MXSZGAIN(g,1)) = MXSZGAIN(g,1); %grain ID
    logic_and(2,MXSZGAIN(g,1)) = MXSZGAIN(g,2); %maxsizegain (total size in micron^2 ever achieved maximal)
end
for g=1:length(COMP(:,1))
    logic_and(3,COMP(g,1)) = COMP(g,3); %summation ti/tj
end
for g=1:length(LR2D(:,1))
    logic_and(4,LR2D(g,1)) = LR2D(g,10); %epsilon something at 13.6s
end
for g=1:length(NFDIFF2GID(:,1))
    %face difference to neighbors
    logic_and(5,NFDIFF2GID(g,1)) = sum(NFDIFF(g,:)); %sum to topological situation
end
for g=1:length(NFACES(:,1))
    logic_and(6,GID(g,1)) = sum(NFACES(g,:))/41; %average number of faces in total, 41 timesteps in 10:1:50
    logic_and(7,GID(g,1)) = NFACES(g,1); %the initial number of faces
end
logic_and_final = logic_and(:,sum(isnan(logic_and))<1);


%% plot
L1 = reshape(logic_and_final(1,:),[length(logic_and_final(1,:)), 1]); %extGID
L2 = reshape(logic_and_final(2,:),[length(logic_and_final(2,:)), 1]); %maxsiz
L3 = reshape(logic_and_final(3,:),[length(logic_and_final(3,:)), 1]); %ti/tj
L4 = reshape(logic_and_final(4,:),[length(logic_and_final(4,:)), 1]); %epsilon
L5 = reshape(logic_and_final(5,:),[length(logic_and_final(5,:)), 1]); %face diff
L6 = reshape(logic_and_final(6,:),[length(logic_and_final(6,:)), 1]); %topological activity total nfaces
L7 = reshape(logic_and_final(7,:),[length(logic_and_final(7,:)), 1]); %holm argument requirement is to have more than 6 neighbors
%% plot eps/ti/tj and MaxSize
figure('Position',[100 100 1200 1000])
hold('on')
plot3(L3,L4,log10(L2),'.','MarkerSize',2); 
fontszcap = 26;
fontszax = 26;
fontnm = 'Calibri Light';
%color = parula;
plot3(L2,L3,L1,'.','Color',color(64,:));
xlabel({'\Sigma t_i/t_j'},'FontSize',fontszcap,'FontName',fontnm);
ylabel({'\xi^{13.6s}_{r=22.7\mum} (m^4/Js)'},'FontSize',fontszcap,'FontName',fontnm);
zlabel({'log10 maximum area achieved (\mum^2)'},'FontSize',fontszcap,'FontName',fontnm);
xlim([0 7]);
xt = [0:1:7];
xticks(xt);
ylim([0 3e-13]);
yt = [0:0.5e-13:3e-13];
yticks(yt);
zlim([-1 5]);
zt = [-1:1:5];
zticks(zt);
%add projection
%xi-sum plane at maxsize -1
PLANELOC(1:1:length(L2),1) = log10(0.1);
hold on
plot3(L3,L4,PLANELOC,'.','Color',color(10,:),'MarkerSize',2);
%size-sum plane at xi = 3e-13
PLANELOC(1:1:length(L2),1) = 3e-13;
hold on
plot3(L3,PLANELOC,log10(L2),'.','Color',color(30,:),'MarkerSize',2);
%xi-si plane at sum=7
PLANELOC(1:1:length(L2),1) = 7;
hold on
plot3(PLANELOC,L4,log10(L2),'.','Color',color(50,:),'MarkerSize',2);
grid('on');
box('on');
set(gca,'FontSize',fontszax,'FontName',fontnm,'LineWidth',1.5);
set(gcf,'PaperUnits','Inches');
set(gcf,'PaperSize',[30 30]);
pbaspect([1 1 1]);
set(gcf,'color','w');
view(45,29);

print(gcf,['AGG2D_LogicAndCompetivenessLR2D_02.png'],'-dpng','-r500');
close(gcf);        

save('AGG2D_LogicAnd_03.mat');















%% filter out all grain IDs with ti/tj < 1.0, eps > 2 but maxsz < 100
these = L2 < 100 & L3 < 1.0 & L4 > 2.0e-14;
sum(these)
bL2 = L2 < 100;
sum(bL2)
bL3 = L3 < 1.0;
sum(bL3)
bL4 = L4 > 2.0e-14;
sum(bL4)


plot(L6,log10(L2),'.')
hist(L6(these==1),25)

%%separation strength of the various approaches
%%Holm argument Acta MAt 2003 starts with ~<10000 grains, at theta star/thetacrit = 30/13 less
%%than 10 remain each then occupying 1/10 of entire RVE area
histogram2(L7(:,1),log10(L2(:,1)),'BinMethod','fd','Normalization','probability','DisplayStyle','tile','ShowEmptyBins','off');
%how many > 6 faces in total
sum(L7 > 6)
%how many of these larger 100?
sum(L7 > 6 & L2 > 1000)
%fraction
sum(L7 > 6 & L2 > 1000) / sum(L7 > 6)
%so approximately only 1% of all

%%in comparison how many larger than 100
sum(L2 > 100)
%how many of those with eps and ti/tj
sum(L3 < 1.0 & L4 > 1.0e-14)
sum(L3 < 1.0 & L4 > 1.0e-14 & L2 > 100)/sum(L3 < 1.0 & L4 > 1.0e-14)









%%%% color scaled 

nl = length(L1(:,1));
gamma = 4.0;
MinL2 = log10(min(L2)); %map to zero
MaxL2 = log10(max(L2));
Iin = (log10(L2) - MinL2)./(MaxL2-MinL2);
Iout = Iin.^gamma;
cid = reshape(1+int32(ceil(Iout.*63)), [1, nl]);
plot(log10(L2),Iout.*64,'.')
%%%%cb = (((1:1:64)/64)-1).^(1/gamma);
TMP = zeros(3,nl);
RR = reshape(color(:,1),[1, 64]);
GG = reshape(color(:,2),[1, 64]);
BB = reshape(color(:,3),[1, 64]);
TMP(1,:) = RR(1,cid);
TMP(2,:) = GG(1,cid);
TMP(3,:) = BB(1,cid);
COLORS = zeros(nl,3);
COLORS(:,1) = reshape(TMP(1,:),[nl, 1]);
COLORS(:,2) = reshape(TMP(2,:),[nl, 1]);
COLORS(:,3) = reshape(TMP(3,:),[nl, 1]);
clearvars TMP RR GG BB

'ColorMapping done'
figure('Position',[100 100 1200 1000])
hold('on')
for i=1:nl %length(L1(:,1))
    if L2(i,1) < 100
        continue;
    else
    hold on
    plot3(L3(i,1),L4(i,1),L2(i,1),'.','Color',COLORS(i,1:3)); 
    i
    end
end
colorbar('h')
%cbh = colorbar('peer', AxesH, 'h','XTickLabel',{'-12','-9','-6','-3','0','3','6','9','12'}, ...'XTick', -12:3:12)
fontsz = 22;
fontnm = 'Calibri Light';
%color = parula;
%plot3(L2,L3,L1,'.','Color',[0 0 1]);
xlabel({'\Sigma t_i/t_j'},'FontSize',fontsz,'FontName',fontnm);
ylabel({'\xi^{13.6s}_{r=22.7\mum} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm);
zlabel({'Sum of 10:100 \Delta N_f'},'FontSize',fontsz,'FontName',fontnm);
grid('on');
box('on');
%histogram2(L4(:,1),log10(L1(:,1)),'BinMethod','fd','Normalization','probability','DisplayStyle','tile','ShowEmptyBins','off');
        
save('AGG2D_LogicAnd_02.mat');
load('AGG2D_LogicAnd_02.mat');

%it is necessary to inspect the individual trajectories of the grains which
%do not grow to substantial size
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% well than lets get their IDs
clearvars these UNSUCCESSFUL_TARGETS;
these = L2 < 100 & L3 < 0.5 & L4 > 2.0e-14;
sum(these)
UNSUCCESSFUL_TARGETS = int32(L1(these==1));
dlmwrite('AGG2D_UnsuccessfulTargets.dat',UNSUCCESSFUL_TARGETS,'precision','%i');
find(isnan(UNSUCCESSFUL_TARGETS))

%anything special with these?







zlabel({'log10 maximum area achieved (\mum^2)'},'FontSize',fontsz,'FontName',fontnm);

set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5);
set(gcf,'PaperUnits','Inches');
set(gcf,'PaperSize',[30 30]);
pbaspect([1 1 1]);
set(gcf,'color','w');
%colorbar;
view(-54,14);
xlim([0 7])
xt = [0:1.0:7];
xticks(xt);
ylim([0 3.e-13])
yt = [0:0.5e-13:3.e-13];
yticks(yt);
zlim([0 10000])
print(gcf,['AGG2D_MaxSzGainFWvsCOMPvsNFaces_01.png'],'-dpng','-r500');
close(gcf);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
clc;
format long;
digits(32);
load('AGG2D_LogicAnd_01.mat');




    
