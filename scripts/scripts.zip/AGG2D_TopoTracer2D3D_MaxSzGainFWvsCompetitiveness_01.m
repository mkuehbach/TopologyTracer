%% TopologyTracer2D3D
% PRX2D_MaxSzGainBKvsCompetitivenessvsLocalFeatures
% Author: m.kuehbach (at) mpie.de, 09/07/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize all grains maximum size until disappearance or survival
% and set into relation to arrival time competition in environment 
clear;
clc;
format long;
digits(32);

%% user interaction
prefix_trackbk = 'E:\LongRangePaperFINAL\PRX2D\2DataAnalysis\TrackingParallel\TrackingBK_Resolution_1\';
prefix_comp = 'E:\LongRangePaperFINAL\PRX2D\2DataAnalysis\UnbiasedGrowthMeasures\';
firstlr = 100;
offsetlr = 100;
lastlr = 2000;
simid = 1005200;
PhysDomainSize = 4.2037e-3; %meter
HAGBEnergy = 1.000; %J/m^2
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
rclass = 3;
LargestGrainID = 9900000;

%% load competetive

%% end of user interaction
%% load forward tracking data for all grains up to timestep 50
ncolsfw = 41;
nrowsfw = 2548653;
prgnm_fw = 'TopoTracer2D3D.SimID.1050.';
suffix_fw = ['.F.' num2str(10) '.O.' num2str(1) '.L.' num2str(50) '.NC.' ...
    num2str(ncolsfw) '.NR.' num2str(nrowsfw) '.bin'];

%% load backtracking grain history in memory
fileID = fopen([prefix_trackfw prgnm_fw 'FW.NF' suffix_fw]);
NFACES = fread(fileID,[nrowsfw,ncolsfw],'uint32');
fclose(fileID);

% fileID = fopen([prefix_trackbk prgnm_bk 'FW.VOL' suffix_bk]);
% VOLUME = fread(fileID,[nrowsbk,ncolsbk],'double');
% fclose(fileID);
% fileID = fopen([prefix_trackbk prgnm_bk 'FW.MOBDSEE' suffix_bk]);
% MOBDSEE = fread(fileID,[nrowsbk,ncolsbk],'double');
% fclose(fileID);
% fileID = fopen([prefix_trackbk prgnm_bk 'FW.HAGB' suffix_bk]);
% HAGB = fread(fileID,[nrowsbk,ncolsbk],'double');
% fclose(fileID);
'Binary raw data successfully read'

% load grainID to get mapping of row to grainIDs
filename = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\TrackingParallel\TrackingFW_Resolution_1\TopoTracer2D3D.SimID.1050.FW.All.GrainsElimbnd.Rank.0.csv';
delimiter = {''};
startRow = 2;
formatSpec = '%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
fclose(fileID);
GID = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;
'GID loaded...'

% build hash for maintaining
ngr = 1+2570000;
nfsumhash = nan(1,ngr);
for r=1:length(NFACES(:,1))
    gid = GID(r,1);
    nfsumhash(1,gid) = sum(NFACES(r,:)); %maintained high number of faces
end

%% map sum of NFACES in relation to Competitiveness
for i=1:length(COMP(:,1));
    gid = COMP(i,1);
    COMP(i,5) = nfsumhash(1,gid);
end

plot3(COMP(:,3),COMP(:,5),COMP(:,4),'.')


for fid=firstlr:1:firstlr
        %% load competitiveness file
        filename = [prefix_comp 'TopoTracer2D3D.SimID.' num2str(simid) '.Competitiveness.FID.' num2str(fid) '.csv'];
        delimiter = ';';
        startRow = 2;
        formatSpec = '%f%f%f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
        fclose(fileID);
        COMP = [dataArray{1:end-1}];
        clearvars filename delimiter startRow formatSpec fileID dataArray ans;
   
        
        fontsz = 22;
        fontnm = 'Calibri Light';
        figure('Position',[100 100 1200 1000])
        hold('on')
        color = parula;
        plot3(COMP(:,3),COMP(:,5),COMP(:,4),'.','Color',[0 0 1]);
        %h = histogram2(COMP(:,3),log10(COMP(:,4)),'BinMethod','fd','Normalization','probability','DisplayStyle','tile','ShowEmptyBins','off');
        xlabel({'\Sigma t_i/t_j'},'FontSize',fontsz,'FontName',fontnm);
        ylabel({'\Sigma^{50}_{10} N_{faces}'},'FontSize',fontsz,'FontName',fontnm);
        zlabel({'log10 maximum area achieved (\mum^2)'},'FontSize',fontsz,'FontName',fontnm);
        %projections
        fixed = reshape(repmat(550,1,length(COMP(:,1))),[length(COMP(:,1)),1]);
        gp = plot3(COMP(:,3),fixed,COMP(:,4),'.','Color',color(45,:));
        gp.Color(4) = 0.01;
        fixed = reshape(repmat(6,1,length(COMP(:,1))),[length(COMP(:,1)),1]);
        gp = plot3(fixed,COMP(:,5),COMP(:,4),'.','Color',color(45,:));
        gp.Color(4) = 0.01;
        grid('on');
        box('on');
        set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5);
        set(gcf,'PaperUnits','Inches');
        set(gcf,'PaperSize',[30 30]);
        pbaspect([1 1 1]);
        set(gcf,'color','w');
        %colorbar;
        view(-54,14);
        xlim([0 6])
        xt = [0:1.0:6];
        xticks(xt);
        ylim([50 550])
        yt = [50:50:550];
        yticks(yt);
        print(gcf,['AGG2D_MaxSzGainFWvsCOMPvsNFaces_01.png'],'-dpng','-r500');
        close(gcf);

        clearvars h;
        ['Processed ' num2str(fid)]
end
save('AGG2D_MaxSzGainFWvsCOMPvsNFACES_01.mat');

