%% TopologyTracer2D3D
% AGG2D_MaxSzGainFWLR2D
% Author: m.kuehbach (at) mpie.de, 09/06/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize evolution of all grains to their maximum size until disappearance or survival
% and set into relation to long range environment mobility
clear;
clc;
format long;
digits(32);

%% user interaction
prefix_tp = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\TrackingParallel\TrackingBK_Resolution_1\';
mxszfw_fn = 'TopoTracer2D3D.SimID.109500.MaxSizeGainFW.F.10.O.1.L.9500.csv';
prefix_lr = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\UnbiasedGrowthMeasures\';
time_fn = 'E:\LongRangePaperFINAL\AGG2D\1Coarsening\NrGrains&EnergyStatistics.txt';
firstlr = 50;
offsetlr = 50;
lastlr = 9500;
simid = 10509500;
PhysDomainSize = 2.83592616e-3; %meter
HAGBEnergy = 0.324; %J/m^2
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
rclass = 3;
LargestGrainID = 2560000;

%% end of user interaction
filename = [prefix_tp mxszfw_fn];
delimiter = ';';
startRow = 3;
formatSpec = '%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
fclose(fileID);
MXSZGAIN = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;
['Loaded ' mxszfw_fn]
%max(MXSZGAIN(:,2))
% maximum size gain is ascendingly ordered but not necessarily filled with
% contiguous values as grains may had boundary contact and where therefore
% expelled from the analysis
%MXSZGAIN = sortrows(MXSZGAIN,2);

%% load real time 
filename = 'E:\LongRangePaperFINAL\AGG2D\1Coarsening\NrGrains&EnergyStatistics.txt';
delimiter = '\t';
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN,  'ReturnOnError', false);
fclose(fileID);
REALTIME = [dataArray{1:end-1}];
clearvars filename delimiter formatSpec fileID dataArray ans;

% long range environment
for fid=firstlr; %%:offsetlr:lastlr
    realtime = REALTIME(fid,1);
    lr2d_fn = [prefix_lr 'TopoTracer2D3D.SimID.' num2str(simid) '.LR2D.FID.' num2str(fid) '.RCLASS.0.csv'];
    delimiter = ';';
    startRow = 15;
    formatSpec = '%f%f%f%f%f%f%f%f%f%f%[^\n\r]';
    fileID = fopen(lr2d_fn,'r');
    if fileID ~= -1 
        textscan(fileID, '%[^\n\r]', startRow-1, 'WhiteSpace', '', 'ReturnOnError', false, 'EndOfLine', '\r\n');
        dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'ReturnOnError', false);
        fclose(fileID);
        LR2D = [dataArray{1:end-1}];
        ['Loaded ' lr2d_fn]
  
        % build hash to find which values exist
        clearvars lrhash;
        ngr=1+LargestGrainID;
        lrhash = nan(1,ngr);
        for i=1:length(LR2D(:,1))
            lrhash(1,LR2D(i,1)) = LR2D(i,10); %mobility environment
        end
        'LR hash build'

        clearvars szhash;
        % build tridirectional hash to aggregate which values exist
        szhash = nan(1,ngr);
        for i=1:length(MXSZGAIN(:,1))
            szhash(1,MXSZGAIN(i,1)) = MXSZGAIN(i,2);
        end
        'SzGain hash build'

        clearvars RESULTS;
        RESULTS(1,:) = 1:1:ngr;
        RESULTS(2,:) = lrhash;
        RESULTS(3,:) = szhash;
        EliminateColumns = any(isnan(RESULTS));
        RESULTS = RESULTS(:,~EliminateColumns);
        RESULTS = transpose(RESULTS);
        'Correlation between MXSZGAIN and initial environment long-range established!'
        clearvars lrhash szhash EliminateColumns;

        %% safe MATLAB state
        %%save('AGG2D_MaxSzGainFWvsLR2D_01.mat');

        fontszcap = 26;
        fontszax = 26;
        fontnm = 'Calibri Light';
        figure('Position',[100 100 1000 1000])
        hold('on')
        h = histogram2(RESULTS(:,2),log10(RESULTS(:,3)),'BinMethod','fd','Normalization','probability','DisplayStyle','tile','ShowEmptyBins','off');
        xlabel({'\xi^{13.6s}_{r=22.7\mum} (m^4/Js)'},'FontSize',fontszcap,'FontName',fontnm);
        ylabel({'log10 maximum area achieved (\mum^2)'},'FontSize',fontszcap,'FontName',fontnm);
        grid('on');
        box('on');
        set(gca,'FontSize',fontszax,'FontName',fontnm,'LineWidth',1.5);
        set(gcf,'PaperUnits','Inches');
        set(gcf,'PaperSize',[30 30]);
        pbaspect([1 1 1]);
        set(gcf,'color','w');
        colorbar;
        
%        str = [num2str(round(realtime,3,'significant')) 's'];
%        t = annotation(gcf, 'textbox', 'Position',[1 1 0.5 0.5], 'uni',0), ...
%            'String', str, 'vert', 'bottom', 'FitBoxToText','on','EdgeColor','none','FontSize',fontsz,'FontName',fontnm);
%         t = annotation('textbox');
%         t.FontSize = fontsz;
%         t.FontName = fontnm;
%         t.HorizontalAlignment = 'right';
%         t.String=str;
%         t.EdgeColor = 'none';
%         t.Position = [0.2 0.8 0.1 0.1];
        
        print(gcf,['AGG2D_MaxSzGainFWvsLR2D.FID.' num2str(fid) '.png'],'-dpng','-r500');
        close(gcf);
   
        clearvars h;
        
    end
    clearvars filename delimiter startRow formatSpec fileID dataArray ans;
   ['Processed ' num2str(fid)]
end

save('AGG2D_MaxSzGainFWvsLR2D_01.mat');

load('AGG2D_MaxSzGainFWvsLR2D_01.mat');

%% evolution of LR2D meta data
for fid=firstlr:offsetlr:lastlr
    %SnapshotID, 
    %r
    %InspectionArea
    %TotalAreaEnclosedByContours
    %TotalAreaEnclosedButNotTriangularizable ...
    %TotalTriangleCnts
    %TotalPolygonsTriangularized,
    %TotalPolygonsNonTriangularizable
    %OverlapLeakageAreaTotal,
    %OverlapLeakageNumberIncidences
    %OverlapComputationTotalTrianglesVisits
    f = 1+(fid-firstlr)/offsetlr;
    lr2d_fn = [prefix_lr 'TopoTracer2D3D.SimID.' num2str(simid) '.LR2D.FID.' num2str(fid) '.RCLASS.0.csv'];
    delimiter = ';';
    endRow = 11;
    formatSpec = '%*s%f%*s%*s%*s%*s%*s%*s%*s%*s%[^\n\r]';
    fileID = fopen(lr2d_fn,'r');
    if ( fileID ~= -1 )
        dataArray = textscan(fileID, formatSpec, endRow, 'Delimiter', delimiter, 'TextType', 'string', 'ReturnOnError', false, 'EndOfLine', '\r\n');
        fclose(fileID);
        LRMETA(:,f) = [dataArray{1:end-1}];
    end
    clearvars delimiter endRow formatSpec fileID dataArray ans;
end

for r=4:11
    [num2str(r) ' --> min ' num2str(min(LRMETA(r,:))) ' --> max ' num2str(max(LRMETA(r,:))) '  --> sum ' num2str(sum(LRMETA(r,:)))]
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%set(gca,'XTick',[-4.0e6:0.5e6:2.0e6]) %round(min(RESULTS(:,3)),2,'significant'):0.3e6:round(max(RESULTS(:,3)),2,'significant')])
%set(gca,'XTick',[round(min(RESULTS(:,3)),2,'significant'):0.3e6:round(max(RESULTS(:,3)),2,'significant')])
%set(gca,'YTick',[ymin-eps:0.1:ymin+sqsize+eps/2])
%alpha = 0.2;
%gp = plot(RESULTS(:,2),log10(RESULTS(:,3)),'.')
%gp.Color(4) = 0.001;