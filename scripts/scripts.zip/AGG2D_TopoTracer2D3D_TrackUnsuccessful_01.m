%% TopologyTracer2D3D
% AGG2D_TopoTracer2D3D_TrackUnsuccessful
% Author: m.kuehbach (at) mpie.de, 10/24/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize evolution of unsuccessful grains unsuccessful in terms
% of favorable environment topological advantage but unable to manage
clear;
clc;
format long;
digits(32);

prefix_trackfw = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\TrackingUnsuccessful\';
prefix_trackfw = '666\';
ngr = 1 + 2560000;
nrows = 219559;
ncols = 950;
PhysDomainSize = 2.83592616e-3; %meter
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
prgnm_fw = [prefix_trackfw 'TopoTracer2D3D.SimID.666.'];
suffix_fw = ['.F.10.O.10.L.9500.NC.' num2str(ncols) '.NR.' num2str(nrows) '.bin'];

fileID = fopen([prgnm_fw 'FW.VOL' suffix_fw]);
VOL = fread(fileID,[nrows,ncols],'double');
fclose(fileID);
fileID = fopen([prgnm_fw 'FW.NF' suffix_fw]);
NFACES = fread(fileID,[nrows,ncols],'int32');
fclose(fileID);
fileID = fopen([prgnm_fw 'FW.VOL' suffix_fw]);
MOBDSEE = fread(fileID,[nrows,ncols],'double');
fclose(fileID);
fileID = fopen([prgnm_fw 'FW.VOL' suffix_fw]);
HAGB = fread(fileID,[nrows,ncols],'double');
fclose(fileID);
'Rawdata loaded'

%% modify data
VOL = VOL .* DomainSize;
'Volume from relative to micron^Dimension'
NFACES(NFACES==0)=NaN;
MOBDSEE(MOBDSEE==0.0)=NaN;
HAGB(HAGB==0.0)=NaN;
VOL(VOL==0.0)=NaN;
'Replaced 0.0 with NaN'

%% load time
filename = 'E:\LongRangePaperFINAL\AGG2D\1Coarsening\NrGrains&EnergyStatistics.txt';
delimiter = '\t';
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN,  'ReturnOnError', false);
fclose(fileID);
REALTIME = [dataArray{1:end-1}];
clearvars filename delimiter formatSpec fileID dataArray ans;

ID = zeros(1,ncols);
for c=1:ncols
    ID(1,c) = REALTIME(10+(c-1)*10,1);
end

%% load grainIds of unsuccessful
filename = 'D:\Testenvironment\DevBranchTopoTracer\AGG2D\666\TopoTracer2D3D.SimID.666.FW.All.GrainsElimbnd.Rank.0.csv';
delimiter = {''};
startRow = 2;
formatSpec = '%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
fclose(fileID);
GIDUnsuccessful = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;


%% plot evolution
figure('Position',[100 100 1200 1000])
for g=1:nrows
    if g ~= 76041 %the one growing to absolute largest size in subpopulation of unsuccessful ones!
    %if mod(g,50) ~= 0
       continue;
    else
        g
        hold('on')
        plot3(ID(1,:),MOBDSEE(g,:),log10(VOL(g,:))); %,'.'); 
    end
end
fontsz = 22;
fontnm = 'Calibri Light';
xlabel({'Time (s)'},'FontSize',fontsz,'FontName',fontnm);
ylabel({'m/s (\mum/s)'},'FontSize',fontsz,'FontName',fontnm);
%ylabel({'HAGB'},'FontSize',fontsz,'FontName',fontnm);
zlabel({'Area (\mum^2)'},'FontSize',fontsz,'FontName',fontnm);
grid('on');
box('on');

%find(VOL(:,ncols)==max(VOL(:,ncols)))
%save('AGG2D_TopoTracer2D3D_Unsuccessful_01.m','-v7.3');
