%% TopologyTracer2D3D
% AGG2D_TrackingRndUnsuccessful
% Author: m.kuehbach (at) mpie.de, 12/05/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize evolution of unsuccessful candidates despite high \xi and low sum t_i/t_j in AGG2D 
% in relation to topology and capillarity implicit function of time
clear;
clc;
format long;
digits(32);

%% user interaction
PhysDomainSize = 2.83592616e-3; %m
HAGBEnergy = 0.324; %J/m^2
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
ngr = 1 + 2560000;
nrowsce = 25000;
ncolsce = 9500;

firstce = 1;
offsetce = 1;
lastce = 9500;

prefix_ce = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\CurvatureEvolutionTracking\EvolutionRndSampleUnsuccessful\';
prgnm_ce = 'TopoTracer2D3D.SimID.2.CapTracking.';
suffix_ce = ['.' num2str(firstce) '.O.' num2str(offsetce) '.L.' num2str(lastce) '.NC.' ...
    num2str(ncolsce) '.NR.' num2str(nrowsce) '.bin'];

prefix_ngrains = 'E:\LongRangePaperFINAL\AGG2D\1Coarsening\';

%% load capillary track matrix
fileID = fopen([prefix_ce prgnm_ce 'VCURV' suffix_ce]);
VCURV = fread(fileID,[nrowsce,ncolsce],'double');
fclose(fileID);

fileID = fopen([prefix_ce prgnm_ce 'TSUPP' suffix_ce]);
TSUPP = fread(fileID,[nrowsce,ncolsce],'uint32');
fclose(fileID);

fileID = fopen([prefix_ce prgnm_ce 'VSUPP' suffix_ce]);
VSUPP = fread(fileID,[nrowsce,ncolsce],'uint32');
fclose(fileID);
'Capillary event matrix loaded'

%% change sign of VCURV because the rawdata define positive as shrinkage and negative as growth
VCURV = -1.0.*VCURV;
%% replace extremely high curvature measure values that indicate non-computable data with NaN
% such that they do not become plotted
VCURV(abs(VCURV) > 1.0e30) = NaN;

%% load realtime
filename = [prefix_ngrains 'NrGrains&EnergyStatistics.txt'];
delimiter = '\t';
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN, 'ReturnOnError', false);
fclose(fileID);
TMP = [dataArray{1:end-1}];
clearvars filename delimiter formatSpec fileID dataArray ans;

%% set up ID vector as a tool to allowing plotting
ID = zeros(nrowsce,ncolsce);
for t=1:ncolsce
    ID(:,t) = TMP(firstce+(t-1)*offsetce,1);
end
'Real time loaded'
clearvars TMP;

fontszcap = 26;
fontszax = 26;
fontnm = 'Calibri Light';

%% plotting order in ascending sizegain to enforce stacking of transparent lines per grain
gmax = find( VOLUME(:,ncolsbk)==max(VOLUME(:,ncolsbk)) );
%cut=190-1;
PLOTORDER = zeros(nrowsbk,2);
%PLOTORDER(:,1) = cSZGAIN(:,cut); %MaximumSizeGain
PLOTORDER(:,1) = SZGAIN(:,ncolssz-1); 
PLOTORDER(:,2) = 1:1:nrowsbk; %LineID
PLOTORDER = sortrows(PLOTORDER,1);

%when died?
DEADTIME = nan(25000,2);
for g=1:25000
    DEADTIME(g,1) = g;
    DEADTIME(g,2) = min(find(isnan(VCURV(g,:))));
    g
end
DEADTIME = sortrows(DEADTIME,2);
color = parula;
tcutoff = 9499;
alpha = 0.1;
figure('Position',[100 100 3000 1000]);
hold on
g = DEADTIME(25000,1);
plot(log10(ID(g,1:tcutoff)),VCURV(g,1:tcutoff),'LineWidth',1.5,'Color',[color(10,:) 1]); %,SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);
hold on
g = DEADTIME(20000,1);
plot(log10(ID(g,1:tcutoff)),VCURV(g,1:tcutoff),'LineWidth',1.5,'Color',[color(20,:) 1]); %,SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);
hold on
g = DEADTIME(15000,1);
plot(log10(ID(g,1:tcutoff)),VCURV(g,1:tcutoff),'LineWidth',1.5,'Color',[color(30,:) 1]); %,SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);
hold on
g = DEADTIME(10000,1);
plot(log10(ID(g,1:tcutoff)),VCURV(g,1:tcutoff),'LineWidth',1.5,'Color',[color(40,:) 1]); %,SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);
hold on
g = DEADTIME(5000,1);
plot(log10(ID(g,1:tcutoff)),VCURV(g,1:tcutoff),'LineWidth',1.5,'Color',[color(50,:) 1]); %,SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);
hold on
g = DEADTIME(1,1);
plot(log10(ID(g,1:tcutoff)),VCURV(g,1:tcutoff),'LineWidth',1.5,'Color',[color(60,:) 1]); %,SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);




for i=25000:-1:25000-3 %longest lasting quantile
    hold on
    g = DEADTIME(i,1);
    plot(log10(ID(g,1:tcutoff)),VCURV(g,1:tcutoff),'LineWidth',1.5,'Color',[0 0 1 0.2]); %,SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);
    %gp = gp.Color(4) = alpha;
	g
end
for i=12500:-1:12500-3 %intermediate lasting quantile
    hold on
    g = DEADTIME(i,1);
    plot(log10(ID(g,1:tcutoff)),VCURV(g,1:tcutoff),'LineWidth',1.5,'Color',[1 0 0 0.2]); %,SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);
    %gp = gp.Color(4) = alpha;
	g
end
ZEROLINE(1,1:1:tcutoff) = ID(1,1:tcutoff);
ZEROLINE(2,1:1:tcutoff) = 0.0;
hold on
plot(log10(ZEROLINE(1,:)),ZEROLINE(2,:),'--','LineWidth',2,'Color',[0 0 0 1.0]);
xlabel({'log10 annealing time (s)'},'FontSize',fontszcap,'FontName',fontnm);
ylabel({'v^{+grw}_{cap} (\mum/s)'},'FontSize',fontszcap,'FontName',fontnm);
grid('on')
box('on')
set(gca,'FontSize',fontszcap,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[60 30])
pbaspect([3 1 1])
set(gcf,'color','w')
xlim([0.5 4.5]);
xt = [0.5:0.5:4.5];
xticks(xt);
ylim([-0.5 0.3]);
yt = [-0.5:0.1:0.3];
yticks(yt);
print(gcf,['AGG2D_RndUnsuccessSixQuantSelection.png'],'-dpng','-r500')
close(gcf)
save('AGG2D_TrackingRndUnsuccessful_01.mat','-v7.3');



tcutoff = 9499;
alpha = 0.1;
figure('Position',[100 100 2000 1000]);
for g=1:1:25000
    hold on
    plot(log10(ID(g,1:tcutoff)),VCURV(g,1:tcutoff),'.','MarkerSize',1,'Color',[0 0 1 0.01]); %,SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);
    %gp = gp.Color(4) = alpha;
	g
end
ZEROLINE(1,1:1:tcutoff) = ID(1,1:tcutoff);
ZEROLINE(2,1:1:tcutoff) = 0.0;
hold on
plot(log10(ZEROLINE(1,:)),ZEROLINE(2,:),'--','LineWidth',2,'Color',[0 0 0 1.0]);
xlabel({'log10 annealing time (s)'},'FontSize',fontszcap,'FontName',fontnm);
ylabel({'v^{+grw}_{cap} (\mum/s)'},'FontSize',fontszcap,'FontName',fontnm);
grid('on')
box('on')
set(gca,'FontSize',fontszcap,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[60 30])
pbaspect([2 1 1])
set(gcf,'color','w')
xlim([1 5]);
xt = [0:1:5];
xticks(xt);
ylim([-0.5 0.3]);
yt = [-0.5:0.1:0.3];
yticks(yt);
print(gcf,['AGG2D_TrackingRndUnsuccessful.png'],'-dpng','-r500')
close(gcf);


%longest to survive?
find(DEADTIME == max(DEADTIME(:,1)))

plot(ID(12311,:),VCURV(12311,:));





%% animation largest grain evolves in vCap-N-Size space
id = 2601;
fname = 'AGG2DLargestGrain2601.gif';
for t=1:1000 %ncolsbk-1
    %figure(1)
    figure('Position',[100 100 1000 1000]);
    plot3(VCURV(id,1:1:t),NFACES(id,1:1:t),SZGAIN(id,1:1:t),'.');
    xlim([-0.25 0.25]);
    xt = [-0.25:0.05:0.25];
    xticks(xt);
    ylim([0 45]);
    yt = 0:5:45;
    yticks(yt);
    zlim([0 20]);
    zt = [0:2:20];
    zticks(zt);
    grid('on');
    box('on');
    set(gca,'FontSize',fontszax,'FontName',fontnm,'LineWidth',1.5);
    set(gcf,'PaperUnits','Inches');
    set(gcf,'PaperSize',[30 30]);
    set(gcf,'color','w','visible','off');
    xlabel({'v^{+grw}_{cap} (\mum/s)'},'FontSize',fontszcap,'FontName',fontnm);
    ylabel({'N_{faces}'},'FontSize',fontszcap,'FontName',fontnm);
    zlabel({'A/A^{matr}_{mean}'},'FontSize',fontszax,'FontName',fontnm);
    drawnow;
    %work with (low)res gif directly
    frame = getframe(gcf);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,65536,'nodither');
    if t ~= 1
      imwrite(imind,cm,fname,'gif','WriteMode','append', 'DelayTime', 0.05);
    else
      imwrite(imind,cm,fname,'gif', 'DelayTime',0.05,'Loopcount',inf);
    end
    close(gcf);
    t
end

%% safe Matlab state
save('AGG2D_TrackingBKvsCurv_03.mat');





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





view(-90,0)
view(0,0)

view(-49,19)
xlim([-1.0e-11 +1.0e-7])
ylim([-1.0e-11 +1.0e-7])

clearvars ans c fid i id naggr optgridcm resu_new_lineid resu_old_lineid val1 val2 val3 where;

save('PRX2D_BKLocalPropertiesEvo_Time_01.mat');

%% correlations of local properties as a function of time (grain history)
optgridcm = 0;
figure('Position',[100 100 1200 1000])
for i=1:nrows
    id = i;
    %if 1==1
    %if  mod(id,100) == 0
    %if VOLUME(id,tcutoff) == Vmax & ~isnan(CURV_SPEED(i,:))
    if VOLUME(id,tcutoff) >= 3.0*Vm %& ~isnan(CURV_SPEED(i,:))
        hold on
        %%plot3(CURV_SPEED(id,1),NFACES(id,1),SZGAIN(id,tcutoff),'.','Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        plot3(MOBDSEE(id,1:tcutoff),CURV_SPEED(id,1:tcutoff),VOLUME(id,1:tcutoff),'Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        %plot3(CURV_DRVFRC(id,1:tcutoff),NFACES(id,1:tcutoff),SZGAIN(id,1:tcutoff),'-o','Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        %plot3(NFACES(id,1:tcutoff),HAGB(id,1:tcutoff),VOLUME(id,1:tcutoff),'Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
 
        if optgridcm == 1
            for t=1:tcutoff-1
                %was a grid coarsement step done between t and t+1?
                resu_old_lineid = find(TMP(:,1)==ID(id,t));
                resu_new_lineid = find(TMP(:,1)==ID(id,t+1));
                if TMP(resu_old_lineid,4) ~= TMP(resu_new_lineid,4)
                    %resu_old_lineid
                    hold on
                    plot3(CURV_SPEED(id,t),NFACES(id,t),SZGAIN(id,t),'+','Color',[1 0 0])
                    %plot3(NFACES(id,t),HAGB(id,t),VOLUME(id,t),'+','Color',[1 0 0])
                 end
            end
        end 
    end
end
fontsz = 20;
fontnm = 'Calibri Light';
xlabel({'v_{SEE} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
ylabel({'v_{cap} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
if Dimension == 2
zlabel({'A (\mum^2)'},'FontSize',fontsz,'FontName',fontnm)
end
if Dimension == 3
zlabel({'V (\mum^3)'},'FontSize',fontsz,'FontName',fontnm)
end
%% POSITIVE DRIVING FORCES MEAN PROMOTING GROWTH NOW FOR BOTH CAP AND SEE!!!!
grid('on')
box('on')
view(-90,0)
view(0,0)
set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[20 20])
pbaspect([1 1 1])
set(gcf,'color','w')
view(-49,19)
print(gcf,['PRX2D_VolumeEvoSpeedSEEandCAP_LargestGrain.png'],'-dpng','-r500')

figure
plot(MOBDSEE(:,1),CURV_SPEED(:,1),'.','MarkerSize')
