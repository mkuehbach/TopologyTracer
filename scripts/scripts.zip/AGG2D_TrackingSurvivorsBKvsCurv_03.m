%% TopologyTracer2D3D
% AGG2D_TrackingSurvivorsBKvsCurv
% Author: m.kuehbach (at) mpie.de, 12/05/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize evolution of survivors in AGG2D in relation to topology and capillarity
% implicit function of time
clear;
clc;
format long;
digits(32);

%% user interaction
prefix_trackbk = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\TrackingParallel\TrackingBK_Resolution_1\';
prefix_tracksz = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\TrackingParallel\TrackingBK_Resolution_1\';
prefix_curvapprx = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\CurvatureEvolution\';
prefix_ngrains = 'E:\LongRangePaperFINAL\AGG2D\1Coarsening\';
surv_fn = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\TrackingParallel\TrackingBK_Resolution_1\TopoTracer2D3D.SimID.109500.ADHOCSurvivors.F.10.O.1.L.9500.GrainElimbnd.Rank.0.csv';
prefix_ce = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalysis\CurvatureEvolutionTracking\EvolutionSurvivors\';

firstbk = 10;
offsetbk = 1;
lastbk = 9500;

firstcurv = 50;
offsetcurv = 50;
lastcurv = 9500;

PhysDomainSize = 2.83592616e-3; %m
HAGBEnergy = 0.324; %J/m^2
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
ngr = 1 + 2560000;
nrowsbk = 8469;
ncolsbk = 9491;

nrowssz = nrowsbk+2;
ncolssz = ncolsbk;

nrowsce = 8469;
ncolsce = 9491;

nrowscrv = nrowsbk;
ncolscrv = (lastcurv-firstcurv)/offsetcurv + 1;

prgnm_bk = 'TopoTracer2D3D.SimID.109500.';
prgnm_sz = 'TopoTracer2D3D.SimID.109500.';
prgnm_crv = 'TopoTracer2D3D.SimID.1009550.OMP3.FID.';
prgnm_ce = 'TopoTracer2D3D.SimID.1.CapTracking.';
suffix_bk = ['.F.' num2str(firstbk) '.O.' num2str(offsetbk) '.L.' num2str(lastbk) '.NC.' ...
    num2str(ncolsbk) '.NR.' num2str(nrowsbk) '.bin'];
suffix_sz = ['.F.' num2str(firstbk) '.O.' num2str(offsetbk) '.L.' num2str(lastbk) '.NC.' ...
    num2str(ncolssz) '.NR.' num2str(nrowssz) '.bin'];
suffix_crv = '.CurvApprx.csv';
suffix_ce = ['.' num2str(firstbk) '.O.' num2str(offsetbk) '.L.' num2str(lastbk) '.NC.' ...
    num2str(ncolsce) '.NR.' num2str(nrowsce) '.bin'];


%% load backtracking grain history in memory
fileID = fopen([prefix_tracksz prgnm_sz 'SIZEGAINBK' suffix_sz]);
SIZEGAINBK = fread(fileID,[nrowssz,ncolssz],'double');
fclose(fileID);
SZGAIN(1:nrowsbk,:) = SIZEGAINBK(3:nrowssz,:);
SZMETA(1:2,:) = SIZEGAINBK(1:2,:);
SZMETA(2,:) = SZMETA(2,:) .* DomainSize;
clearvars SIZEGAINBK;

fileID = fopen([prefix_trackbk prgnm_bk 'BK.NF' suffix_bk]);
NFACES = fread(fileID,[nrowsbk,ncolsbk],'uint32');
fclose(fileID);

fileID = fopen([prefix_trackbk prgnm_bk 'BK.VOL' suffix_bk]);
VOLUME = fread(fileID,[nrowsbk,ncolsbk],'double');
fclose(fileID);

fileID = fopen([prefix_trackbk prgnm_bk 'BK.MOBDSEE' suffix_bk]);
MOBDSEE = fread(fileID,[nrowsbk,ncolsbk],'double');
fclose(fileID);

fileID = fopen([prefix_trackbk prgnm_bk 'BK.HAGB' suffix_bk]);
HAGB = fread(fileID,[nrowsbk,ncolsbk],'double');
fclose(fileID);
'Binary raw data successfully read'

%VOLUME(VOLUME == 0) = nan;
%HAGB(isnan(VOLUME)) = nan;
%NFACES(isnan(VOLUME)) = nan;
%MOBDSEE(isnan(VOLUME)) = nan;

%% translate relative into absolute sizes in micron^Dimension
for c=1:ncolsbk
    VOLUME(:,c) = VOLUME(:,c) .* DomainSize;
end
'Volume from normalized to micron^Dimension'

%% load IDs of survivors
filename = surv_fn;
delimiter = '';
startRow = 2;
formatSpec = '%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
fclose(fileID);
GID = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;
'Survivor IDs loaded'


%% load capillary track matrix
fileID = fopen([prefix_ce prgnm_ce 'VCURV' suffix_ce]);
VCURV = fread(fileID,[nrowsce,ncolsce],'double');
fclose(fileID);

fileID = fopen([prefix_ce prgnm_ce 'TSUPP' suffix_ce]);
TSUPP = fread(fileID,[nrowsce,ncolsce],'uint32');
fclose(fileID);

fileID = fopen([prefix_ce prgnm_ce 'VSUPP' suffix_ce]);
VSUPP = fread(fileID,[nrowsce,ncolsce],'uint32');
fclose(fileID);
'Capillary event matrix loaded'

%% change sign of VCURV because the rawdata define positive as shrinkage and negative as growth
VCURV = -1.0.*VCURV;
%% replace extremely high curvature measure values that indicate non-computable data with NaN
% suhc tzaht they do not become plotted
VCURV(abs(VCURV) > 1.0e100) = NaN;
% %% successively load results for curvature
% CURV_DRVFRC = nan(nrowscrv,ncolscrv);
% CURV_SPEED = nan(nrowscrv,ncolscrv);
% CURV_SUPP = nan(nrowscrv,ncolscrv);
% 
% for fid=lastcurv:-offsetcurv:firstcurv
%     %% load curvature file and analyze
%     filename = [prefix_curvapprx prgnm_crv num2str(fid) suffix_crv];
%     delimiter = ';';
%     startRow = 3;
%     formatSpec = '%f%f%f%f%f%f%f%f%f%[^\n\r]';
%     fileID = fopen(filename,'r');
%     dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
%     fclose(fileID);
%     TMP = [dataArray{1:end-1}];
%     clearvars filename delimiter startRow formatSpec fileID dataArray ans;
%     
%     %% store available curvature approximates in hash for quick assignment to grains
%     clearvars crvhash;
%     crvhash = nan(3,ngr);
%     for i=1:length(TMP(:,1))
%         gid = TMP(i,1); %grainID
%         % filtering?
%         crvhash(1,gid) = TMP(i,2); %effDrvForce w/o TJP Pa
%         crvhash(2,gid) = TMP(i,4); %effSpeed w/o TJP m/s
%         crvhash(3,gid) = TMP(i,8); %contour support w/o TJP cnt
%     end
%     clearvars TMP;
%     
%     %% assign to curv
%     for i=1:length(GID(:,1))
%         gid = GID(i,1); %ID of grain to which data in row i along the entire columns belong
%         val1 = crvhash(1,gid);
%         val2 = crvhash(2,gid);
%         val3 = crvhash(3,gid);
%         where = (fid-firstcurv)/offsetcurv+1;
%         if ~isnan(val1) && ~isnan(val2)
%             CURV_DRVFRC(i,where) = val1; %what is at the moment the driving force?
%             CURV_SPEED(i,where) = val2; %what is at the moment the speed?
%             CURV_SUPP(i,where) = val3; %is the contour still sufficiently supported by points?
%         end
%         %i
%     end
%     clearvars crvhash;
%     ['Curvature ' num2str(fid) ' read out']
% end
% 'Curvature all imported'
% 
% %% multiply curvature speed and driving force with -1.0 to enforce consistence with sign convention ...
% % for SEE driving force, positive promotes the growth of the grain!
% CURV_DRVFRC = -1.0.*CURV_DRVFRC;
% CURV_SPEED = -1.0.*CURV_SPEED;
% CURV_SPEED = CURV_SPEED .* 1.0e6; %m/s to micron/s
% signvalid = 1;
% 'Curvature data loaded successfully'
% %% POSITIVE DRIVING FORCES MEAN PROMOTING GROWTH NOW FOR BOTH CAP AND SEE!!!!
% 
% %% given that curvature is sampled more coarsely we have to draw subset of entire trajectory...
% for c=1:1:ncolscrv
%     f = 1 + firstcurv + (c-1)*offsetcurv - firstbk; %##MK::assuming offsetbk = 1
%     cSZGAIN(:,c) = SZGAIN(:,f);
%     cNFACES(:,c) = NFACES(:,f);
% end
% 'Projected data for sizegain and backwards tracking to curvature'
% 
% %% do not report grains for which the number of supporting points for the estimation 
% % of the curvature falls below a certain threshold

%% load realtime
filename = [prefix_ngrains 'NrGrains&EnergyStatistics.txt'];
delimiter = '\t';
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN, 'ReturnOnError', false);
fclose(fileID);
TMP = [dataArray{1:end-1}];
clearvars filename delimiter formatSpec fileID dataArray ans;

%% set up ID vector as a tool to allowing plotting
ID = zeros(nrowsbk,ncolsbk);
for t=1:ncolsbk
    ID(:,t) = TMP(firstbk+(t-1)*offsetbk,1);
end
'Real time loaded'
clearvars TMP;

%% find column index of last snapshot before population becomes insignificant
tcutoff = ncolsbk-1;
Vm = mean(VOLUME(:,tcutoff));
Vmax = max(VOLUME(:,tcutoff));
[num2str(Vm) ' micron^Dim mean  ' num2str(Vmax) ' micron^Dim max']
% when does the first abnormal grain appear?

%load('AGG2D_TrackingBKvsCurv_01.mat');

fontszcap = 26;
fontszax = 26;
fontnm = 'Calibri Light';

% %% plot evolution of VCURV relative to matrix excluding survivors
% plot(log10(ID(1,:)),log10(SZMETA(1,:)),'.')
% xlabel({'log10 Annealing time (s)'},'FontSize',fontsz,'FontName',fontnm)
% ylabel({'log10 Matrix excl surv remaining'},'FontSize',fontsz,'FontName',fontnm)
% plot(log10(ID(2,:)),SZMETA(2,:),'.')
% xlabel({'log10 Annealing time (s)'},'FontSize',fontsz,'FontName',fontnm)
% if Dimension==2
% ylabel({'Matrix excl surv average (\mum^2)'},'FontSize',fontsz,'FontName',fontnm)
% end
% if Dimension==3
% ylabel({'Matrix excl surv average (\mum^3)'},'FontSize',fontsz,'FontName',fontnm)
% end
% %% safe Matlab state
% save('AGG2D_TrackingBKvsCurv_01.mat');

%% plotting order in ascending sizegain to enforce stacking of transparent lines per grain
gmax = find( VOLUME(:,ncolsbk)==max(VOLUME(:,ncolsbk)) );
%cut=190-1;
PLOTORDER = zeros(nrowsbk,2);
%PLOTORDER(:,1) = cSZGAIN(:,cut); %MaximumSizeGain
PLOTORDER(:,1) = SZGAIN(:,ncolssz-1); 
PLOTORDER(:,2) = 1:1:nrowsbk; %LineID
PLOTORDER = sortrows(PLOTORDER,1);

tcutoff = 9400;
alpha = 0.1;
figure('Position',[100 100 1000 1000]);
%hold('on')
for g=nrowsbk:-1:nrowsbk-49
    id = PLOTORDER(g,2);
    hold on
    plot3(VCURV(id,1:tcutoff),NFACES(id,1:tcutoff),SZGAIN(id,1:tcutoff),'LineWidth',3,'Color',[0 0 1 alpha]); %'.','Color',[0 0 1]); % %alpha]);
    %gp = gp.Color(4) = alpha;
    id
end
%gl = plot3(xmax(1,1:cut),ymax(1,1:cut),zmax(1,1:cut),'-','MarkerSize',9,'Color',[1 0 0]);
%gl.Color(4) = alpha;
%         gx = plot3(xmax(1,1:cut),cNFACES(id,1:cut),cSZGAIN(id,1:cut),'.','MarkerSize',4,'Color',[1 0 0]);
%         gx.Color(4) = 0.1;  
%         gy = plot3(CURV_SPEED(id,1:cut),ymax(1,1:cut),cSZGAIN(id,1:cut),'.','MarkerSize',4,'Color',[0 1 0]);
%         gy.Color(4) = 0.1;
%         gz = plot3(CURV_SPEED(id,1:cut),cNFACES(id,1:cut),zmax(1,1:cut),'.','MarkerSize',4,'Color',[1 1 0]);
%         gz.Color(4) = 0.1;  
ZEROLINE(1,1:1:121) = 0.0; %along zero velocity 
ZEROLINE(2,1:1:121) = 0:1:120; %faces
ZEROLINE(3,1:1:121) = 0.0; %size
hold on
plot3(ZEROLINE(1,:),ZEROLINE(2,:),ZEROLINE(3,:),'--','LineWidth',2,'Color',[0 0 0 1.0]);
xlabel({'v^{+grw}_{cap} (\mum/s)'},'FontSize',fontszcap,'FontName',fontnm);
ylabel({'N_{faces}'},'FontSize',fontszcap,'FontName',fontnm);
if Dimension == 2
zlabel({'A/A^{matr}_{mean}'},'FontSize',fontszax,'FontName',fontnm)
end
if Dimension == 3
zlabel({'V/V^{matr}_{mean})'},'FontSize',fontszax,'FontName',fontnm)
end
grid('on')
box('on')
view(-45,17)
view(-31,13)
set(gca,'FontSize',fontszcap,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[30 30])
pbaspect([1 1 1])
set(gcf,'color','w')
xlim([-0.5 0.3]);
xt = [-0.5:0.10:0.3];
xticks(xt);
ylim([0 120]);
yt = [0:20:120];
yticks(yt);
print(gcf,['AGG2D_TrackingBKvsCurv_03_50Largest.png'],'-dpng','-r500')
close(gcf);


%% animation largest grain evolves in vCap-N-Size space
id = 2601;
fname = 'AGG2DLargestGrain2601.gif';
for t=1:1000 %ncolsbk-1
    %figure(1)
    figure('Position',[100 100 1000 1000]);
    plot3(VCURV(id,1:1:t),NFACES(id,1:1:t),SZGAIN(id,1:1:t),'.');
    xlim([-0.25 0.25]);
    xt = [-0.25:0.05:0.25];
    xticks(xt);
    ylim([0 45]);
    yt = 0:5:45;
    yticks(yt);
    zlim([0 20]);
    zt = [0:2:20];
    zticks(zt);
    grid('on');
    box('on');
    set(gca,'FontSize',fontszax,'FontName',fontnm,'LineWidth',1.5);
    set(gcf,'PaperUnits','Inches');
    set(gcf,'PaperSize',[30 30]);
    set(gcf,'color','w','visible','off');
    xlabel({'v^{+grw}_{cap} (\mum/s)'},'FontSize',fontszcap,'FontName',fontnm);
    ylabel({'N_{faces}'},'FontSize',fontszcap,'FontName',fontnm);
    zlabel({'A/A^{matr}_{mean}'},'FontSize',fontszax,'FontName',fontnm);
    drawnow;
    %work with (low)res gif directly
    frame = getframe(gcf);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,65536,'nodither');
    if t ~= 1
      imwrite(imind,cm,fname,'gif','WriteMode','append', 'DelayTime', 0.05);
    else
      imwrite(imind,cm,fname,'gif', 'DelayTime',0.05,'Loopcount',inf);
    end
    close(gcf);
    t
end

%% safe Matlab state
save('AGG2D_TrackingBKvsCurv_03.mat');





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





view(-90,0)
view(0,0)

view(-49,19)
xlim([-1.0e-11 +1.0e-7])
ylim([-1.0e-11 +1.0e-7])

clearvars ans c fid i id naggr optgridcm resu_new_lineid resu_old_lineid val1 val2 val3 where;

save('PRX2D_BKLocalPropertiesEvo_Time_01.mat');

%% correlations of local properties as a function of time (grain history)
optgridcm = 0;
figure('Position',[100 100 1200 1000])
for i=1:nrows
    id = i;
    %if 1==1
    %if  mod(id,100) == 0
    %if VOLUME(id,tcutoff) == Vmax & ~isnan(CURV_SPEED(i,:))
    if VOLUME(id,tcutoff) >= 3.0*Vm %& ~isnan(CURV_SPEED(i,:))
        hold on
        %%plot3(CURV_SPEED(id,1),NFACES(id,1),SZGAIN(id,tcutoff),'.','Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        plot3(MOBDSEE(id,1:tcutoff),CURV_SPEED(id,1:tcutoff),VOLUME(id,1:tcutoff),'Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        %plot3(CURV_DRVFRC(id,1:tcutoff),NFACES(id,1:tcutoff),SZGAIN(id,1:tcutoff),'-o','Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        %plot3(NFACES(id,1:tcutoff),HAGB(id,1:tcutoff),VOLUME(id,1:tcutoff),'Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
 
        if optgridcm == 1
            for t=1:tcutoff-1
                %was a grid coarsement step done between t and t+1?
                resu_old_lineid = find(TMP(:,1)==ID(id,t));
                resu_new_lineid = find(TMP(:,1)==ID(id,t+1));
                if TMP(resu_old_lineid,4) ~= TMP(resu_new_lineid,4)
                    %resu_old_lineid
                    hold on
                    plot3(CURV_SPEED(id,t),NFACES(id,t),SZGAIN(id,t),'+','Color',[1 0 0])
                    %plot3(NFACES(id,t),HAGB(id,t),VOLUME(id,t),'+','Color',[1 0 0])
                 end
            end
        end 
    end
end
fontsz = 20;
fontnm = 'Calibri Light';
xlabel({'v_{SEE} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
ylabel({'v_{cap} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
if Dimension == 2
zlabel({'A (\mum^2)'},'FontSize',fontsz,'FontName',fontnm)
end
if Dimension == 3
zlabel({'V (\mum^3)'},'FontSize',fontsz,'FontName',fontnm)
end
%% POSITIVE DRIVING FORCES MEAN PROMOTING GROWTH NOW FOR BOTH CAP AND SEE!!!!
grid('on')
box('on')
view(-90,0)
view(0,0)
set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[20 20])
pbaspect([1 1 1])
set(gcf,'color','w')
view(-49,19)
print(gcf,['PRX2D_VolumeEvoSpeedSEEandCAP_LargestGrain.png'],'-dpng','-r500')

figure
plot(MOBDSEE(:,1),CURV_SPEED(:,1),'.','MarkerSize')
