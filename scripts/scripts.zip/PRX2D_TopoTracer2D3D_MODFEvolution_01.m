%% TopologyTracer2D3D
% PRX3D_MODFEvolution
% Author: m.kuehbach (at) mpie.de, 09/07/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize eovlution of disorientation angle distribution
clear;
clc;
format long;
digits(32);

%% user interaction
prefix_track = 'E:\LongRangePaperFINAL\PRX3D\2DataAnalysis\TrackingParallel\';
first = 10;
offset = 1;
last = 1000;
simid = 1;
PhysDomainSize = 4.2037e-3; %meter
HAGBEnergy = 1.000; %J/m^2
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
LargestGrainID = 9900000;

ncols = 1992;
nrows = 630;

%% end of user interaction

%% load MODF
prgnm = ['TopoTracer2D3D.SimID.' num2str(simid) '.'];
suffix = ['.F.' num2str(first) '.O.' num2str(offset) '.L.' num2str(last) '.NC.' ...
    num2str(ncols) '.NR.' num2str(nrows) '.bin'];

%% load backtracking grain history in memory
fileID = fopen([prefix_track prgnm 'MODF' suffix]);
MODF = fread(fileID,[nrows,ncols],'double');
fclose(fileID);
MODF(nrows,:) = [];
'Binary raw data successfully read'

fontsz = 22;
fontnm = 'Calibri Light';
figure('Position',[100 100 1200 1000])
hold('on')
%MACKENZIE=zeros(24,2);
%plot(MACKENZIE(:,1),MACKENZIE(:,2),'--','Color',[1 0 0],'LineWidth',1);
for fid=first:1:last
  if fid == first || fid == last
        plot(MODF(:,1),MODF(:,1+1+fid-first),'-','Color',[0 0 1],'LineWidth',2);
        %color = parula;
  end
end
xlabel({'Disorientation angle \Theta (^{\circ})'},'FontSize',fontsz,'FontName',fontnm);
ylabel({'CDF'},'FontSize',fontsz,'FontName',fontnm);
%projections
grid('on');
box('on');
set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5);
set(gcf,'PaperUnits','Inches');
set(gcf,'PaperSize',[30 30]);
pbaspect([1 1 1]);
set(gcf,'color','w');
%colorbar;
xlim([0 62.8]);
xt = [0:5.0:62.8];
xticks(xt);
ylim([-0.02 1.02]);
yt = [0:0.1:1.0];
yticks(yt);
print(gcf,['PRX2D_MODFEvolution_01.png'],'-dpng','-r500');
close(gcf);
save('PRX2D_MODFEvolution_01.mat');

