%% TopologyTracer2D3D
% PRX2D_MaxSzGainBKvsCompetitivenessvsLocalFeatures
% Author: m.kuehbach (at) mpie.de, 09/07/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize all grains maximum size until disappearance or survival
% and set into relation to arrival time competition in environment 
clear;
clc;
format long;
digits(32);

%% user interaction
prefix_trackbk = 'E:\LongRangePaperFINAL\PRX2D\2DataAnalysis\TrackingParallel\TrackingFW_Resolution_1\1010\';
prefix_comp = 'E:\LongRangePaperFINAL\PRX2D\2DataAnalysis\UnbiasedGrowthMeasures\';
firstlr = 100;
offsetlr = 100;
lastlr = 2000;
firstbk = 10;
offsetbk = 1;
lastbk = 10;
simidbk = 1010;
simidlr = 1005200;
PhysDomainSize = 4.2037e-3; %meter
HAGBEnergy = 1.000; %J/m^2
Dimension = 2;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
rclass = 3;
LargestGrainID = 9900000;

%% load competetive

%% end of user interaction
%% load forward tracking data for all grains up to timestep 50
ncolsbk = 1;
nrowsbk = 9808951;
prgnm_bk = ['TopoTracer2D3D.SimID.' num2str(simidbk) '.'];
suffix_bk = ['.F.' num2str(firstbk) '.O.' num2str(offsetbk) '.L.' num2str(lastbk) '.NC.' ...
    num2str(ncolsbk) '.NR.' num2str(nrowsbk) '.bin'];

%% load backtracking grain history in memory
fileID = fopen([prefix_trackbk prgnm_bk 'FW.NF' suffix_bk]);
NFACES = fread(fileID,[nrowsbk,ncolsbk],'uint32');
fclose(fileID);
fileID = fopen([prefix_trackbk prgnm_bk 'FW.VOL' suffix_bk]);
VOLUME = fread(fileID,[nrowsbk,ncolsbk],'double');
fclose(fileID);
fileID = fopen([prefix_trackbk prgnm_bk 'FW.MOBDSEE' suffix_bk]);
MOBDSEE = fread(fileID,[nrowsbk,ncolsbk],'double');
fclose(fileID);
fileID = fopen([prefix_trackbk prgnm_bk 'FW.HAGB' suffix_bk]);
HAGB = fread(fileID,[nrowsbk,ncolsbk],'double');
fclose(fileID);
'Binary raw data successfully read'

NFACES(find(NFACES==0))=nan;
VOLUME(find(VOLUME==0))=nan;
HAGB(find(HAGB==0))=nan;
MOBDSEE(find(MOBDSEE==0))=nan;

%volume to micron
VOLUME = VOLUME .* DomainSize;
MOBDSEE = MOBDSEE .* 1.0e6; %m/s to micron/s

%% load maximum size gain ever
filename = 'E:\LongRangePaperFINAL\PRX2D\2DataAnalysis\TrackingParallel\TrackingFW_Resolution_1\102000\TopoTracer2D3D.SimID.102000.MaxSizeGainFW.F.10.O.1.L.2000.csv';
delimiter = ';';
startRow = 3;
formatSpec = '%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
fclose(fileID);
MAXSZ = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;

ngr = 1 + LargestGrainID;
%build size gain hash
szhash = nan(1,ngr);
for i=1:length(MAXSZ(:,1))
    gid = MAXSZ(i,1);
    szhash(1,gid) = MAXSZ(i,2);
end
'MaxSzHash build'

% load grainID to get mapping of row to grainIDs
filename = 'E:\LongRangePaperFINAL\PRX2D\2DataAnalysis\TrackingParallel\TrackingFW_Resolution_1\1010\TopoTracer2D3D.SimID.1010.ADHOCMatrix.All.GrainsElimbnd.Rank.0.csv';
delimiter = {''};
startRow = 2;
formatSpec = '%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
fclose(fileID);
GID = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;
'GID loaded...'
%% fill GID with maximum size gain
ng = length(GID(:,1));
for g=1:ng
    GID(g,2) = szhash(1,GID(g,1));
    g
end
save('PRX2D_MaxSzGainFWvsCOMPvsLocalEnv_01.mat');
%load('PRX2D_MaxSzGainFWvsCOMPvsLocalEnv_01.mat');

%% analyze evolution of correlation local v
nbin=10;
mxsz_vs_hagb = nan(nbin,ncolsbk);
mxsz_vs_nf = nan(nbin,ncolsbk);
mxsz_vs_mob = nan(nbin,ncolsbk);
for c=1:1:ncolsbk
    for bin=1:1:nbin
        left = (bin-1)*(1/nbin);
        right = bin*(1/nbin);
        cand = GID(find(HAGB(~isnan(HAGB(:,c)),c)>left & HAGB(~isnan(HAGB(:,c)),c)<=right),1); %candidate grainIDs
        mxsz_vs_hagb(bin,c) = max(szhash(1,transpose(cand)));
        clearvars cand; 
        %cand = GID(find(NFACES(~isnan(NFACES(:,c)),c)>left & NFACES(~isnan(NFACES(:,c)),c)<=right),1);
        %mxsz_vs_nf(bin,c) = max(szhash(1,transpose(cand)));
        %clearvars cand;
        %cand = GID(find(MOBDSEE(~isnan(MOBDSEE(:,c)),c)>left & MOBDSEE(~isnan(MOBDSEE(:,c)),c)<=right),1);
        %mxsz_vs_nf(bin,c) = max(szhash(1,transpose(cand)));
        %clearvars cand;
    end
    c
end

fontszcap = 26;
fontszax = 26;
fontnm = 'Calibri Light';
figure('Position',[100 100 1000 1000])
hold('on')
plot(HAGB(:,1),log10(GID(:,2)),'.','MarkerSize',9.0,'Color',[0 0 1]);
xlabel({'HAGB fraction'},'FontSize',fontszcap,'FontName',fontnm);
if Dimension==2
ylabel({'log10 maximum area achieved (\mum^2)'},'FontSize',fontszcap,'FontName',fontnm);
end
if Dimension==3
ylabel({'log10 maximum volume achieved (\mum^2)'},'FontSize',fontszcap,'FontName',fontnm);
end    
grid('on');
box('on');
set(gca,'FontSize',fontszax,'FontName',fontnm,'LineWidth',1.5);
set(gcf,'PaperUnits','Inches');
set(gcf,'PaperSize',[30 30]);
pbaspect([1 1 1]);
set(gcf,'color','w');
xlim([-0.02 1.02])
xt = [0:0.1:1.0];
xticks(xt);
ylim([-1 5])
yt = [-1:1:5];
yticks(yt);

print(gcf,['PRX2D_MaxSzGainBKvsHAGB.FID.10.png'],'-dpng','-r500');
close(gcf);


    

%%%%######################################################
%%%%######################################################
%%%%######################################################
%%%%######################################################
%%%%######################################################





% build hash for maintaining
ngr = 1+LargestGrainID;
nfsumhash = nan(1,ngr);
for r=1:length(NFACES(:,1))
    gid = GID(r,1);
    nfsumhash(1,gid) = sum(NFACES(r,:)); %maintained high number of faces
end

%% map sum of NFACES in relation to Competitiveness
for i=1:length(COMP(:,1));
    gid = COMP(i,1);
    COMP(i,5) = nfsumhash(1,gid);
end

plot3(COMP(:,3),COMP(:,5),COMP(:,4),'.')


for fid=firstlr:1:firstlr
        %% load competitiveness file
        filename = [prefix_comp 'TopoTracer2D3D.SimID.' num2str(simid) '.Competitiveness.FID.' num2str(fid) '.csv'];
        delimiter = ';';
        startRow = 2;
        formatSpec = '%f%f%f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
        fclose(fileID);
        COMP = [dataArray{1:end-1}];
        clearvars filename delimiter startRow formatSpec fileID dataArray ans;
   
        
        fontsz = 22;
        fontnm = 'Calibri Light';
        figure('Position',[100 100 1200 1000])
        hold('on')
        color = parula;
        plot3(COMP(:,3),COMP(:,5),COMP(:,4),'.','Color',[0 0 1]);
        %h = histogram2(COMP(:,3),log10(COMP(:,4)),'BinMethod','fd','Normalization','probability','DisplayStyle','tile','ShowEmptyBins','off');
        xlabel({'\Sigma t_i/t_j'},'FontSize',fontsz,'FontName',fontnm);
        ylabel({'\Sigma^{50}_{10} N_{faces}'},'FontSize',fontsz,'FontName',fontnm);
        zlabel({'log10 maximum area achieved (\mum^2)'},'FontSize',fontsz,'FontName',fontnm);
        %projections
        fixed = reshape(repmat(550,1,length(COMP(:,1))),[length(COMP(:,1)),1]);
        gp = plot3(COMP(:,3),fixed,COMP(:,4),'.','Color',color(45,:));
        gp.Color(4) = 0.01;
        fixed = reshape(repmat(6,1,length(COMP(:,1))),[length(COMP(:,1)),1]);
        gp = plot3(fixed,COMP(:,5),COMP(:,4),'.','Color',color(45,:));
        gp.Color(4) = 0.01;
        grid('on');
        box('on');
        set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5);
        set(gcf,'PaperUnits','Inches');
        set(gcf,'PaperSize',[30 30]);
        pbaspect([1 1 1]);
        set(gcf,'color','w');
        %colorbar;
        view(-54,14);
        xlim([0 6])
        xt = [0:1.0:6];
        xticks(xt);
        ylim([50 550])
        yt = [50:50:550];
        yticks(yt);
        print(gcf,['AGG2D_MaxSzGainFWvsCOMPvsNFaces_01.png'],'-dpng','-r500');
        close(gcf);

        clearvars h;
        ['Processed ' num2str(fid)]
end
save('AGG2D_MaxSzGainFWvsCOMPvsNFACES_01.mat');

