%% TopologyTracer2D3D
% PRX3D_MODFEvolution
% Author: m.kuehbach (at) mpie.de, 09/07/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize eovlution of disorientation angle distribution
clear;
clc;
format long;
digits(32);
load('MacKenzieDistroOriginal1958.mat','MACKENZIE');

%% original MacKenzie distribution pdf(\Psi)
% i=1;
% for p=0.1/180.0*pi:0.1/180.0*pi:62.8/180.0*pi
%     sq21 = (2^0.5) - 1;
%     ct = cot(0.5*p);
%     %ct = ct/180.0*pi;
%     X = sq21 / (1 - (sq21)^2 * ct^2)^0.5;
%     Y = sq21^2 / (3-ct^2)^0.5;
%     a = (2/15)* ( (3*sq21 + 4/(3^0.5))*sin(p) - 6*(1-cos(p)) );
%     b = -8/5*pi* ( 2*sq21*acos(X*ct) + (1/(3^0.5))*acos(Y*ct) ) * sin(p);
%     c = +8/5*pi* (2*acos( ((2^0.5)+1)*X/(2^0.5)) + acos(((2^0.5)+1)*Y/(2^0.5)))*(1-cos(p));
%     pdf_p = a + b + c;
%     MacKenzie(i,1) = p; %deg
%     MacKenzie(i,2) = real(pdf_p);
%     i = i+1;
% end
    
    


%% user interaction
prefix_track = 'E:\LongRangePaperFINAL\PRX3D\2DataAnalysis\TrackingParallel\';
first = 10;
offset = 1;
last = 1000;
simid = 101000;
PhysDomainSize = 1.16e-4; %meter
HAGBEnergy = 0.324; %J/m^2
Dimension = 3;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
LargestGrainID = 500000;

ncols = 992;
nrows = 630; %because struct of 5 contiguous doubles


%% end of user interaction

%% load MODF
prgnm = ['TopoTracer2D3D.SimID.' num2str(simid) '.'];
suffix = ['.F.' num2str(first) '.O.' num2str(offset) '.L.' num2str(last) '.NC.' ...
    num2str(ncols) '.NR.' num2str(nrows) '.bin'];

%% load backtracking grain history in memory
fileID = fopen([prefix_track prgnm 'MODF' suffix]);
MODF = fread(fileID,[nrows,ncols],'double');
fclose(fileID);
MODF(nrows,:) = [];
nrows = nrows-1;
'Binary raw data successfully read'

fontsz = 22;
fontnm = 'Calibri Light';
figure('Position',[100 100 1200 1000])
hold('on')
%MACKENZIE=zeros(24,2);
plot(MACKENZIE(:,1),MACKENZIE(:,2),'--','Color',[1 0 0],'LineWidth',1);
for fid=first:1:last
  if fid == first || fid == last
        plot(MODF(:,1),MODF(:,1+1+fid-first),'-','Color',[0 0 1],'LineWidth',2);
        %color = parula;
  end
end
xlabel({'Disorientation angle \Theta (^{\circ})'},'FontSize',fontsz,'FontName',fontnm);
ylabel({'CDF'},'FontSize',fontsz,'FontName',fontnm);
%projections
grid('on');
box('on');
set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5);
set(gcf,'PaperUnits','Inches');
set(gcf,'PaperSize',[30 30]);
pbaspect([1 1 1]);
set(gcf,'color','w');
%colorbar;
xlim([0 62.8]);
xt = [0:5.0:62.8];
xticks(xt);
ylim([-0.02 1.02]);
yt = [0:0.1:1.0];
yticks(yt);
print(gcf,['PRX3D_MODFEvolution_01.png'],'-dpng','-r500');
close(gcf);
save('PRX3D_MODFEvolution_01.mat');