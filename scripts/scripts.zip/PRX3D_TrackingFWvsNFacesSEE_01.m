%% TopologyTracer2D3D
% PRX3D_TrackingFWvsNFacesSEE
% Author: m.kuehbach (at) mpie.de, 09/07/2017
% MinRequirement: Matlab v2017a
% Purpose: visualize evolution of successful grains as 
% a function of time in relation current HAGB, nfaces
clear;
clc;
format long;
digits(32);

%% user interaction
prefix_trackfw = 'E:\LongRangePaperFINAL\PRX3D\2DataAnalysis\TrackingParallel\';
prefix_tracksz = 'E:\LongRangePaperFINAL\PRX3D\2DataAnalysis\TrackingParallel\';
prefix_ngrains = 'E:\LongRangePaperFINAL\PRX3D\1Coarsening\';
surv_fn = 'E:\LongRangePaperFINAL\PRX3D\2DataAnalysis\TrackingParallel\TopoTracer2D3D.SimID.101000.FW.All.GrainsElimbnd.Rank.0.csv';

firstfw = 10;
offsetfw = 1;
lastfw = 1000;
simid = 101000;
PhysDomainSize = 1.16e-4; %meter
HAGBEnergy = 0.324; %J/m^2
Dimension = 3;
DomainSize = (PhysDomainSize/1.0e-6)^Dimension;
LargestGrainID = 500000;

nrowsfw = 461823;
ncolsfw = 991;

nrowssz = nrowsfw+2;
ncolssz = ncolsfw;

%%nrowscrv = nrowsbk;
%%ncolscrv = (lastcurv-firstcurv)/offsetcurv + 1;

prgnm_fw = 'TopoTracer2D3D.SimID.101000.';
prgnm_sz = 'TopoTracer2D3D.SimID.101000.';
suffix_fw = ['.F.' num2str(firstfw) '.O.' num2str(offsetfw) '.L.' num2str(lastfw) '.NC.' ...
    num2str(ncolsfw) '.NR.' num2str(nrowsfw) '.bin'];
suffix_sz = ['.F.' num2str(firstfw) '.O.' num2str(offsetfw) '.L.' num2str(lastfw) '.NC.' ...
    num2str(ncolssz) '.NR.' num2str(nrowssz) '.bin'];

%% load backtracking grain history in memory
% fileID = fopen([prefix_tracksz prgnm_sz 'SIZEGAINBK' suffix_sz]);
% SIZEGAINBK = fread(fileID,[nrowssz,ncolssz],'double');
% SZGAIN(1:nrowsbk,:) = SIZEGAINBK(3:nrowssz,:);
% SZMETA(1:2,:) = SIZEGAINBK(1:2,:);
% SZMETA(2,:) = SZMETA(2,:) .* DomainSize;
% clearvars SIZEGAINBK;
% fclose(fileID);

fileID = fopen([prefix_trackfw prgnm_fw 'FW.NF' suffix_fw]);
NFACES = fread(fileID,[nrowsfw,ncolsfw],'uint32');
fclose(fileID);

fileID = fopen([prefix_trackfw prgnm_fw 'FW.VOL' suffix_fw]);
VOLUME = fread(fileID,[nrowsfw,ncolsfw],'double');
fclose(fileID);

fileID = fopen([prefix_trackfw prgnm_fw 'FW.MOBDSEE' suffix_fw]);
MOBDSEE = fread(fileID,[nrowsfw,ncolsfw],'double');
fclose(fileID);

% fileID = fopen([prefix_trackfw prgnm_fw 'FW.HAGB' suffix_fw]);
% HAGB = fread(fileID,[nrowsfw,ncolsfw],'double');
% fclose(fileID);
'Binary raw data successfully read'

%fill zeros with n
NFACES(find(NFACES==0.0))=nan;
VOLUME(find(VOLUME==0.0))=nan;
MOBDSEE(find(MOBDSEE==0.0))=nan;
'Replaced 0.0 indicating grain disappearance with nan'

%% translate relative into absolute sizes in micron^Dimension
MOBDSEE = MOBDSEE .* 1.0e6; %m to micron
VOLUME = VOLUME .* DomainSize;
'Volume from normalized to micron^Dimension'

%% load IDs of survivors
filename = surv_fn;
delimiter = '';
startRow = 2;
formatSpec = '%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
fclose(fileID);
GID = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;
'Survivor IDs loaded'

%% load realtime
filename = [prefix_ngrains 'NrGrains&EnergyStatistics.txt'];
delimiter = '\t';
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN, 'ReturnOnError', false);
fclose(fileID);
TMP = [dataArray{1:end-1}];
clearvars filename delimiter formatSpec fileID dataArray ans;


%% set up ID vector as a tool to allowing plotting
ID = zeros(nrowsfw,ncolsfw);
for t=1:ncolsfw
    ID(:,t) = TMP(firstfw+(t-1)*offsetfw,1);
end
'Real time loaded'
clearvars TMP;

%% find column index of last snapshot before population becomes insignificant
cut = ncolsfw-1;
Vm = mean(VOLUME(:,cut));
Vmax = max(VOLUME(:,cut));
[num2str(Vm) ' micron^Dim mean  ' num2str(Vmax) ' micron^Dim max']
% when does the first abnormal grain appear?

% %% plot evolution size relative to matrix excluding survivors
% plot(log10(ID(1,:)),log10(SZMETA(1,:)),'.')
% xlabel({'log10 Annealing time (s)'},'FontSize',fontsz,'FontName',fontnm)
% ylabel({'log10 Matrix excl surv remaining'},'FontSize',fontsz,'FontName',fontnm)
% 
% plot(log10(ID(2,:)),SZMETA(2,:),'.')
% xlabel({'log10 Annealing time (s)'},'FontSize',fontsz,'FontName',fontnm)
% if Dimension==2
% ylabel({'Matrix excl surv average (\mum^2)'},'FontSize',fontsz,'FontName',fontnm)
% end
% if Dimension==3
% ylabel({'Matrix excl surv average (\mum^3)'},'FontSize',fontsz,'FontName',fontnm)
% end
% 
% %% safe Matlab state
% save('PRX3D_TrackingFWvsNFacesvsCurv_01.mat');

%% plotting order to enforce stacking of transparent lines per grain

%% build max size ever, works because each timestep was tracked
MAXSZ = zeros(nrowsfw,1);
for r=1:nrowsfw
    MAXSZ(r,1) = max(VOLUME(r,:)); %max(VOLUME(r,~isnan(VOLUME(r,:))));
    r
end

fontszcap = 26;
fontszax = 26;
fontnm = 'Calibri Light';
cut=ncolsfw-1;

PLOTORDER = zeros(nrowsfw,2);
PLOTORDER(:,1) = MAXSZ(:,1); %MaximumSizeGain
PLOTORDER(:,2) = 1:1:nrowsfw; %LineID
PLOTORDER = sortrows(PLOTORDER,1);

alpha = 0.2;
figure('Position',[100 100 1000 1000]);
hold('on');
xlabel({'m\cdot0.5Gb^2\cdot\Delta\rho (\mum/s)'},'FontSize',fontszcap,'FontName',fontnm)
ylabel({'N_{faces}'},'FontSize',fontszcap,'FontName',fontnm)
if Dimension == 2
zlabel({'log10 A (\mum^2)'},'FontSize',fontszcap,'FontName',fontnm)
end
if Dimension == 3
zlabel({'log10 V (\mum^3)'},'FontSize',fontszcap,'FontName',fontnm)
end
grid('on')
box('on')
view(20,12)

%sorted list of grain sizes
%-50 / +50 about 25% quantile of final sizes
color = parula;

ncolor = 64;
colorbar;
%h = colorbar;
%set( h, 'YDir', 'reverse' );
quant=0.25;
for g=int32((461763*quant)-50):1:int32((461763*quant)+50) %hardcoded because grains which died prior 10
    id = PLOTORDER(g,2);
    gp = plot3(MOBDSEE(id,1:cut),NFACES(id,1:cut),log10(VOLUME(id,1:cut)),'LineWidth',3,'Color',color(1+(1-0.25)*64,:)); %[0 0 1]); %alpha]);
    gp.Color(4) = alpha;
end

quant=0.5;
for g=int32((461763*quant)-50):1:int32((461763*quant)+50)
    id = PLOTORDER(g,2);
    gp = plot3(MOBDSEE(id,1:cut),NFACES(id,1:cut),log10(VOLUME(id,1:cut)),'LineWidth',3,'Color',color(1+(1-0.50)*64,:)); %[0 0 1]); %alpha]);
    gp.Color(4) = alpha;
end

quant=0.75;
for g=int32((461763*quant)-50):1:int32((461763*quant)+50)
    id = PLOTORDER(g,2);
    gp = plot3(MOBDSEE(id,1:cut),NFACES(id,1:cut),log10(VOLUME(id,1:cut)),'LineWidth',3,'Color',color(1+(1-0.75)*64,:)); %[0 0 1]); %alpha]);
    gp.Color(4) = alpha;
end

%100largest in color parula color(0,:)
for g=int32(461763-100):461763 %hardcoded because grains which died prior 10
    id = PLOTORDER(g,2);
    gp = plot3(MOBDSEE(id,1:cut),NFACES(id,1:cut),log10(VOLUME(id,1:cut)),'LineWidth',3,'Color',color(1+(1-1)*64,:)); %[0 0 1]); %alpha]);
    gp.Color(4) = alpha;
end

zmi = -1;
zmx = 4.5;
ymi = 0;
ymx = 55;
xmi = -0.02;
xmx = +0.02;

set(gca,'FontSize',fontszax,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[30 30])
pbaspect([1 1 1])
set(gcf,'color','w')
zlim([zmi zmx]);
zt = [-1:1:4];
zticks(zt);
ylim([ymi ymx]);
yt = [0:10:40];
yticks(yt);
xlim([xmi xmx]);
xt = [-0.02:0.01:0.02];
xticks(xt);
print(gcf,['PRX3D_TrackingFW_VOLUMEvsLocalConditions.png'],'-dpng','-r500')
close(gcf);

%% safe Matlab state
save('PRX3D_TrackingFW_VOLUMEvsLocalConditions_01.mat','-v7.3');

load('PRX3D_TrackingFW_VOLUMEvsLocalConditions_01.mat');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

