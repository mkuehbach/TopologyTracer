%% TopoTracer2D3D_SpatialDistrArrivalTime_01_AGG2D
% Author: m.kuehbach (at) mpie.de, 09/01/2017 
% Requirement: Matlab v2015a
% Purpose: given a chi/xi value for each sub-grain, i.e. a measure of the
% expected migration speed / driving force in a spherical/circular region
% about the initial barycenter how is the spatial arrangement and density
% of neighboring sub-grains, what is their chi value?
% Can we, based on this point pattern in R^3 with chi as utilize
% an arrival time scheme to weight the propensity/i.e. identify abnormal
% grain growth hotspots in the structure a priori and strongly correlated
% to the volume evolution?
% key idea, take points p_i with inspection region completely in map
% for these determine all neighbors in inspection volume and compute 
% \tau_j = ||r_ij||/chi_j and \tau_i = ||r_ij||/chi_i, if \tau_j >> \tau_i
% grain j cannot consume matrix along the growth trajectory than i --- the central
% grain, is and if so how is then the concentration and profile of high \tau_j >> \tau_i value pairs
% correlated with the size evolution of sub-grains starting from p_i and how stable over time is this correlation
% quantitatively?

clear;
clc;
format long;
digits(32);

% generate point pattern by loading barycenter location of all sub-grains
% in initial structure
msuds_fn = 'E:\LongRangePaperFINAL\AGG2D\1Coarsening\Microstructure.uds';
chi_fn = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalytics\UnbiasedGrowthMeasures\TopoTracer2D3D.SimID.509500.LR2D.FID.50.RCLASS.0.csv';
InitialDomainEdgeLength = 21269;
PhysDomainEdgeLength = 2.83592616e-3/1.0e-6; %micron square RVE
R = 0.008*PhysDomainEdgeLength * 2;
iR = (1.0 - 2*0.008)*PhysDomainEdgeLength;
'User input there'

%% load Microstructure.uds
delimiter = '\t';
startRow = 9;
formatSpec = '%f%f%f%*s%*s%*s%*s%*s%*s%*s%*s%*s%[^\n\r]';
fileID = fopen(msuds_fn,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
fclose(fileID);
GID = dataArray{:, 1};
XY0(:,1) = dataArray{:, 2};
XY0(:,2) = dataArray{:, 3};
clearvars delimiter startRow formatSpec fileID dataArray ans;
XY0 = XY0./InitialDomainEdgeLength .* PhysDomainEdgeLength; %micron
'Microstructure.uds loaded'

%% load chi values
np = length(XY0(:,1));
CHI = nan(np,1);
delimiter = ';';
startRow = 15;
formatSpec = '%f%f%f%f%f%f%f%f%f%f%[^\n\r]';
fileID = fopen(chi_fn,'r');
textscan(fileID, '%[^\n\r]', startRow-1, 'ReturnOnError', false);
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'ReturnOnError', false);
fclose(fileID);
TMP(:,1) = [dataArray{:,1}];
TMP(:,2) = [dataArray{:,10}];
clearvars delimiter startRow formatSpec fileID dataArray ans;
'Chi loaded now build a hash to enforce equivalence of list index and grain ID'

%% input handling
ntmp = length(TMP(:,1));
for tmp=1:ntmp
    CHI(TMP(tmp,1),1) = TMP(tmp,2);
end
CHI = CHI .* 1.0e6; %m/s to micron/s
ARTIFICIAL_DRIVINGFORCE = 1.0e6; %1MPa because CHI is a mobility
CHI = CHI .* ARTIFICIAL_DRIVINGFORCE;
clearvars TMP;
'Input handled'

%% QUANTILES of tj/ti distribution
nquants = 101;
quants = 0/nquants:1/nquants:100/nquants;
xat = [0.2,1,5,10,15,20,25];
QUANTILETABLE = nan(np,nquants);
XATTABLE = nan(np,length(xat(1,:)));
DESCRTABLE = nan(np,2); %how many before (:,1) and after (:,2) clearing nans
'Initialized quantile tables'

%% build KDTree for distance queries
KDTREE = KDTreeSearcher(XY0);
'Building KDTree'

%% build logical array of inclosure exclosure
BNDCONTACT = logical(ones(np,1));
for gid=1:np
    %disprove boundary contact
    %if ~isnan(CHI(gid,1)) %chi value exists
        %sufficiently far from the boundary?
        if XY0(gid,1) > R && XY0(gid,1) < iR && XY0(gid,2) > R && XY0(gid,2) < iR
            BNDCONTACT(gid,1) = 0;
        end
    %end
end
%plot(XY0(BNDCONTACT==0,1),XY0(BNDCONTACT==0,2),'.')

%% perform point-based analysis
clearvars KDTREE;
tic
KDTREE = KDTreeSearcher(XY0,'BucketSize',50,'Distance','euclidean');
toc

for gid=1:1000
    clearvars idx d;
    tic
    [idx, d] = rangesearch(KDTREE,XY0(gid,:),(0.5*R));
    toc
end


tic
for gid=1:1000 %lisrt index equivalent to grainID only because XY0(:,1) == 1:1:2560000!
    if BNDCONTACT(gid,1) == 0 && ~isnan(CHI(gid,1))
       %find all neighbors in region of R about XY0(gid,:) 
       clearvars idx d cand dist ncand;
       [idx, d] = rangesearch(KDTREE,XY0(gid,:),R);    
       cand = cell2mat(idx(1,1)); 
        
       %if sum(BNDCONTACT(cand,1)) == 0
       %in general cand contains list indices not grain IDs!
       %BUT, as the XY0 contains is contiguous, and 1:1:2560000
       dist = cell2mat(d(1,1));
       %any of these candidates close to RVE boundary?
       ncand = length(cand(1,:));
       %if sum(~isnan(CHI(cand,1))) == ncand %analyze even though some candidates nan (because most likely as they died out)

       %if sum(XY0(cand,1)<R)==0 & sum(XY0(cand,1)>iR)==0 & sum(XY0(cand,2)<R)==0 & sum(XY0(cand,2)>iR)==0
       %so we analyze
       ['Analyzing ' num2str(gid)]
       clearvars ARRTIME c;
       ARRTIME = nan(ncand,2); %ti, tj
       for c=2:ncand %output of rangesearch is sorted so first point always i
            %i to j, i.e. me to candidate
            ARRTIME(c,1) = dist(c)/CHI(gid,1); %m/m/s --> s
            %%accept overflow into NaN for non-existent CHI value
            ARRTIME(c,2) = dist(c)/CHI(cand(c),1); %cand(c) as a list index is only a grainID because XY0(:,1) == 1:1:2560000!
       end
          
          %alpha_ji = tj/ti, assumption the larger alpha_ji the more beneficial for t_i to grow successfully!
          ARRTIME(:,3) = ARRTIME(:,2) ./ ARRTIME(:,1); 
          DESCRTABLE(gid,1) = length(ARRTIME(:,1));
          
          %remove ti,tj pairs with NaN
          ARRTIME(any(isnan(ARRTIME),2),:)=[];
          DESCRTABLE(gid,2) = length(ARRTIME(:,1));

          %compute quantile values of tj/ti
          QUANTILETABLE(gid,:) = quantile(ARRTIME(:,3),quants); 
          %distribution of ratio of arrival when all grains where given the same driving force
          
          %ecdf 
          clearvars F X;
          [F,X] = ecdf(ARRTIME(:,3));
          X = X(2:end);
          F = F(2:end);
          XATTABLE(gid,:) = interp1(X,F,xat,'nearest');
          %stairs(X,F)
     end
end
toc
%plot(XY0(BNDCONTACT==0,1),XY0(BNDCONTACT==0,2),'.')

%% load maxsize gain ever
mxszever_fn = 'E:\LongRangePaperFINAL\AGG2D\2DataAnalytics\TrackingParallel\TrackingBK_Resolution_1\TopoTracer2D3D.SimID.109500.MaxSizeGainFW.F.10.O.1.L.9500.csv';
delimiter = ';';
startRow = 3;
formatSpec = '%f%f%[^\n\r]';
fileID = fopen(mxszever_fn,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
fclose(fileID);
TMP = [dataArray{1:end-1}];
clearvars delimiter startRow formatSpec fileID dataArray ans;
%build a MAXSZ hash to map list indices to grain IDs
MAXSZ = nan(np,1);
ntmp = length(TMP(:,1));
for tmp=1:ntmp
    MAXSZ(TMP(tmp,1),1) = TMP(tmp,2);
end
clearvars TMP;
'Maximum size of grains ever achieved loaded'

threshold = 1000;

figure
for gid=1:10000
    if ~isnan(XATTABLE(gid,2)) & ~isnan(MAXSZ(gid,1)) %MAXSZ(gid,1) > threshold & 
        hold on
        plot(XATTABLE(gid,2),MAXSZ(gid,1),'.'); %,'LineWidth',0.5*MAXSZ(gid,1)/threshold)
    end
%    if MAXSZ(gid,1) < 3
%        hold on
%        plot(quants,QUANTILETABLE(gid,:))
%    end
end



%% load backtracking grain history in memory
fileID = fopen([prefix_trackbk prgnm_bk 'BK.NF' suffix_bk]);
NFACES = fread(fileID,[nrows,ncols],'uint32');
fclose(fileID);

fileID = fopen([prefix_trackbk prgnm_bk 'BK.VOL' suffix_bk]);
VOLUME = fread(fileID,[nrows,ncols],'double');
fclose(fileID);

fileID = fopen([prefix_trackbk prgnm_bk 'BK.MOBDSEE' suffix_bk]);
MOBDSEE = fread(fileID,[nrows,ncols],'double');
fclose(fileID);

fileID = fopen([prefix_trackbk prgnm_bk 'BK.HAGB' suffix_bk]);
HAGB = fread(fileID,[nrows,ncols],'double');
fclose(fileID);
'Binary raw data successfully read'

%VOLUME(VOLUME == 0) = nan;
%HAGB(isnan(VOLUME)) = nan;
%NFACES(isnan(VOLUME)) = nan;
%MOBDSEE(isnan(VOLUME)) = nan;

%% translate relative into absolute sizes in micron^Dimension
for c=1:ncols
    VOLUME(:,c) = VOLUME(:,c) * DomainSize;
end
'Volume from normalized to micron^Dimension'

%% load IDs of survivors
filename = surv_fn;
delimiter = '';
startRow = 2;
formatSpec = '%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
fclose(fileID);
GID = [dataArray{1:end-1}];
clearvars filename delimiter startRow formatSpec fileID dataArray ans;
'Survivor IDs loaded'

%% successively load results for curvature
CURV_DRVFRC = nan(nrows,ncols);
CURV_SPEED = nan(nrows,ncols);
CURV_SUPP = nan(nrows,ncols);

for fid=last:-offset:first
    %% load curvature file and analyze
    filename = [prefix_curvapprx prgnm_crv num2str(fid) suffix_crv];
    delimiter = ';';
    startRow = 3;
    formatSpec = '%f%f%f%f%f%f%f%f%f%[^\n\r]';
    fileID = fopen(filename,'r');
    dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
    fclose(fileID);
    TMP = [dataArray{1:end-1}];
    clearvars filename delimiter startRow formatSpec fileID dataArray ans;
    
    %% store available curvature approximates in hash for quick assignment to grains
    clearvars crvhash;
    crvhash = nan(3,ngr);
    for i=1:length(TMP(:,1))
        gid = TMP(i,1); %grainID
        % filtering?
        crvhash(1,gid) = TMP(i,2); %effDrvForce w/o TJP
        crvhash(2,gid) = TMP(i,4); %effSpeed w/o TJP
        crvhash(3,gid) = TMP(i,8); %contour support
    end
    clearvars TMP;
    
    %% assign to curv
    for i=1:length(GID(:,1))
        gid = GID(i,1);
        val1 = crvhash(1,gid);
        val2 = crvhash(2,gid);
        val3 = crvhash(3,gid);
        where = (fid-first)/offset+1;
        if ~isnan(val1) && ~isnan(val2)
            CURV_DRVFRC(i,where) = val1; %what is at the moment the driving force?
            CURV_SPEED(i,where) = val2; %what is at the moment the speed?
            CURV_SUPP(i,where) = val3; %is the contour still sufficiently supported by points?
        end
        %i
    end
    clearvars crvhash;
    ['Curvature ' num2str(fid) ' read out']
end
'Curvature all imported'

%% multiply curvature speed and driving force with -1.0 to enforce
% consistence with sign convention for SEE driving force, positive promotes the growth of the grain!
CURV_DRVFRC = -1.0.*CURV_DRVFRC;
CURV_SPEED = -1.0.*CURV_SPEED;
signvalid = 1;


%% do not report grains for which the number of supporting points for the estimation 
% of the curvature falls below a certain threshold


%% load realtime
filename = [prefix_ngrains 'NrGrains&EnergyStatistics.txt'];
delimiter = '\t';
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN, 'ReturnOnError', false);
fclose(fileID);
TMP = [dataArray{1:end-1}];
clearvars filename delimiter formatSpec fileID dataArray ans;

%% set up ID vector as a tool to allowing plotting
ID = zeros(nrows,ncols);
for t=1:ncols
    ID(:,t) = TMP(first+(t-1)*offset,1);
end
'Real time loaded'


%% find column index of last snapshot before population becomes insignificant
tcutoff = ncols;
Vm = mean(VOLUME(:,tcutoff));
Vmax = max(VOLUME(:,tcutoff));

tzoom = 1;
% when does the first abnormal grain appear?
for c=1:ncols
    if max(VOLUME(:,c)) < 9.0
        tzoom = c;
    end
end
%plot(1:nrows,VOLUME(:,1),'.')
%xlabel({'grainID'},'FontSize',fontsz,'FontName',fontnm)
%ylabel({'SzGain FID.100'},'FontSize',fontsz,'FontName',fontnm)
%print(gcf,'AGG2D_SzGainVsMatrExclSurv_SurvivorsMakeItInTheFirst100Timesteps.png','-dpng','-r500')
clearvars TMP;



%% exemplary plot
gidx=find(VOLUME(:,tcutoff)==Vmax); %1599401;
%cut=min[find(isnan(VOLUME(gid,:)))]
plot3(MOBDSEE(gidx,:),CURV_SPEED(gidx,:),VOLUME(gidx,:),'-o')
fontsz = 20;
fontnm = 'Calibri Light';
xlabel({'v_{SEE} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
ylabel({'v_{cap} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
if Dimension == 2
zlabel({'A (\mum^2)'},'FontSize',fontsz,'FontName',fontnm)
end
if Dimension == 3
zlabel({'V (\mum^3)'},'FontSize',fontsz,'FontName',fontnm)
end
grid('on')
box('on')
view(-90,0)
view(0,0)
set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[20 20])
pbaspect([1 1 1])
set(gcf,'color','w')
view(-49,19)
xlim([-1.0e-11 +1.0e-7])
ylim([-1.0e-11 +1.0e-7])

clearvars ans c fid i id naggr optgridcm resu_new_lineid resu_old_lineid val1 val2 val3 where;

save('PRX2D_BKLocalPropertiesEvo_Time_01.mat');

%% correlations of local properties as a function of time (grain history)
optgridcm = 0;
figure('Position',[100 100 1200 1000])
for i=1:nrows
    id = i;
    %if 1==1
    %if  mod(id,100) == 0
    %if VOLUME(id,tcutoff) == Vmax & ~isnan(CURV_SPEED(i,:))
    if VOLUME(id,tcutoff) >= 3.0*Vm %& ~isnan(CURV_SPEED(i,:))
        hold on
        %%plot3(CURV_SPEED(id,1),NFACES(id,1),SZGAIN(id,tcutoff),'.','Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        plot3(MOBDSEE(id,1:tcutoff),CURV_SPEED(id,1:tcutoff),VOLUME(id,1:tcutoff),'Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        %plot3(CURV_DRVFRC(id,1:tcutoff),NFACES(id,1:tcutoff),SZGAIN(id,1:tcutoff),'-o','Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
        %plot3(NFACES(id,1:tcutoff),HAGB(id,1:tcutoff),VOLUME(id,1:tcutoff),'Color',[0 0 122/255],'LineWidth',0.5) %VOLUME(id,tcutoff)/Vmax*0.5)
 
        if optgridcm == 1
            for t=1:tcutoff-1
                %was a grid coarsement step done between t and t+1?
                resu_old_lineid = find(TMP(:,1)==ID(id,t));
                resu_new_lineid = find(TMP(:,1)==ID(id,t+1));
                if TMP(resu_old_lineid,4) ~= TMP(resu_new_lineid,4)
                    %resu_old_lineid
                    hold on
                    plot3(CURV_SPEED(id,t),NFACES(id,t),SZGAIN(id,t),'+','Color',[1 0 0])
                    %plot3(NFACES(id,t),HAGB(id,t),VOLUME(id,t),'+','Color',[1 0 0])
                 end
            end
        end 
    end
end
fontsz = 20;
fontnm = 'Calibri Light';
xlabel({'v_{SEE} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
ylabel({'v_{cap} (m^4/Js)'},'FontSize',fontsz,'FontName',fontnm)
if Dimension == 2
zlabel({'A (\mum^2)'},'FontSize',fontsz,'FontName',fontnm)
end
if Dimension == 3
zlabel({'V (\mum^3)'},'FontSize',fontsz,'FontName',fontnm)
end
%% POSITIVE DRIVING FORCES MEAN PROMOTING GROWTH NOW FOR BOTH CAP AND SEE!!!!
grid('on')
box('on')
view(-90,0)
view(0,0)
set(gca,'FontSize',fontsz,'FontName',fontnm,'LineWidth',1.5)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[20 20])
pbaspect([1 1 1])
set(gcf,'color','w')
view(-49,19)
print(gcf,['PRX2D_VolumeEvoSpeedSEEandCAP_LargestGrain.png'],'-dpng','-r500')

figure
plot(MOBDSEE(:,1),CURV_SPEED(:,1),'.','MarkerSize')
