%% IMPORT TOPOTRACER RESULTS AGGLUIS
clear;
clc;

%% BKSIZEGAIN
nrows = 2361; %ngrains
sizenrows = 2+2361;
ncols = 71; %ntimes
simid = 5355;
DomainSize = (29.2 * 1.0e-6 / 1.0e-6)^3; %micron^3

prefix = ['TopoTracer2D3D.SimID.' num2str(simid) '.BK.'];
sizeprefix = ['TopoTracer2D3D.SimID.' num2str(simid) '.'];
suffix = ['.F.5.O.5.L.355.NC.' num2str(ncols) '.NR.' num2str(nrows) '.bin'];
sizesuffix = ['.F.5.O.5.L.355.NC.' num2str(ncols) '.NR.' num2str(sizenrows) '.bin'];

%% read input
fileID = fopen([sizeprefix 'SIZEGAINBK' sizesuffix]);
SIZEGAINBK = fread(fileID,[sizenrows,ncols],'double');
fclose(fileID);

%% read input
fileID = fopen([prefix 'NF' suffix]);
NFACES = fread(fileID,[nrows,ncols],'uint32');
fclose(fileID);

fileID = fopen([prefix 'VOL' suffix]);
VOLUME = fread(fileID,[nrows,ncols],'double');
fclose(fileID);

fileID = fopen([prefix 'HAGB' suffix]);
HAGB = fread(fileID,[nrows,ncols],'double');
fclose(fileID);

fileID = fopen([prefix 'MOBDSEE' suffix]);
MOBDSEE = fread(fileID,[nrows,ncols],'double');
fclose(fileID);
'Raw data read'


x = 0:0.01:1;
figure(1)
filename = 'Test.gif';
for n=1:1 %:0.5:5
      y = x.^n;
      plot(x,y)
      set(gca,'FontSize',12,'FontName','CMU Bright','LineWidth',2)
      set(gcf,'PaperUnits','Inches')
      set(gcf,'PaperSize',[20 20])
      set(gcf,'color','w');
      drawnow
      frame = getframe(1);
      im = frame2im(frame);
      [imind,cm] = rgb2ind(im,65536,'nodither');
      if n == 1;
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
      else
          imwrite(imind,cm,filename,'gif','WriteMode','append');
      end
end



















%% overview
plot(1:ncols,SIZEGAINBK(1,:))
plot(1:ncols,SIZEGAINBK(2,:))
%% at 2225 less than 1000 grains in the matrix
xlim([2200 2250])
ylim([1 1000])
%plot(log(SIZEGAINBK(3:nrows,2000))./log(10))
plot(SIZEGAINBK(3:nrows,2000))
nAGG = length(find(SIZEGAINBK(3:nrows,2000) > 9))

%% load realtime data
filename = 'W:\Paper08\ANALYSIS\TestStructureNoGridCoarsement\VideoForChristian\NrGrains&EnergyStatistics.txt';
delimiter = '\t';
formatSpec = '%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN, 'ReturnOnError', false);
fclose(fileID);
NrGrains = [dataArray{1:end-1}];
clearvars filename delimiter formatSpec fileID dataArray ans;
'Real time read'

tcutoff = ncols;

%%collect data for grain 1068
RESULTS = zeros(ncols,1+1+1+1+1+1);
for c=1:ncols
    RESULTS(c,1) = NrGrains(5/5+c,1);
    RESULTS(c,2) = VOLUME(326,c)*DomainSize;
    RESULTS(c,3) = NFACES(326,c);
    RESULTS(c,4) = HAGB(326,c);
    RESULTS(c,5) = MOBDSEE(326,c);
    RESULTS(c,6) = SIZEGAINBK(2+326,c);
end
dlmwrite('Grain1068forChristian.csv',RESULTS);




%% define realtime, MIND THE TIME OFFSET!
ID = zeros(nrows,ncols);
for t=1:ncols
    ID(:,t) = NrGrains(10/1+t,1);
end

%% mean size
Vm = mean(VOLUME(:,ncols));
rm = (Vm/(4/3*pi))^(1/3);

%% find the largest abnormal grain
Vmax = max(VOLUME(:,ncols));
VmaxID = find ( VOLUME(:,ncols) == Vmax );

%% identify grid coarsement
GRIDCOARSE = zeros(nrows,ncols);
for c=1:ncols
    if ( NrGrains(10/1+c,4) - NrGrains(10/1+c-1,4) ~= 0 ) 
        [num2str(10/1+c) ' hit']
        GRIDCOARSE(:,c) = 1;
    end
end

%% plot largest grain only
figure;
plot3(MOBDSEE(VmaxID,1:tcutoff),HAGB(VmaxID,1:tcutoff),VOLUME(VmaxID,1:tcutoff),'.','MarkerSize',10);
xlabel({'0.5\cdotGb^2\Delta\rho (m^{-2})'},'FontSize',14,'FontName','CMU Bright')
ylabel({'HAGB fraction'},'FontSize',14,'FontName','CMU Bright')
zlabel({'Volume (�m^3)'},'FontSize',14,'FontName','CMU Bright')
grid('on')
box('on')
ylim([0 1])
%plot grid coarsement as well
% for c=1:ncols
%     if ( GRIDCOARSE(1,c) == 1 ) 
%         hold on
%         plot3(MOBDSEE(VmaxID,1:tcutoff),HAGB(VmaxID,1:tcutoff),VOLUME(VmaxID,1:tcutoff),'o','Color',[1 0 0],'MarkerSize',5);
%     end
% end


%% plot log(V(:,ncols)/Vm) = f(Initial configuration)
figure;
for gr=1:nrows
    hold on
    plot3(MOBDSEE(gr,1),HAGB(gr,1),VOLUME(gr,ncols)/VOLUME(gr,1),'.','MarkerSize',10 );
end
xlabel({'0.5\cdotGb^2\Delta\rho (m^-2)'},'FontSize',14,'FontName','CMU Bright')
ylabel({'HAGB fraction'},'FontSize',14,'FontName','CMU Bright')
zlabel({'Size gain'},'FontSize',14,'FontName','CMU Bright')
grid('on')
box('on')


%%plot evolution of correlation SizeGain=f(HAGB) or =f(MOBDSEE) over time
figure;
for c=900:ncols
    if ( mod(c,200) == 0 ) 
        %linear regression

Rsq2 = 1 - sum((y - yCalc2).^2)/sum((y - mean(y)).^2)
        
        
        
    for gr=1:nrows
        hold on
        plot3(ID(gr,c),MOBDSEE(gr,c),VOLUME(gr,ncols)/VOLUME(gr,c),'.','MarkerSize',5);
    end
    end
    c
end
xlabel({'Annealing time (s)'},'FontSize',14,'FontName','CMU Bright')
ylabel({'0.5\cdotGb^2\Delta\rho (m^-2)'},'FontSize',14,'FontName','CMU Bright')
zlabel({'Size gain'},'FontSize',14,'FontName','CMU Bright')
set(gca,'zscale','log')
box('on')
grid('on')
zlim([1 1e4])

% fit correlations
% x = MOBDSEE(:,c);
% y = log(VOLUME(:,ncols)./VOLUME(:,c));
% b1 = y\x;
% ycalc = x() .* 1/b1;
% Rsq = 1 - sum((y - ycalc).^2)/sum((y - mean(y)).^2);
% plot(x,y,'.')
% ylim([0 2])
        

figure;
for c=1:ncols
    if ( mod(c,100) == 0 ) 
    for gr=1:nrows
        hold on
        plot3(ID(gr,c),HAGB(gr,c),VOLUME(gr,ncols)/VOLUME(gr,c),'.','MarkerSize',5);
    end
    end
    c
end
xlabel({'Annealing time (s)'},'FontSize',14,'FontName','CMU Bright')
ylabel({'HAGB fraction'},'FontSize',14,'FontName','CMU Bright')
zlabel({'Size gain'},'FontSize',14,'FontName','CMU Bright')
set(gca,'zscale','log')
box('on')
grid('on')
zlim([1 1e4])

%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% plot the n-largest
%% plot the n-largest

NLARGEST = zeros(nrows,3);
for gr=1:nrows
    NLARGEST(gr,1) = gr;
    NLARGEST(gr,2) = VOLUME(gr,ncols);
    NLARGEST(gr,3) = VOLUME(gr,ncols)/VOLUME(gr,1); % volume gain relative to beginning
end
NLARGEST = sortrows(NLARGEST,-3);


%% plot only trajectories of the largest grains
tcutoff = ncols;
figure;
%for gr=1:nrows
for i=1:100
    gr = NLARGEST(i,1);
    hold on
    %plot3(ID(gr,1:tcutoff),NFACES(gr,1:tcutoff),VOLUME(gr,1:tcutoff) ); %'.','LineWidth',2.0,'Color',[0 0 1]*(VOLUME(gr,tcutoff)/max(VOLUME(:,tcutoff))) ); %[unifrnd(0,1) unifrnd(0,1) unifrnd(0,1)]); % 0 100/255]); %[rgbr rgbg rgbb]*(VOLUME(gr,tcutoff)/maxvolume)); %+(VOLUME(gr,ncols))); %/maxsize)*0.6 ); %,'.'); %( % 1) fac(:)],'.'),%'.')
    %plot3(NFACES(gr,1:tcutoff),HAGB(gr,1:tcutoff),VOLUME(gr,1:tcutoff) ); %'.','LineWidth',2.0,'Color',[0 0 1]*(VOLUME(gr,tcutoff)/max(VOLUME(:,tcutoff))) ); %[unifrnd(0,1) unifrnd(0,1) unifrnd(0,1)]); % 0 100/255]); %[rgbr rgbg rgbb]*(VOLUME(gr,tcutoff)/maxvolume)); %+(VOLUME(gr,ncols))); %/maxsize)*0.6 ); %,'.'); %( % 1) fac(:)],'.'),%'.')
    plot3(MOBDSEE(gr,1:tcutoff),HAGB(gr,1:tcutoff),VOLUME(gr,1:tcutoff)./VOLUME(gr,1) );
    
    gr
end
'Plotting successful'
xlabel({'0.5\cdotGb^2\Delta\rho (m^{-2})'},'FontSize',14,'FontName','CMU Bright')
ylabel({'HAGB fraction'},'FontSize',14,'FontName','CMU Bright')
zlabel({'Volume gain'},'FontSize',14,'FontName','CMU Bright')
%set(gca,'zscale','log')
grid('on')
box('on')


%% plot final size gain in dependency of initial properties
tcutoff = ncols;
figure;
for i=1:nrows
    gr = NLARGEST(i,1);
    hold on
    %plot3(MOBDSEE(gr,1),HAGB(gr,1),VOLUME(gr,ncols)/VOLUME(gr,1),'.','MarkerSize',10 );  
    plot(MOBDSEE(gr,1),VOLUME(gr,ncols)/VOLUME(gr,1),'.','MarkerSize',10 );  
    %plot(HAGB(gr,1),VOLUME(gr,ncols)/VOLUME(gr,1),'.','MarkerSize',10 );    
    %gr
end
'Plotting successful'
xlabel({'0.5\cdotGb^2\Delta\rho (m^{-2})'},'FontSize',14,'FontName','CMU Bright')
%xlabel({'HAGB fraction'},'FontSize',14,'FontName','CMU Bright')
%ylabel({'HAGB fraction'},'FontSize',14,'FontName','CMU Bright')
%zlabel({'Volume gain'},'FontSize',14,'FontName','CMU Bright')
ylabel({'Volume gain'},'FontSize',14,'FontName','CMU Bright')

%set(gca,'zscale','log')
grid('on')
box('on')



%% plot typical growth curves, aka "Juul Jensen experiment"
figure;
for i=1:100
    gr = NLARGEST(i,1);
    hold on
    plot(ID(gr,1:tcutoff),VOLUME(gr,1:tcutoff)./VOLUME(gr,1) )
end
'Plotting successful'
xlabel({'Annealing time (s)'},'FontSize',14,'FontName','CMU Bright')
ylabel({'Volume gain'},'FontSize',14,'FontName','CMU Bright')
%set(gca,'xscale','log')
grid('on')
box('on')

























VOLUME(115,1699)/VOLUME(115,1)

VOLUME(:,1699) = VOLUME(:,1699) ./ VOLUME(:,1);
plot([1:nrows],VOLUME(:,1699))


%NFACES GBTYPE VOLUME
% xlabel({'Number of faces'},'FontSize',14,'FontName','Times')
% ylabel({'Mobility * Energy'},'FontSize',14,'FontName','CMU Bright')
% zlabel({'x Average grain area (-)'},'FontSize',14,'FontName','CMU Bright')

set(gca,'FontSize',12,'FontName','Times','LineWidth',2)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[15 20])
pbaspect([ 1 1 1])
box('on')
view(-45,14)
xlim([-0.05 1e14] )
ylim([-0.05 1.05])
xt = get(gca,'XTick');
set(gca,'XTickLabel', sprintf('%.1e|',xt)) %elastic
yt = get(gca,'YTick');
set(gca,'YTickLabel', sprintf('%.1f|',yt)) %area
zt = get(gca,'ZTick');
set(gca,'ZTickLabel', sprintf('%.1f|',zt)) %mobility
%view(0,0)





%% post process
sizescale = (1.994*10^-4/10^-6)^2; %square micron
disoriscale = 180.0/pi; %degree
for rr=1:nrows
    for cc=1:ncols
        VOLUME(rr,cc) = VOLUME(rr,cc)*sizescale; %log(VOLUME(rr,cc)*sizescale)/log(10);
        DISORI(rr,cc) = DISORI(rr,cc) * disoriscale;
        DISORI(rr,cc) = 1-0.99*exp(-5*(DISORI(rr,cc)/15)^9);
        
    end
end
'Raw data post-processed'

%% perform initial categorization
%classes: nfaces, <6, 6, 7-8, 9-10, >10
%classes: disori, <=0.2,<0.4,<0.6,<0.8,<1.0
%classes: stored elastic
nf = 3; %<6, 6, >6
nrho = 16; %how many categories to bin dislocation densities
nm = 10;
rhomin = -1.5*10^14;
rhomax = +1.5*10^14;
mmin = 0.01;
mmax = 1.00;

nt0 = 0;
ZZ0 = zeros(nm,nrho);
for r=1:nrows
    cm = ceil(DISORI(r,1)*nm); %disori
    cr = uint32((ELASTIC(r,1)+(-1*rhomin))/((rhomax-rhomin)/(nrho-1)))+1;%elastic
    ZZ0(cm,cr) = ZZ0(cm,cr) + 1; 
    nt0 = nt0 + 1;
end

%calculate
ZZ = zeros(nm,nrho);
coltime=100;
nt = 0;
for r=1:nrows
    cm = ceil(DISORI(r,1)*nm); %disori
    cr = uint32((ELASTIC(r,1)+(-1*rhomin))/((rhomax-rhomin)/(nrho-1)))+1;%elastic
    %still there by coltime?
    if ( NFACES(r,coltime) > 1 )
        ZZ(cm,cr) = ZZ(cm,cr) + 1; 
        nt = nt+1;
    end   
end
%normalize against how many where in the category in the beginning
for rr=1:nrho
    for mm=1:nm
        if ( ZZ0(mm,rr) > 0 )
         ZZ(mm,rr) = ZZ(mm,rr)/ZZ0(mm,rr);
        end
    end
end
%plot
rr = linspace(-1.5*10^14,+1.5*10^14,16);
mm = linspace(0.0,1.0,nm);
[RR,MM] = meshgrid(rr,mm);
figure
contourf(RR,MM,ZZ)%'ShowText','on')
xlim([-0.5*10^14 0.5*10^14])
colorbar



    
    
    
      



for 



% start rather simple
SurvivalRateA = zeros(ncols,1);
SurvivalRateB = zeros(ncols,1);
SurvivalRateC = zeros(ncols,1);
% count how many grains with particular property combination remain after t
for r=1:nrows
    nf0 = NFACES(r,1);
    dis0 = DISORI(r,1);
    se0 = ELASTIC(r,1);
    
    if ( nf0 < 6 && dis0 >= 0.5 && dis0 <= 1.0 && se0 > 0.0)
        for c=1:ncols
            if ( NFACES(r,c) > 0 ) %grains exists
                SurvivalRateA(c,1) = SurvivalRateA(c,1) + 1;
            end
        end
    end
    
    if ( nf0 == 6 && dis0 >= 0.5 && dis0 <= 1.0 && se0 > 0.0)
        for c=1:ncols
            if ( NFACES(r,c) > 0 ) %grains exists
                SurvivalRateB(c,1) = SurvivalRateB(c,1) + 1;
            end
        end
    end
    
    if ( nf0 > 6 && dis0 >= 0.5 && dis0 <= 1.0 && se0 > 0.0)
        for c=1:ncols
            if ( NFACES(r,c) > 0 ) %grains exists
                SurvivalRateC(c,1) = SurvivalRateC(c,1) + 1;
            end
        end
    end
    r
end
%normalize results
A0 = SurvivalRateA(1,1);
B0 = SurvivalRateB(1,1);
C0 = SurvivalRateC(1,1);

for c=1:ncols
    SurvivalRateA(c,1) = SurvivalRateA(c,1) / A0;
    SurvivalRateB(c,1) = SurvivalRateB(c,1) / B0;
    SurvivalRateC(c,1) = SurvivalRateC(c,1) / C0;
    
end   
'Survival analysis performed'
plot(SurvivalRateA(:,1),'Color',[1 0 0]);
hold on
plot(SurvivalRateB(:,1),'Color',[0 0 1]);
hold on
plot(SurvivalRateC(:,1),'Color',[0 1 0]);
ylim([-0.05 1.05])


% %% transform volume (area) to times the average grain size at each point in time
% %2016REXGG only boundary grains excluded
% %VOLUMEAV = zeros(1,ncols);
% %for cc=1:ncols
% %    VOLUMEAV(1,cc) = ##unknown;
% %end
% for rr=1:nrows
%     for cc=1:ncols
%         VOLUME(rr,cc) = VOLUME(rr,cc) / VOLUME(rr,ncols); %normalize by final size
%     end
% end
% 'Average found'

%% detect topological transitions
TOPOTRANS = zeros(nrows,ncols);
for rr=1:nrows
    for cc=2:ncols
        TOPOTRANS(rr,cc) = (NFACES(rr,cc)-NFACES(rr,cc-1));
    end
end
'Topological transformations detected'
ID = zeros(1,ncols);
for t=1:ncols
    ID(1,t) = t;
end
plot3(ID(1,:),VOLUME(1,:),NFACES(1,:),'.')
xlabel({'Time step'},'FontSize',14,'FontName','Times')
ylabel({'Area (micron^2)'},'FontSize',14,'FontName','Times')
zlabel({'Faces'},'FontSize',14,'FontName','Times')
grid('on')


%% main plot routine

['Analyzing with ' num2str(nrows) ' ' num2str(ncols)]
tcutoff = 561; %short before band contact    ncols;
figure;
for gr=1:nrows
    %if ( VOLUME(gr,tcutoff) > 40.0 ) %(mod(gr,1) == 0 
%     for c=1:ncols
%         hold on       %VOLUME(gr,tcutoff)/10
%         if ( NFACES(gr,c) > 6 ) 
%             plot3(ELASTIC(gr,c),DISORI(gr,c),VOLUME(gr,c),'.','LineWidth',3.0,'Color',[0 1 0]); %[unifrnd(0,1) unifrnd(0,1) unifrnd(0,1)]); % 0 100/255]); %[rgbr rgbg rgbb]*(VOLUME(gr,tcutoff)/maxvolume)); %+(VOLUME(gr,ncols))); %/maxsize)*0.6 ); %,'.'); %( % 1) fac(:)],'.'),%'.')
%         end
%         if ( NFACES(gr,c) == 6 ) 
%             plot3(ELASTIC(gr,c),DISORI(gr,c),VOLUME(gr,c),'.','LineWidth',3.0,'Color',[1 1 0]);
%         end
%         if(NFACES(gr,c) < 6 ) 
%             plot3(ELASTIC(gr,c),DISORI(gr,c),VOLUME(gr,c),'.','LineWidth',3.0,'Color',[1 0 0]);
%         end
%         c
%      end
     hold on
     plot3(ELASTIC(gr,1:tcutoff),DISORI(gr,1:tcutoff),VOLUME(gr,1:tcutoff),'.','LineWidth',2.0,'Color',[0 0 1]*(VOLUME(gr,tcutoff)/max(VOLUME(:,tcutoff))) ); %[unifrnd(0,1) unifrnd(0,1) unifrnd(0,1)]); % 0 100/255]); %[rgbr rgbg rgbb]*(VOLUME(gr,tcutoff)/maxvolume)); %+(VOLUME(gr,ncols))); %/maxsize)*0.6 ); %,'.'); %( % 1) fac(:)],'.'),%'.')
     
    %faces, mobenergy, volume space
    %plot3(NFACES(gr,1:tcutoff),GBTYPE(gr,1:tcutoff),VOLUME(gr,1:tcutoff),'b','LineWidth',1,'Color',[rgbr(n)/255 rgbg(n)/255 rgbb(n)/255]); %+(VOLUME(gr,ncols))); %/maxsize)*0.6 ); %,'.'); %( % 1) fac(:)],'.'),%'.')
    
    %plot3(IDS(gr,:),NFACES(gr,:),GBTYPE(gr,:),'b','LineWidth',2,'Color',[0 0 0]+(VOLUME(gr,ncols)/maxsize)*0.6 ); %,'.'); %( % 1) fac(:)],'.'),%'.')
    %plot start point of the grain
    %plot3(NFACES(gr,1),GBTYPE(gr,1),VOLUME(gr,1),'.','MarkerSize',2+25*(VOLUME(gr,ncols)/maxsize),'MarkerEdgeColor',[0 0 0]+(VOLUME(gr,ncols)/maxsize)*0.6); %,'MarkerFaceColor',[0 0 0]+(VOLUME(gr,ncols)/maxsize)*0.6); 
   
    %start stop marker
    %plot3(NFACES(gr,1),GBTYPE(gr,1),VOLUME(gr,1),'o','MarkerSize',10,'MarkerEdgeColor',[rgbr(n)/255 rgbg(n)/255 rgbb(n)/255],'LineWidth',3); %,'MarkerFaceColor',[0 0 0]+(VOLUME(gr,ncols)/maxsize)*0.6); 
    %plot3(NFACES(gr,tcutoff),GBTYPE(gr,tcutoff),VOLUME(gr,tcutoff),'.','MarkerSize',25,'MarkerEdgeColor',[rgbr(n)/255 rgbg(n)/255 rgbb(n)/255]); %,'MarkerFaceColor',[0 0 0]+(VOLUME(gr,ncols)/maxsize)*0.6); 
    
    %plot3(NFACES(gr,:),GBTYPE(gr,:),VOLUME(gr,:),'b','LineWidth',4*(VOLUME(gr,ncols)/maxsize),'Color',[0 0 0]+(VOLUME(gr,ncols)/maxsize)*0.6 ); %,'.'); %( % 1) fac(:)],'.'),%'.')
    %plot3(NFACES(gr,ncols),GBTYPE(gr,ncols),VOLUME(gr,ncols),'o','MarkerSize',2+20*(VOLUME(gr,ncols)/maxsize),'MarkerEdgeColor',[0 0 0]+(VOLUME(gr,ncols)/maxsize)*0.6,'MarkerFaceColor',[0 0 0]+(VOLUME(gr,ncols)/maxsize)*0.6);

end
'Plotting successful'

%set(gca,'Units','normalized','FontUnits','points','FontWeight','normal','FontSize',16,'FontName','Times')
%Stored Elastic Disori Volume
xlabel({'SEE gradient (1/m^2)'},'FontSize',14,'FontName','Times')
ylabel({'Mobility realtive to HAGB'},'FontSize',14,'FontName','Times')
zlabel({'Area (micron^2)'},'FontSize',14,'FontName','Times')
grid('on')
%NFACES GBTYPE VOLUME
% xlabel({'Number of faces'},'FontSize',14,'FontName','Times')
% ylabel({'Mobility * Energy'},'FontSize',14,'FontName','CMU Bright')
% zlabel({'x Average grain area (-)'},'FontSize',14,'FontName','CMU Bright')

set(gca,'FontSize',12,'FontName','Times','LineWidth',2)
set(gcf,'PaperUnits','Inches')
set(gcf,'PaperSize',[15 20])
pbaspect([ 1 1 1])
box('on')
view(-45,14)
xlim([-0.05 1e14] )
ylim([-0.05 1.05])

xt = get(gca,'XTick');
set(gca,'XTickLabel', sprintf('%.1e|',xt)) %elastic
yt = get(gca,'YTick');
set(gca,'YTickLabel', sprintf('%.1f|',yt)) %area
zt = get(gca,'ZTick');
set(gca,'ZTickLabel', sprintf('%.1f|',zt)) %mobility
%view(0,0)

PICKGRAIN = zeros(ncols,4);
for cc=1:ncols
    PICKGRAIN(cc,1) = ELASTIC(1,cc);
    PICKGRAIN(cc,2) = DISORI(1,cc);
    PICKGRAIN(cc,3) = VOLUME(1,cc);
    if (NFACES(1,cc) > 6)
        PICKGRAIN(cc,4) = 0+(255*256)+0*(256^2); %Origin green
    end
    if ( NFACES(1,cc) == 6)
        PICKGRAIN(cc,4) = 255+(217*256)+64*(256^2); %origin yellow
    end
    if ( NFACES(1,cc) < 6) 
        PICKGRAIN(cc,4) = 255+(0*256)+0*(256^2);
    end

end
    

print(gcf,pngfname,'-dpng','-r600')
































%rgbr = [255,255,255,255, 137,137,137,137, 0,0,0,0];
%rgbg = [50,50,50,50 ,137,137,137,137, 0,0,0,0];
%rgbb = [0,0,0,0, 250,250,250,250, 100,100,100,100];
%rgbr = [255, 137, 0];
%rgbg = [50, 137, 0];
%rgbb = [0, 250, 100];
limitingtime = 1e5; %seconds

%% end of user interaction
h = figure;
maxx = 0.0;
maxid = -1;
view(-45,14)
%view(0,90)
view(90,0)
view(0,0)
grid('on')

%nfaces
%maxvolume = 22;
%xlim([0 1e5])
%ylim([0 25])
%zlim([0 maxvolume])
%xlim([0 30])
%ylim([0 1.0])
%zlim([0 20000])
%set(gca, 'zscale', 'log') 
%zlim([1 5])

%for n=1:nsims
%nrows = rows(n);
%ncols = 1 + flast(n); %1+last, how many timesteps?


%% read descriptive summary system evolution

suffix = [num2str(id(n)) '.first.0.offs.1.last.' num2str(flast(n))];
fname = ['../topotracelog/InputLog.JobID.' num2str(id(n)) '.first.1.offs.1.last.1.csv'];

newData1 = importdata(fname);
vars = fieldnames(newData1);
for i = 1:length(vars)
    assignin('base', vars{i}, newData1.(vars{i}));
end
clearvars i colheaders vars newData1

%calculate true average grain size because in Luis original kinetics file
%this is wrong! takes always all grains ever planned for the network but
%not actual number of grains
nld = length(data(:,1));
for i = 1:nld
    data(i,7) = Arve / data(i,3);
end

% %output this info in a new file
% fileID = fopen(['../topotracelog/WithKinetics.Job.ID' num2str(id(n)) '.first.1.offs.1.last.1.csv'],'w');
% fprintf(fileID,'Time(s);NGrains;MemoryByte;MPITime(s);AvGrainSize(m^2)\n');
% for i = 1:nld
%     fprintf(fileID,'%.4e;%lu,%lu,%.4e;%.4e\n',data(i,2), data(i,3), data(i,5), data(i,6), data(i,7) );
% end
% fclose(fileID);

%% for mobility-nfaces-area plots that show comparable states of the structure
% the time is fixed! hence, plot up to a threshold time tcutoff
tcutoff = 1;
for i=1:nld
    tcutoff = i;
    %[num2str(data(i,2)) ' ' num2str(tcutoff)]
    if ( data(i,2) > limitingtime )
        break;        
    end
end

tcutoff


%% descriptive stats
maxsize=max(VOLUME(:,ncols));

%% copy over time scheme for the plotting of the population
IDS = zeros(nrows,ncols);
for gr=1:nrows
    for c=1:ncols
       IDS(gr,c) = data(c,2); %for real time
    end;
end

%% plot population evolution
% figure;
% plot(data(:,2),data(:,3),'b','LineWidth',2,'Color',[0 0 0]+0.0 );
% grid('on');
% set(gca,'Units','normalized','FontUnits','points','FontWeight','normal','FontSize',20,'FontName','Times')
% xlabel({'Annealing time (s)'},'FontUnits','points','interpreter','latex','FontSize',20,'FontName','Times')
% ylabel({'Total number of grains'},'FontUnits','points','interpreter','latex','FontSize',20,'FontName','Times')
% print -depsc Riso2015SCubeBiCrystalPopulationStatistics.eps
% print -dpng Riso2015SCubeBiCrystalPopulationStatistics.png


%% calculate face switching matrix
% FACESWITCH=zeros(nrows,ncols);
% for gr=1:nrows
%     for s=2:ncols
%         FACESWITCH(gr,s) = NFACES(gr,s) - NFACES(gr,s-1);
%     end
% end

%% count potential for reduction of information content
% totalswitches = zeros(1,ncols);
% totalneighborrels = zeros(1,ncols);
% for c=1:ncols
%     totalswitches(1,c) = sum(abs(FACESWITCH(:,c)));
%     totalneighborrels(1,c) = sum(NFACES(:,c));
% end
% plot(totalneighborrels,totalswitches,'.','MarkerSize',14,'Color',[0 0 0]+0);
% xlim([min(totalneighborrels(1,:))*0.95 max(totalneighborrels(1,:))*1.05]);
% ylim([0 30]);
% grid('on');
% set(gca,'Units','normalized','FontUnits','points','FontWeight','normal','FontSize',20,'FontName','Times')
% xlabel({'Sum of faces in the system (w/o double counting)'},'FontUnits','points','interpreter','latex','FontSize',20,'FontName','Times')
% ylabel({'Total number of switches per time step'},'FontUnits','points','interpreter','latex','FontSize',20,'FontName','Times')
% print -depsc Riso2015SCubeBiCrystalTopologicalChanges.eps
% print -dpng Riso2015SCubeBiCrystalTopologicalChanges.png

% %% plotting
% finalav=mean(VOLUME(:,ncols));
% scale=40.0;
% i=0;
% for gr=1:nrows
%     if (VOLUME(gr,ncols) > scale*finalav)
%         i=i+1;
%     end
% end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 
% 
% 
% %set(gca,'xscale','log');
% xlim([min(IDS(1,:)) max(IDS(1,:))]);
% 
% set(gca,'Units','normalized','FontUnits','points','FontWeight','normal','FontSize',16,'FontName','Times')
% %NFACES VOLUME
% xlabel({'Time (s)'},'FontUnits','points','interpreter','latex','FontSize',16,'FontName','Times')
% ylabel({'Number of faces'},'FontUnits','points','interpreter','latex','FontSize',16,'FontName','Times')
% zlabel({'Normalized grain area'},'FontUnits','points','interpreter','latex','FontSize',16,'FontName','Times')
% 
% %NFACES GBTYPE
% xlabel({'Time (s)'},'FontUnits','points','interpreter','latex','FontSize',16,'FontName','Times')
% ylabel({'Number of faces'},'FontUnits','points','interpreter','latex','FontSize',16,'FontName','Times')
% zlabel({'Mobility*Energy ($m^2$/s)'},'FontUnits','points','interpreter','latex','FontSize',16,'FontName','Times')
% 
% %VOLUME GBTYPE
% xlabel({'Time (s)'},'FontUnits','points','interpreter','latex','FontSize',16,'FontName','Times')
% ylabel({'Normalized grain area'},'FontUnits','points','interpreter','latex','FontSize',16,'FontName','Times')
% zlabel({'Mobility*Energy ($m^2$/s)'},'FontUnits','points','interpreter','latex','FontSize',16,'FontName','Times')
% 
% view(-45,14);
% print -dpng SCubeBicrystal.VolTopoTime.png
% print -dpng SCubeBicrystal.NFacesMobEnergyTime.png
% print -dpng SCubeBicrystal.VolumeMobEnergyTime.png
% 
% view(0,0);
% print -dpng SCubeBicrystal.VolTime.png
% print -dpng SCubeBicrystal.MobEnergyTime.png
% print -dpng SCubeBicrystal.MobEnergyTime.png
% 
% view(-90,0);
% print -dpng SCubeBicrystal.VolTopo.png
% print -dpng SCubeBicrystal.MobEnergyNFaces.png
% print -dpng SCubeBicrystal.MobEnergyVolume.png
% 
% view(0,90);
% print -dpng SCubeBicrystal.TopoTime.png
% print -dpng SCubeBicrystal.NFacesTime.png
% 
% 
% grid('on');
% view(-45,14);
% print -depsc Riso2015SCubeBicrystalAtBndVolTopoTime.10000.3D.eps
% view(0,0);
% print -depsc Riso2015SCubeBicrystalAtBndVolTime.10000.3D.eps
% view(0,90);
% print -depsc vepsRiso2015SCubeBicrystalAtBndTopoTime.10000.3D.eps
% 
% 
% 
% 
% figure;
% plot3(IDS(maxid,:),NFACES(maxid,:),VOLUME(maxid,:),'b','LineWidth',2,'Color',[0 0 1]); %,'.'); %( % 1) fac(:)],'.'),%'.')
% grid('on');
% 
% 
% %view(-35,14);
% view(0,0); %vol=f(time)
% view(-90,0); %vol=f(topo)
% view(0,90); %topo=f(time)
% 
% figureHandle = gcf;
% set(findall(figureHandle,'type','text'),'fontSize',12,'fontName','Calibri'); %'fontWeight','bold')
% %axes('fontName','Calibri','fontSize',12);
% axesHandle = gca;
% set(gca,'fontName','Calibri','fontSize',12);
% 
% print -dpng AllLargerThan3TimesTheAverage.png
% %print -deps fname.eps
% %print -depsc fname.eps
% 
% 
% 
% %% temporal evolution classes still buggy####
% [hc,hw] = hist(NFACES(:,2));
% nbins = length(hc);
% faceevolution = zeros(nbins,ncols);
% figure
% for c=1:20:ncols
%     [hc,hw] = hist(NFACES(:,c));
%     %for b=1:nbins
%         faceevolution(b,c) = hc(b);
%     %end
%     hold on
%     plot(hw, hc,'Color',[0 0 c/ncols])
% end
%     
% %% sorting
% %HERE IS A BUG AT THE MOMENT ...
% AS = sortrows(VOLUME,ncols,'descend');
% A = sort(A,ncols,'ascend');
% 
% 
% %% isocontour - still debuggy
% figure
% row = linspace(1,ncols-1,ncols-1);
% col = linspace(1,ncols-1,ncols-1);
% for r=1:ncols-1
%     for c=1:ncols-1
%         chi(r,c)=NFACES(r,c);
%     end;
% end;
% pcolor(row,col,NFACES);
% 
% %[C, h] = contourf(ee0, eee, chi)
% %set(h,'LineColor','none')
% pcolor(ee0,eee,chi)
% shading flat
% %colormap(map)
% colormap gray
% colorbar
% xlabel(['<110>'])
% ylabel(['<111>'])
% %mark sphere
% %hold on
% %plot(sq2,sq3,'*','MarkerSize',8,'Color',[1 1 1])
% hold on
% plot(0.7957,0.6494,'x','MarkerSize',10,'Color',[0 0 0])
% %plot(0.7957,0.6494,'o','MarkerSize',8,'Color',[1 1 1])