/*
#include "TopologyTracer2D3D_Defs.h"
#include "TopologyTracer2D3D_Datatypes.h"
#include "TopologyTracer2D3D_Math.h"



#ifndef TOPOLOGYTRACER2D3D_SNAPSHOT_H_
#define TOPOLOGYTRACER2D3D_SNAPSHOT_H_



#endif /* TOPOLOGYTRACER2D3D_SNAPSHOT_H */
*/
