/*
	Copyright Markus K�hbach, 2015-2017

	TopologyTracer is an MPI-parallel datamining tool for the conducting of spatiotemporal 
	analyses of microstructural element dynamics. Its purpose is the quantification of correlations
	--- spatial and temporal --- between individual microstructural elements and their 
	higher-order neighboring elements. Specifically, its current functionalities allow to 
	study the volume evolution of individual grains over time and set their growth history into 
	relation to the evolution of the higher-order neighbors. The tool is unique insofar as it 
	allows processing these individual surveys in a parallelized manner. Thus, enabling the 
	post-processing of so far intractable large datasets.

	The source code was developed by Markus K�hbach during his PhD time with Luis A. Barrales-Mora 
	and G�nter Gottstein at the Institute of Physical Metallurgy and Metal Physics with RWTH Aachen University. 
	Being now with the Max-Planck-Institut fur Eisenforschung GmbH in Dusseldorf, I maintain the code, 
	though at disregular intervals. Nonetheless, feel free to utilize the tool, do not hesitate contacting 
	me for sharing thoughts, suggesting improvements, or reporting your experiences.
	markus.kuehbach at rwth-aachen.de and m.kuehbach at mpie.de


	The authors gratefully acknowledge the financial support from the Deutsche Forschungsgemeinschaft
	(DFG) within the Reinhart Koselleck-Project (GO 335/44-1) and computing time grants kindly provided
	by RWTH Aachen University and the FZ J�lich within the scope of the JARAHPC project JARA0076.


	This file is part of TopologyTracer.

	TopologyTracer is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TopologyTracer is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with SCORE.  If not, see <http://www.gnu.org/licenses/>.
*/


//copy these code snippets into the volanaHdl class

//into the volanaHdl:: class definition
//MK::beta implementation of solving the intersection volume analytically
#ifdef DONOT_UTILIZE_TETGEN
	void init( void );
	void test_tetgen( void );
	void test_singlegrain_vtk( std::string vtkfname, unsigned int dgid );
	void test_singlegrain_modifydata_GraGeLeS( unsigned int gid );
	bool test_singlegrain_tetgen( unsigned int gid );
	double test_singlegrain_volume( unsigned int gid );
	void test_topo2tetgen( unsigned int gid );
	void test_tetgen2topo( void );
	void test_clearPLC( unsigned int gid );
	bool read_vtkfile( std::string fname, unsigned int desired_gid );

	std::vector<std::vector<idtriplet>*> gPLCtris;			//reference to the vertices of all triangles comprising the hull of the grain
	std::vector<std::vector<point3d>*> gPLCverts;			//coordinates of the vertices supporting the piecewise linear complex enculling the grain
	std::vector<std::vector<tetrahedron>*> gsegments3d;		//the tetrahedra which reconstruct spacefilling the hull
#endif



//into the function definition
#ifdef DONOT_UTILIZE_TETGEN
void volanaHdl::init( void ) {
	//init contour buckets, as ID hashs
	double timer = MPI_Wtime();

	struct isectionmeta dummy;
	unsigned int n = 1 + Settings::LargestGrainID;

	for ( unsigned int c = 0; c < n; c++ ) {
		gPLCtris.push_back( NULL );
		gPLCverts.push_back( NULL );
		//set up meta data grain ID hash, 
		//MK::a compromise approach, namely if grainIDs are sparse, the hash provokes frequent far field fetches for which searching through a list would be faster
		//however, if gmetadata is populated dense, searching would always have to be executed for all to avoid one far field miss
		//gmetadata.push_back( dummy );

		gsegments3d.push_back( NULL );
	}

	myprofiler.logev( "InitializeMemory", (double) (MPI_Wtime() - timer) );
}

void volanaHdl::test_tetgen( void ) {
	tetgenio in, out;
	tetgenio::facet *f;
	tetgenio::polygon *p;
	int i;

	tetgenbehavior* calls = new tetgenbehavior;
	bool tetstatus = calls->parse_commandline( "pq1.414a0.1" );

	// All indices start from 1.
	in.firstnumber = 1;

	in.numberofpoints = 8;
	in.pointlist = new REAL[in.numberofpoints * 3];
	in.pointlist[0]  = 0;  // node 1.
	in.pointlist[1]  = 0;
	in.pointlist[2]  = 0;
	in.pointlist[3]  = 2;  // node 2.
	in.pointlist[4]  = 0;
	in.pointlist[5]  = 0;
	in.pointlist[6]  = 2;  // node 3.
	in.pointlist[7]  = 2;
	in.pointlist[8]  = 0;
	in.pointlist[9]  = 0;  // node 4.
	in.pointlist[10] = 2;
	in.pointlist[11] = 0;
	// Set node 5, 6, 7, 8.
	for (i = 4; i < 8; i++) {
	in.pointlist[i * 3]     = in.pointlist[(i - 4) * 3];
	in.pointlist[i * 3 + 1] = in.pointlist[(i - 4) * 3 + 1];
	in.pointlist[i * 3 + 2] = 12;
	}

	in.numberoffacets = 6;
	in.facetlist = new tetgenio::facet[in.numberoffacets];
	in.facetmarkerlist = new int[in.numberoffacets];

	// Facet 1. The leftmost facet.
	f = &in.facetlist[0];
	f->numberofpolygons = 1;
	f->polygonlist = new tetgenio::polygon[f->numberofpolygons];
	f->numberofholes = 0;
	f->holelist = NULL;
	p = &f->polygonlist[0];
	p->numberofvertices = 4;
	p->vertexlist = new int[p->numberofvertices];
	p->vertexlist[0] = 1;
	p->vertexlist[1] = 2;
	p->vertexlist[2] = 3;
	p->vertexlist[3] = 4;
  
	// Facet 2. The rightmost facet.
	f = &in.facetlist[1];
	f->numberofpolygons = 1;
	f->polygonlist = new tetgenio::polygon[f->numberofpolygons];
	f->numberofholes = 0;
	f->holelist = NULL;
	p = &f->polygonlist[0];
	p->numberofvertices = 4;
	p->vertexlist = new int[p->numberofvertices];
	p->vertexlist[0] = 5;
	p->vertexlist[1] = 6;
	p->vertexlist[2] = 7;
	p->vertexlist[3] = 8;

	// Facet 3. The bottom facet.
	f = &in.facetlist[2];
	f->numberofpolygons = 1;
	f->polygonlist = new tetgenio::polygon[f->numberofpolygons];
	f->numberofholes = 0;
	f->holelist = NULL;
	p = &f->polygonlist[0];
	p->numberofvertices = 4;
	p->vertexlist = new int[p->numberofvertices];
	p->vertexlist[0] = 1;
	p->vertexlist[1] = 5;
	p->vertexlist[2] = 6;
	p->vertexlist[3] = 2;

	// Facet 4. The back facet.
	f = &in.facetlist[3];
	f->numberofpolygons = 1;
	f->polygonlist = new tetgenio::polygon[f->numberofpolygons];
	f->numberofholes = 0;
	f->holelist = NULL;
	p = &f->polygonlist[0];
	p->numberofvertices = 4;
	p->vertexlist = new int[p->numberofvertices];
	p->vertexlist[0] = 2;
	p->vertexlist[1] = 6;
	p->vertexlist[2] = 7;
	p->vertexlist[3] = 3;

	// Facet 5. The top facet.
	f = &in.facetlist[4];
	f->numberofpolygons = 1;
	f->polygonlist = new tetgenio::polygon[f->numberofpolygons];
	f->numberofholes = 0;
	f->holelist = NULL;
	p = &f->polygonlist[0];
	p->numberofvertices = 4;
	p->vertexlist = new int[p->numberofvertices];
	p->vertexlist[0] = 3;
	p->vertexlist[1] = 7;
	p->vertexlist[2] = 8;
	p->vertexlist[3] = 4;

	// Facet 6. The front facet.
	f = &in.facetlist[5];
	f->numberofpolygons = 1;
	f->polygonlist = new tetgenio::polygon[f->numberofpolygons];
	f->numberofholes = 0;
	f->holelist = NULL;
	p = &f->polygonlist[0];
	p->numberofvertices = 4;
	p->vertexlist = new int[p->numberofvertices];
	p->vertexlist[0] = 4;
	p->vertexlist[1] = 8;
	p->vertexlist[2] = 5;
	p->vertexlist[3] = 1;

	// Set 'in.facetmarkerlist'

	in.facetmarkerlist[0] = -1;
	in.facetmarkerlist[1] = -2;
	in.facetmarkerlist[2] = 0;
	in.facetmarkerlist[3] = 0;
	in.facetmarkerlist[4] = 0;
	in.facetmarkerlist[5] = 0;

	// Output the PLC to files 'barin.node' and 'barin.poly'.
	in.save_nodes("barin");
	in.save_poly("barin");

	// Tetrahedralize the PLC. Switches are chosen to read a PLC (p),
	//   do quality mesh generation (q) with a specified quality bound
	//   (1.414), and apply a maximum volume constraint (a0.1).

	tetrahedralize( calls, &in, &out);

	// Output mesh to files 'barout.node', 'barout.ele' and 'barout.face'.
	out.save_nodes("barout");
	out.save_elements("barout");
	out.save_faces("barout");
}

void volanaHdl::test_singlegrain_vtk( std::string vtkfname, unsigned int dgid  ) {
	//read 3D hull of a single grain from vtkfname VTK file into datastructure
	double timer = MPI_Wtime();

	if ( read_vtkfile( vtkfname, dgid ) == false ) { cout << "ERR::Unable to locate " << vtkfname << " .VTK file" << endl; return; }

	myprofiler.logev( "ReadSingleVTKFile", (double) (MPI_Wtime() - timer) );
	cout << vtkfname << " was read successfully in " << (double) (MPI_Wtime() - timer) << " seconds" << endl;
}

void volanaHdl::test_singlegrain_modifydata_GraGeLeS( unsigned int gid ) {
	//implement model specific affine transformations and other data format unification and scaling work
	//##MK::VTK outputs px, however, we are interested in positions on a unit cube
	double timer = MPI_Wtime();

	//##MK::run for loop of all IDs {
		if ( gPLCverts.at(gid) != NULL ) {
			unsigned int np = gPLCverts.at(gid)->size();
			double _px2unitcube = 1.0;

			for ( unsigned int p = 0; p < np; p++ ) {
				gPLCverts.at(gid)->at(p).x *= _px2unitcube; //reads are cache efficient
				gPLCverts.at(gid)->at(p).y *= _px2unitcube;
				gPLCverts.at(gid)->at(p).z *= _px2unitcube;
			}
		}
	//##}

	myprofiler.logev( "ModifyData", (double) (MPI_Wtime() - timer) );
	cout << "Modified input data successfully in " << (double) (MPI_Wtime() - timer) << " seconds" << endl;
}

bool volanaHdl::test_singlegrain_tetgen( unsigned int gid ) {
	//calling TetGen to tetrahedralize the PLC
	double timer = MPI_Wtime();

	bool good = true;

	//get tetgen structure
	test_topo2tetgen( gid ); //generate tetgen structures for a particular grain

	//##if ( == false ) { cout << "ERR::Tetrahedralization of grain " << gid << " was unsuccessful!" << endl; //##MK::empty return false; tetrahedralize by tetgen

	std::vector<tetrahedron>* tets = NULL; //allocate memory for storing tetrahedra
	tets = new std::vector<tetrahedron>;
	this->gsegments3d.at(gid) = tets;

	test_tetgen2topo(); //copy results from tetgen

	test_clearPLC( gid );

	myprofiler.logev( "ReadSingleVTKFile", (double) (MPI_Wtime() - timer) );
	cout << "Tetrahedralization of grain " << gid << " successful, took " << (double) (MPI_Wtime() - timer) << " seconds" << endl;
	return true;
}

double volanaHdl::test_singlegrain_volume( unsigned int gid ) {
	//returns volume of grain hull gid
	double volume = 0;
	double one_sixth = (1.0f / 6.0f);
	for (unsigned int i = 0; i < gPLCtris.at(gid)->size(); i++) {
		/*double v321 = tri.points[2][0] * tri.points[1][1] * tri.points[0][2];
		double v231 = tri.points[1][0] * tri.points[2][1] * tri.points[0][2];
		double v312 = tri.points[2][0] * tri.points[0][1] * tri.points[1][2];
		double v132 = tri.points[0][0] * tri.points[2][1] * tri.points[1][2];
		double v213 = tri.points[1][0] * tri.points[0][1] * tri.points[2][2];
		double v123 = tri.points[0][0] * tri.points[1][1] * tri.points[2][2];*/

		unsigned int uu = gPLCtris.at(gid)->at(i).u;
		unsigned int vv = gPLCtris.at(gid)->at(i).v;
		unsigned int ww = gPLCtris.at(gid)->at(i).w;
		
		double tri00 = gPLCverts.at(gid)->at(uu).x;
		double tri01 = gPLCverts.at(gid)->at(uu).y;
		double tri02 = gPLCverts.at(gid)->at(uu).z;
		double tri10 = gPLCverts.at(gid)->at(vv).x;
		double tri11 = gPLCverts.at(gid)->at(vv).y;
		double tri12 = gPLCverts.at(gid)->at(vv).z;
		double tri20 = gPLCverts.at(gid)->at(ww).x;
		double tri21 = gPLCverts.at(gid)->at(ww).y;
		double tri22 = gPLCverts.at(gid)->at(ww).z;

		double v321 = tri20 * tri11 * tri02;
		double v231 = tri10 * tri21 * tri02;
		double v312 = tri20 * tri01 * tri12;
		double v132 = tri00 * tri21 * tri12;
		double v213 = tri10 * tri01 * tri22;
		double v123 = tri00 * tri11 * tri22;

		volume += one_sixth * (-v321 + v231 + v312 - v132 - v213 + v123);
	}
	double h = 1.0 / Settings::InitialDomainEdgeLength;
	volume = abs(volume) * h * h * h;

	return volume;
}

void volanaHdl::test_topo2tetgen( unsigned int gid ) {
	//passes individual grain hulls to TetGen and performs tetrahedralization
	tetgenio in, out;
	tetgenio::facet *f;
	tetgenio::polygon *p;
	int i;

	double TetGenMaximalVol = (1.0/100.0) * test_singlegrain_volume( gid );
	string args = "pq2.0a10.0v";

	tetgenbehavior* calls = new tetgenbehavior;
	bool tetstatus = calls->parse_commandline( "pq2.0a10.0v" );

	in.firstnumber = 0;	 // indices in GraGLeS and TopoTracer for faces start from 0

	std::vector<point3d>* thatplc = NULL;
	thatplc = gPLCverts.at(gid);
	unsigned int nv = thatplc->size();

	in.numberofpoints = nv; //int
	in.pointlist = new REAL[nv*3];
	for ( unsigned int v = 0; v < nv; v++ ) { //add vertices
		in.pointlist[v*3+0] = thatplc->at(v).x;
		in.pointlist[v*3+1] = thatplc->at(v).y;
		in.pointlist[v*3+2] = thatplc->at(v).z;
	}

	std::vector<idtriplet>* thatt = NULL;
	thatt = gPLCtris.at(gid);
	unsigned int nt = thatt->size();

	in.numberoffacets = nt;
	in.facetlist = new tetgenio::facet[in.numberoffacets];
	in.facetmarkerlist = NULL; //new int[in.numberoffacets]; //##??

	for ( unsigned int t = 0; t < nt; t++ ) { //add facets
		f = &in.facetlist[t];
		f->numberofpolygons = 1;
		f->polygonlist = new tetgenio::polygon[f->numberofpolygons];
		f->numberofholes = 0;
		f->holelist = NULL;

		p = &f->polygonlist[0];
		p->numberofvertices = 3;
		p->vertexlist = new int[p->numberofvertices];
		p->vertexlist[0] = thatt->at(t).u;
		p->vertexlist[1] = thatt->at(t).v;
		p->vertexlist[2] = thatt->at(t).w;
	}
	

	// Set 'in.facetmarkerlist'
	/*in.facetmarkerlist[0] = -1;
	in.facetmarkerlist[1] = -2;
	in.facetmarkerlist[2] = 0;
	in.facetmarkerlist[3] = 0;
	in.facetmarkerlist[4] = 0;
	in.facetmarkerlist[5] = 0;*/

	// Output the PLC to files 'barin.node' and 'barin.poly'.
	in.save_nodes("barin");
	in.save_poly("barin");

	// Tetrahedralize the PLC. Switches are chosen to read a PLC (p),
	//   do quality mesh generation (q) with a specified quality bound
	//   (1.414), and apply a maximum volume constraint (a).

	tetrahedralize( calls, &in, &out);

	// Output mesh to files 'barout.node', 'barout.ele' and 'barout.face'.
	out.save_nodes("barout");
	out.save_elements("barout");
	out.save_faces("barout");
}

void volanaHdl::test_tetgen2topo( void ) { //still arguments missing
}

void volanaHdl::test_clearPLC( unsigned int gid ) {
	if ( gPLCtris.at(gid) != NULL ) { //when IDs in this range where there
		delete gPLCtris[gid];
		gPLCtris[gid] = NULL;
	}

	if ( gPLCverts.at(gid) != NULL ) {
		delete gPLCverts[gid];
		gPLCverts[gid] = NULL;
	}
}

bool volanaHdl::read_vtkfile( std::string fname, unsigned int desired_gid ) {
	//MK::read 3D hull of a single grain from vtkfname VTK file into datastructure
	//reading an UDS File MicrostructureDiagnostics for computation unbiased chi values by adding the orientation and SEE of the grains that which is not part of the GNU file
	//ASCII file with a header comprising 6 lines in 2D and 8 lines in 3D utilizing only either empty lines (LF or CRLF) or tab separated strings or a single string
	ifstream vtkfile;
	string vtkline;
	istringstream line;
	string datapiece;

	struct isectionmeta dat;
	struct point3d ap;
	struct idtriplet tt;
	unsigned int gid = desired_gid;
	if ( gid > Settings::LargestGrainID ) {
		cout << "ERROR::Invalid desired ID! It is larger than Settings::LargestGrainID!" << endl; return false; 
	}

	vtkfile.open( fname.c_str() ); //open( Settings::UDSDataFromFilename );
	if ( vtkfile.is_open() == true ) { //read in file
		unsigned int nheaderlines = 5;

		unsigned int j = 0; //jump over header
		while ( vtkfile.good() == true && j < nheaderlines ) {
			getline( vtkfile, vtkline);
			j++;
		}

		std::vector<point3d>* vert = NULL; //init temporary storage containers!
		vert = new std::vector<point3d>;

		std::vector<idtriplet>* tri = NULL;
		tri = new std::vector<idtriplet>;

		if ( vtkfile.good() == true ) { //read number of disjoint vertices
			getline( vtkfile, vtkline );

			unsigned int nvertices = 0;
			if ( vtkline.size() > 0 ) { //not empty
				istringstream line( vtkline );
				getline(line, datapiece, ' ');
				getline(line, datapiece, ' '); nvertices = atoi( datapiece.c_str() );
				getline(line, datapiece, ' ');

cout << nvertices << " vertices" << endl;
				j = 0;
				while ( vtkfile.good() == true && j < nvertices ) {
					getline( vtkfile, vtkline);
					//###MK::skip checking format of each line
					istringstream line( vtkline );
					getline(line, datapiece, ' ');	ap.x = atof( datapiece.c_str() );
					getline(line, datapiece, ' ');	ap.y = atof( datapiece.c_str() );
					getline(line, datapiece, ' ');	ap.z = atof( datapiece.c_str() );

					vert->push_back( ap );
//cout << ap.x << "\t\t" << ap.y << "\t\t" << ap.z << endl;
					
					j++;
				}

				if ( vtkfile.good() == true ) { //read number of disjoint triangles of grain hull
					getline ( vtkfile, vtkline );

					unsigned int nids = 0;
					if ( vtkline.size() > 0 ) { //not an empty line
						istringstream line( vtkline );

						getline(line, datapiece, ' ');
						getline(line, datapiece, ' '); nids = atoi( datapiece.c_str() );
						getline(line, datapiece, ' ');

cout << nids << " ids" << endl;
						j = 0;
						while( vtkfile.good() == true && j < nids ) {
							getline( vtkfile, vtkline );
							istringstream line ( vtkline );
							getline(line, datapiece, ' '); //skip VTK piece of information how many vertices for thew polygon
							//MK::GraGLeS utilizes clock-wise ordering of triangles in a right-handed coordinate system
							getline(line, datapiece, ' '); tt.u = atoi( datapiece.c_str() );
							getline(line, datapiece, ' '); tt.v = atoi( datapiece.c_str() );
							getline(line, datapiece, ' '); tt.w = atoi( datapiece.c_str() );

							tri->push_back( tt );
//cout << tt.u << "\t\t" << tt.v << "\t\t" << tt.w << endl;
							//collecting
							j++;
						} //done reading id triplets

						//##MK::do not read field data such as interestingness
					}
				} //triangles read
			}
		} //finish vertices

		//register
		this->gPLCtris.at(gid) = tri;
		this->gPLCverts.at(gid) = vert;

		vtkfile.close();
	}
	else { 
		cout << "ERR::Unable to load file " << fname << endl; return false;
	}
	return true;
}
#endif 



//into the volanaHdl::default destructor
#ifdef DONOT_UTILIZE_TETGEN
	//##MK::later gPLC will have been deleted successively already!
	for ( unsigned int c = 0; c < gPLCtris.size(); c++  ) {
		if ( gPLCtris[c] != NULL ) { //when IDs in this range where there
			delete gPLCtris[c];
			gPLCtris[c] = NULL;
		}
	}

	for ( unsigned int c = 0; c < gPLCverts.size(); c++ ) {
		if ( gPLCverts[c] != NULL ) {
			delete gPLCverts[c];
			gPLCverts[c] = NULL;
		}
	}

	for ( unsigned int c = 0; c < gsegments3d.size(); c++ ) {
		if ( gsegments3d[c] != NULL ) {
			delete gsegments3d[c];
			gsegments3d[c] = NULL;
		}
	}
#endif
