/*
*	TopologyTracer2D3D_Iohdl.cpp
*	Created on: July 12, 2016
*	Author: Markus Kuehbach, markus.kuehbach at rwth-aachen.de
*/

#include "TopologyTracer2D3D_Iohdl.h"


ioHdl::ioHdl()
{
	myRank = MASTER;
	nRanks = SINGLE_PROCESS;
}


ioHdl::~ioHdl()
{
}


