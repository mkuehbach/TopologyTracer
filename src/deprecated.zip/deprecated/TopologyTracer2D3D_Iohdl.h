/*
*	TopologyTracer2D3D_Main.cpp
*	Created on: July 12, 2016
*	Author: Markus Kuehbach, markus.kuehbach at rwth-aachen.de
*/

#include "TopologyTracer2D3D_Datatypes.h"


class ioHdl //: public io, public randomClass, public mathMethods
{
public:
	ioHdl();
	~ioHdl();

/*
	void init_mpitypes( void );
	void cstyle_binary_writing( const char* fname );
	void mpiiostyle_binary_reading( const char* fname );
*/

	int myRank;
	int nRanks;
};
typedef class ioHdl * ioHdlP;
