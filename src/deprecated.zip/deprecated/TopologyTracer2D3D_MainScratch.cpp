/*
	Copyright Markus K�hbach, 2015-2017

	TopologyTracer is an MPI-parallel datamining tool for the conducting of spatiotemporal 
	analyses of microstructural element dynamics. Its purpose is the quantification of correlations
	--- spatial and temporal --- between individual microstructural elements and their 
	higher-order neighboring elements. Specifically, its current functionalities allow to 
	study the volume evolution of individual grains over time and set their growth history into 
	relation to the evolution of the higher-order neighbors. The tool is unique insofar as it 
	allows processing these individual surveys in a parallelized manner. Thus, enabling the 
	post-processing of so far intractable large datasets.

	The source code was developed by Markus K�hbach during his PhD time with Luis A. Barrales-Mora 
	and G�nter Gottstein at the Institute of Physical Metallurgy and Metal Physics with RWTH Aachen University. 
	Being now with the Max-Planck-Institut fur Eisenforschung GmbH in Dusseldorf, I maintain the code, 
	though at disregular intervals. Nonetheless, feel free to utilize the tool, do not hesitate contacting 
	me for sharing thoughts, suggesting improvements, or reporting your experiences.
	markus.kuehbach at rwth-aachen.de and m.kuehbach at mpie.de


	The authors gratefully acknowledge the financial support from the Deutsche Forschungsgemeinschaft
	(DFG) within the Reinhart Koselleck-Project (GO 335/44-1) and computing time grants kindly provided
	by RWTH Aachen University and the FZ J�lich within the scope of the JARAHPC project JARA0076.


	This file is part of TopologyTracer.

	TopologyTracer is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TopologyTracer is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with SCORE.  If not, see <http://www.gnu.org/licenses/>.
*/





/*
	//TESTING
	arealanaHdlP worker = new arealanaHdl;
	//typical v1e2 numerics issue example
	//istringstream line( "ERROR::gidx/tri/Atri/Aana/xy012xcycr;22573;69;5.66001449999962519e-12;-3.23243346550371817e-14;0.0319031999999999996;9.4959e-06;0.0308030999999999999;9.50756999999999984e-06;0.0326366000000000017;9.49840999999999941e-06;0.0304731546018983286;0.0200061850274757952;0.0200000000000000004");
	//typical v2e3 numerics issue example
	//istringstream line( "ERROR::gidx/tri/Atri/Aana/xy012xcycr;1055686;2;2.54812987696960175e-21;-666;0.00788411999999999967;0.107106999999999994;0.00715072000000000017;0.107143000000000002;0.00770077000000000001;0.107116000000000003;0.0272141208934985855;0.107524323809976924;0.0200000000000000004");
	//typical numerics flaw example with negative intersection area and small almost degenerated triangle which in circular cap computation results in rounding issues...
	istringstream line( "ERROR::gidx/tri/Atri/Aana/xy012xcycr;155870;0;4.45000000077643322e-13;-3.02086834606783458e-13;0.0975324999999999942;0.0154015000000000003;0.0977264000000000049;0.0155130000000000007;0.0975430999999999937;0.0154076000000000005;0.0789780431524609305;0.0225039845850084456;0.0200000000000000004");





//TESTING
	arealanaHdlP worker = (arealanaHdlP) new arealanaHdl;
	//worker->test_pqsolve( atof(argv[1]), atof(argv[2]), atof(argv[3]) );
	//worker->test_circular_cap( atof(argv[1]), atof(argv[2]) );
	//test stability against rotation of the input arguments
	worker->test_intersection( atof(argv[1]), atof(argv[2]), atof(argv[3]), atof(argv[4]), atof(argv[5]), atof(argv[6]),  atof(argv[7]), atof(argv[8]), atof(argv[9]) );
	delete worker;
	return 0;

	arealanaHdlP worker = new arealanaHdl;
	istringstream line( "ERROR::gidx/tri/Atri/Aana/xy012xcycr;192065;14;5.97488499999976439e-08;-666;0.753942000000000001;0.0186133999999999987;0.75586399999999998;0.0187019000000000005;0.754125000000000045;0.0186839999999999992;0.754787449151937628;0.0180793110830934668;0.0010000000000000000" );
	string datapiece;
	double x1,y1,x2,y2,x3,y3,xc,yc,r;
	getline(line, datapiece, ';');
	getline(line, datapiece, ';');
	getline(line, datapiece, ';');
	getline(line, datapiece, ';');
	getline(line, datapiece, ';');
	getline(line, datapiece, ';'); x1 = stod( datapiece.c_str() ); //atof(datapiece.c_str());
	getline(line, datapiece, ';'); y1 = stod( datapiece.c_str() ); //atof(datapiece.c_str());
	getline(line, datapiece, ';'); x2 = stod( datapiece.c_str() ); //atof(datapiece.c_str());
	getline(line, datapiece, ';'); y2 = stod( datapiece.c_str() ); //atof(datapiece.c_str());
	getline(line, datapiece, ';'); x3 = stod( datapiece.c_str() ); //atof(datapiece.c_str());
	getline(line, datapiece, ';'); y3 = stod( datapiece.c_str() ); //atof(datapiece.c_str());
	getline(line, datapiece, ';'); xc = stod( datapiece.c_str() ); //atof(datapiece.c_str());
	getline(line, datapiece, ';'); yc = stod( datapiece.c_str() ); //atof(datapiece.c_str());
	getline(line, datapiece, ';'); r = stod( datapiece.c_str() ); //atof(datapiece.c_str());

	double test = worker->intersection_area_triangle_circle( x1, y1, x2, y2, x3, y3, xc, yc, r );
	if ( test < 0.0 ) cout << "PROBLEM " << setprecision(32) << test << endl;
	else cout << "NO PROBLEM " << setprecision(32) << test << endl;
	delete worker;
	return 0;
*/


/*
//TESTING
	arealanaHdlP worker = (arealanaHdlP) new arealanaHdl;
	//worker->test_pqsolve( atof(argv[1]), atof(argv[2]), atof(argv[3]) );
	//worker->test_circular_cap( atof(argv[1]), atof(argv[2]) );
	//test stability against rotation of the input arguments
	worker->test_intersection( atof(argv[1]), atof(argv[2]), atof(argv[3]), atof(argv[4]), atof(argv[5]), atof(argv[6]),  atof(argv[7]), atof(argv[8]), atof(argv[9]) );
	worker->test_intersection( atof(argv[1]), atof(argv[2]), atof(argv[5]), atof(argv[6]), atof(argv[3]), atof(argv[4]),  atof(argv[7]), atof(argv[8]), atof(argv[9]) );
	worker->test_intersection( atof(argv[3]), atof(argv[4]), atof(argv[1]), atof(argv[2]), atof(argv[5]), atof(argv[6]),  atof(argv[7]), atof(argv[8]), atof(argv[9]) );
	worker->test_intersection( atof(argv[3]), atof(argv[4]), atof(argv[5]), atof(argv[6]), atof(argv[1]), atof(argv[2]),  atof(argv[7]), atof(argv[8]), atof(argv[9]) );
	worker->test_intersection( atof(argv[5]), atof(argv[6]), atof(argv[1]), atof(argv[2]), atof(argv[3]), atof(argv[4]),  atof(argv[7]), atof(argv[8]), atof(argv[9]) );
	worker->test_intersection( atof(argv[5]), atof(argv[6]), atof(argv[3]), atof(argv[4]), atof(argv[1]), atof(argv[2]),  atof(argv[7]), atof(argv[8]), atof(argv[9]) );
	delete worker;
	return 0;
//END OF TESTING INTERSECTION
		cout << "##MK::Reactivate read_metadata() and set checkPlausibility to true!" << endl;
		cout << "##MK::Add selfmonitoring!" << endl;
*/






/*	
	struct pqsolve r;
	r = worker->CircleLineSegmentIntersection( -2.0, 0.0, 2.0, 0.0, 0.0, (1.0-2*DOUBLE_EPSILON), 1.0 );
cout << "nsol/sol1/sol2 = " << r.nsol << "\t\t" << setprecision(18) << r.sol1 << "\t\t" << setprecision(18) << r.sol2 << endl;

	int nranks, rank;
	MPI_Init( NULL, NULL );
	MPI_Comm_size(MPI_COMM_WORLD, &nranks);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	char* recvbuf = new char[3];
	recvbuf[0] = 0x00;
	recvbuf[1] = 0x00;
	recvbuf[2] = 0x00;
	char* sendbuf = new char[3];
	sendbuf[0] = 0x01;
	sendbuf[1] = 0x01;
	sendbuf[2] = 0x01;

	if ( rank == MASTER) 
		cout << "Begin=" << (int) recvbuf[0] << ";" << (int) recvbuf[1] << ";" << (int) recvbuf[2] << endl;
	if ( rank == MASTER )
		MPI_Reduce( MPI_IN_PLACE, recvbuf, 3, MPI_CHAR, MPI_BAND, MASTER, MPI_COMM_WORLD ); 
		//BAND in combination with 0x00 for DO_NOT_ANALYZE and 0x01 for DO_ANALYZE sets all bits to 0 and therefore the entire char to 0x00 is not all bits in all char for one grain are set to 1
		//i.e. any process with the buffer[] entry being set to DO_NOT_ANALYZE will expell the grain
	if ( rank != MASTER )
		MPI_Reduce( sendbuf, sendbuf, 3, MPI_CHAR, MPI_BAND, MASTER, MPI_COMM_WORLD );

	if ( rank == MASTER)
		cout << "Enden=" << (int) recvbuf[0] << ";" << (int) recvbuf[1] << ";" << (int) recvbuf[2] << endl;

	delete [] recvbuf;
	delete [] sendbuf;
	MPI_Finalize();
	return 0;
const unsigned int n = 1000000*10;
	std::bitset<n> FlagFieldBit;
	vector<bool> FlagFieldBool;
	int rank,nranks;
	MPI_Init( NULL, NULL );
	MPI_Comm_size(MPI_COMM_WORLD, &nranks);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	double timer = MPI_Wtime();
	FlagFieldBit.set();
	for ( unsigned int i = n-1; i > 0; i-- ) {
		FlagFieldBit.set(i,0);
	}
	cout << "Bit=" << (double) (MPI_Wtime() - timer) << endl;

	timer = MPI_Wtime();
	for ( unsigned int i = n-1; i > 0; i-- ) 
		FlagFieldBool.push_back(true);
	for ( unsigned int i = n-1; i > 0; i-- )
		FlagFieldBool[i] = false;
	cout << "Bol=" << (double) (MPI_Wtime() - timer) << endl;


	MPI_Finalize();
	return 0;
*/

//cout << "Hello from " << worker->get_Rank() << " rank/nRanks = " << worker->get_Rank() << ";" << worker->get_nRanks() << endl;
//worker->hellow();
/*#include "TopologyTracer_IO_Test_Defs.h"
#include "TopologyTracer_IO_Test_DataTypes.h"

const unsigned long long size = 8ULL*1024ULL*1024ULL;
unsigned long long a[size];

#include <fstream>
#include <sstream>
#include <string>*/

/*
void init_mpitypes( void )
{
	//create MPI datatypes
	MPI_Datatype MPI_Grain2DPropsIO_Type;
	int elementCounts[2] = {2, 2};
	MPI_Aint displacements[2] = {0, 2 * MPIIO_OFFSET_INCR_UINT};
	MPI_Datatype oldTypes[2] = {MPI_UNSIGNED, MPI_DOUBLE};
	MPI_Type_create_struct(2, elementCounts, displacements, oldTypes, &MPI_Grain2DPropsIO_Type);

	MPI_Datatype MPI_SimMetaDataIO_Type;
	int elementCounts2[2] = {4, 4};
	MPI_Aint displacements2[2] = {0, 4 * MPIIO_OFFSET_INCR_UINT};
	MPI_Datatype oldTypes2[2] = {MPI_UNSIGNED, MPI_DOUBLE};
	MPI_Type_create_struct(2, elementCounts2, displacements2, oldTypes2, &MPI_SimMetaDataIO_Type);

	MPI_Datatype MPI_3DFaceIO_Type;
	int elementCounts3[2] = {1, 2};
	MPI_Aint displacements3[2] = {0, 1 * MPIIO_OFFSET_INCR_DOUBLE};
	MPI_Datatype oldTypes3[2] = {MPI_DOUBLE, MPI_UNSIGNED};
	MPI_Type_create_struct(2, elementCounts3, displacements3, oldTypes3, &MPI_3DFaceIO_Type);

	MPI_Datatype MPI_3DTextureIO_Type;
	int elementCounts4[2] = {10, 4 };
	MPI_Aint displacements4[2] = {0, 10 * MPIIO_OFFSET_INCR_DOUBLE};
	MPI_Datatype oldTypes4[2] = {MPI_DOUBLE, MPI_UNSIGNED};
	MPI_Type_create_struct(2, elementCounts4, displacements4, oldTypes4, &MPI_3DTextureIO_Type);

	MPI_Type_commit(&MPI_Grain2DPropsIO_Type);
	MPI_Type_commit(&MPI_SimMetaDataIO_Type);
	MPI_Type_commit(&MPI_3DFaceIO_Type);
	MPI_Type_commit(&MPI_3DTextureIO_Type);
	cout << "\t\tMPI IO Types committed ..." << endl;
}




int main(int argc, char** argv)
{
	cout << "TopologyTracer IO testing..." << endl;

	int nranks, rank;
	MPI_Init( NULL, NULL );
	MPI_Comm_size(MPI_COMM_WORLD, &nranks);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	ioHdlP tester = (ioHdlP) new ioHdl;
	tester->myRank = rank;
	tester->nRanks = nranks;

	init_mpitypes();

	//read individual file
	vector<t> controller;

	MPI_File iofhdl;
	MPI_Status iofsta;
	stringstream msfn;
	msfn << "Container.raw";
	int msfnlen = msfn.str().size();
	char* msf = new char[msfnlen+1];
	strcpy(msf, msfn.str().c_str());
	MPI_File_open(MPI_COMM_SELF, (char*) msf, MPI_MODE_RDONLY, MPI_INFO_NULL, &iofhdl);
	cout << "\t\tReading file " << msfn.str().c_str() << endl;
	MPI_File_seek(iofhdl, 0, MPI_SEEK_SET);

	unsigned int nslices = 1190;
	unsigned int* voxel = NULL;
	voxel = new unsigned int[nslices*nslices*nslices];
	unsigned int offset = 0;
	unsigned int* slice = NULL;
	slice = new unsigned int[nslices*nslices];
	cout << "nslices/2x/3x" << nslices << ";" << nslices*nslices << ";" << nslices*nslices*nslices << endl;

	for ( unsigned int s = 0; s < nslices; s++ ) {
		for ( unsigned int e = 0; e < nslices*nslices; e++ ) {
			slice[e] = 0;
		}

		MPI_File_read( iofhdl, slice, nslices*nslices, MPI_UNSIGNED, &iofsta);

		//explicit datatransfer
		for ( unsigned int e = 0; e < nslices*nslices; e++ ) {
			voxel[offset] = slice[e];
			offset++;
		}
		cout << "Reading slice " << s << " offset at " << offset << endl;
	}
	MPI_File_close(&iofhdl);

	delete [] slice; slice = NULL;

	//prefetch container
	controller.reserve(500000);
	for (unsigned int k = 0; k < 500000; k++ ) {
		struct t agr;
		//agr.id = k;
		agr.cnt = 0;
		agr.xmi = 2000;
		agr.xmx = 0;
		agr.ymi = 2000;
		agr.ymx = 0;
		agr.zmi = 2000;
		agr.zmx = 0;
		controller.push_back( agr );
	}


	//account for
	unsigned int gid = 0;
	bool unknown = true;
	unsigned int i = 0;
	unsigned int v = 0;
	unsigned int zoff = 0;
	unsigned int yoff = 0;
	for ( int z = 0; z < nslices; z++ ) {
		zoff = z*nslices*nslices;
		for ( int y = 0; y < nslices; y++ ) {
			yoff = y * nslices;
			for ( int x = 0; x < nslices; x++ ) {
				v = x + yoff + zoff;

				gid = voxel[v];

				if ( gid >= 500000 || gid < 1) { 
					cout << "ID fail in location x/y/z = " << x << ";" << y << ";" << z << endl;
				}

				controller[gid].cnt = controller[gid].cnt + 1;
				if ( x <= controller[gid].xmi ) controller[gid].xmi = x;
				if ( x >= controller[gid].xmx ) controller[gid].xmx = x;
				if ( y <= controller[gid].ymi ) controller[gid].ymi = y;
				if ( y >= controller[gid].ymx ) controller[gid].ymx = y;
				if ( z <= controller[gid].zmi ) controller[gid].zmi = z;
				if ( z >= controller[gid].zmx ) controller[gid].zmx = z;
			}
		}
		cout << "Slice z = " << z << " successfully checked" << endl;
	}


	stringstream log_fname;
	ofstream log_file;
	log_fname << "IOTest.ContainerTest.csv";
	log_file.open ( log_fname.str().c_str() );
	//header
	log_file << "GrainID;Cnt;XMI;XMX;YMI;YMX;ZMI;ZMX" << endl;
	for ( unsigned int gr = 1; gr < controller.size(); gr++ ) {
		if ( controller[gr].cnt > 0 ) 
			log_file << gr << ";" << controller[gr].cnt << ";" << controller[gr].xmi << ";" << controller[gr].xmx << ";" << controller[gr].ymi << ";" << controller[gr].ymx << ";" << controller[gr].zmi << ";" << controller[gr].zmx << endl;
	}
	log_file.flush();
	log_file.close();

	delete [] voxel; voxel = NULL;




/*
//write and read performance test
	//nodes write individually a Texture file with
	unsigned int IOTestSimID = atoi(argv[1]);
	unsigned int IOTestNFiles = atoi(argv[2]);
	unsigned int IOTestNGrains = atoi(argv[3]);
	//unsigned int IOTestNFaces = 14 * 0.5 * IOTestNGrains;
	double IOTestBlockLength = atof(argv[4]);
	cout << "\t\t" << tester->myRank << " participates in IO test by writing " << IOTestNFiles << " files with " <<  IOTestNGrains << " grains each, reading blocks of length " << IOTestBlockLength << " bytes" << endl;
	double wtimer = MPI_Wtime();
	double rtimer = MPI_Wtime();
	double totalrtimer = MPI_Wtime();

	//store results in process local file

	vector<IOTestResult> MyMatrixWithIOTestResults;

	for (unsigned int f = 0; f < IOTestNFiles; ++f) {
		//prepare to store test results
		IOTestResult log;
		log.rank = tester->myRank;
		log.run = f;
		log.nruns = IOTestNFiles;
		log.wresults = 0.0; //NULL;
		log.rresults = 0.0; //NULL;
		MyMatrixWithIOTestResults.push_back( log );
		//MyMatrixWithIOTestResults[MyMatrixWithIOTestResults.size()-1].wresults = NULL;
		//MyMatrixWithIOTestResults[MyMatrixWithIOTestResults.size()-1].wresults = new double[IOTestNFiles];	for ( unsigned int k = 0; k < IOTestNFiles; k++ ) MyMatrixWithIOTestResults[MyMatrixWithIOTestResults.size()-1].wresults[k] = 0.0;
		//MyMatrixWithIOTestResults[MyMatrixWithIOTestResults.size()-1].rresults = NULL;
		//MyMatrixWithIOTestResults[MyMatrixWithIOTestResults.size()-1].rresults = new double[IOTestNFiles];	for ( unsigned int k = 0; k < IOTestNFiles; k++ ) MyMatrixWithIOTestResults[MyMatrixWithIOTestResults.size()-1].rresults[k] = 0.0;


		//generate values of no interest, dummies!
		MPI_3DTextureIO* wbucket = NULL;
		wbucket = new MPI_3DTextureIO[IOTestNGrains];
		for ( unsigned int g = 0; g < IOTestNGrains; ++g ) {
			wbucket[g].volume = 1.0;
			wbucket[g].surfaceArea = 1.0;
			wbucket[g].GBEnergy = 1.0;
			wbucket[g].BulkEnergy = 1.0;
			wbucket[g].phi1 = 0.5;
			wbucket[g].Phi = 0.5;
			wbucket[g].phi2 = 0.5;
			wbucket[g].x = 0.5;
			wbucket[g].y = 0.5;
			wbucket[g].z = 0.5;
			wbucket[g].id = g;
			wbucket[g].NeighbourCount = 14;
			wbucket[g].intersectsBoundaryGrain = 0;
			wbucket[g].pad = 0;
		}

		//time measurement only for MPI I/O
		wtimer = MPI_Wtime();

		MPI_File ioWriteFileHdl;
		MPI_Status ioWriteFileStatus;
		// create C-consistent file name for MPI I/O
		stringstream msFileName;
		msFileName << "Texture.Node." << tester->myRank << ".File." << f << ".bin";
		int msFileNameLength = msFileName.str().size();
		char* wCmsFileName = new char[msFileNameLength+1];
		strcpy(wCmsFileName, msFileName.str().c_str());

		MPI_File_open(MPI_COMM_SELF, wCmsFileName, MPI_MODE_CREATE|MPI_MODE_WRONLY, MPI_INFO_NULL, &ioWriteFileHdl);
		int totalOffset = 0;
		MPI_File_seek( ioWriteFileHdl, totalOffset, MPI_SEEK_SET );

		MPI_File_write(ioWriteFileHdl, wbucket, IOTestNGrains, MPI_3DTextureIO_Type, &ioWriteFileStatus);

		MPI_File_close(&ioWriteFileHdl);

		//cout << "\t\tWriting the " << f << "-th file took \t\t\t" << (MPI_Wtime() - wtimer) << "\t\tseconds" << endl;
		MyMatrixWithIOTestResults[MyMatrixWithIOTestResults.size()-1].wresults = (MPI_Wtime() - wtimer);



		//read back the file and check for consistency
		totalrtimer = MPI_Wtime();

		MPI_3DTextureIO* rbucket = NULL;
		rbucket = new MPI_3DTextureIO[IOTestNGrains]; //uninitialized

		MPI_File ioReadFileHdl;
		MPI_Status ioReadFileStatus;

		//get file size and plan reading process...
		char* rCmsFileName = new char[msFileNameLength+1];
		strcpy(rCmsFileName, msFileName.str().c_str());
		//if ( filesize % sizeof(struct Face) != 0 ) { cout << "ERR:: Invalid file size!" << endl; delete [] fn; fn = NULL; MPI_Finalize(); return 0; }
		long long filesize[1] = {0};

		MPI_File_open(MPI_COMM_SELF, (char*)rCmsFileName, MPI_MODE_RDONLY, MPI_INFO_NULL, &ioReadFileHdl);
		MPI_File_get_size(ioReadFileHdl, filesize);
		cout << "\t\tReading file " << msFileName.str().c_str() << " with a size of " << filesize[0] << " bytes" << endl;
		MPI_File_seek(ioReadFileHdl, 0, MPI_SEEK_SET);


		unsigned int TotalBlocksToRead = (double) filesize[0] / IOTestBlockLength + 1;
		int ElementsPerBlock = IOTestBlockLength / sizeof(MPI_3DTextureIO);
		cout << "\t\tReading file in " << TotalBlocksToRead << " blocks with " << ElementsPerBlock << " elements each" << endl;
		//read back the file
		int elementsTotal = filesize[0] / sizeof(MPI_3DTextureIO);
		int elementsRead = 0;
		int elementsNow = 0;
		for ( unsigned int b = 0; b < TotalBlocksToRead; b++ ) {
			elementsNow = ElementsPerBlock;
			if ( (elementsTotal - elementsRead) < elementsNow ) elementsNow = elementsTotal - elementsRead;
			if ( elementsNow > 0 ) {
				MPI_3DTextureIO* rbuf = NULL;
				rbuf = new MPI_3DTextureIO[elementsNow];
				if ( rbuf == NULL ) { cout << "Allocation error!" << endl; }

				rtimer = MPI_Wtime();
				//MPI_File_read_at( ioReadFileHdl, elementsRead, rbuf, elementsNow, MPI_3DTextureIO_Type, &ioReadFileStatus);
				MPI_File_read( ioReadFileHdl, rbuf, elementsNow, MPI_3DTextureIO_Type, &ioReadFileStatus);

				//explicit datatransfer
				for ( int e = 0; e < elementsNow; e++ ) {
					rbucket[elementsRead+e].volume = rbuf[e].volume;
					rbucket[elementsRead+e].surfaceArea = rbuf[e].surfaceArea;
					rbucket[elementsRead+e].GBEnergy = rbuf[e].GBEnergy;
					rbucket[elementsRead+e].BulkEnergy = rbuf[e].BulkEnergy;
					rbucket[elementsRead+e].phi1 = rbuf[e].phi1;
					rbucket[elementsRead+e].Phi = rbuf[e].Phi;
					rbucket[elementsRead+e].phi2 = rbuf[e].phi2;
					rbucket[elementsRead+e].x = rbuf[e].x;
					rbucket[elementsRead+e].y = rbuf[e].y;
					rbucket[elementsRead+e].z = rbuf[e].z;
					rbucket[elementsRead+e].id = rbuf[e].id;
					rbucket[elementsRead+e].NeighbourCount = rbuf[e].NeighbourCount;
					rbucket[elementsRead+e].intersectsBoundaryGrain = rbuf[e].intersectsBoundaryGrain;
					rbucket[elementsRead+e].pad = rbuf[e].pad;
				}

				elementsRead = elementsRead + elementsNow;

//				cout << "\t\tBlockID/elementsRead/elementsNow/elementsTotal--time = " << b << "/" << elementsRead << "/" << elementsNow << "/" << elementsTotal << "\t\t\t" << (MPI_Wtime() - rtimer) << "\t\tseconds" << endl;

				delete [] rbuf; rbuf = NULL;
			}
		}
		MPI_File_close(&ioReadFileHdl);

		//cout << "\t\tReading the " << f << "-th file took completed elementsRead = " << elementsRead  << endl; //\t\t\t" << (MPI_Wtime() - rtimer) << "\t\tseconds" << endl;
		MyMatrixWithIOTestResults[MyMatrixWithIOTestResults.size()-1].rresults = (MPI_Wtime() - totalrtimer);


		//check consistency
		bool consistent = true; //prove false strategy...
		for ( unsigned int gr = 0; gr < IOTestNGrains; gr++ ) {
			//cout << "wbucketid/rbucketid\t\t" << wbucket[gr].id << "\t\t" << rbucket[gr].id << "\t\t" << rbucket[gr].volume <<  endl;
			if ( wbucket[gr].volume != rbucket[gr].volume )						{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].surfaceArea != rbucket[gr].surfaceArea )			{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].GBEnergy != rbucket[gr].GBEnergy )					{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].BulkEnergy != rbucket[gr].BulkEnergy )				{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].phi1 != rbucket[gr].phi1 )							{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].Phi != rbucket[gr].Phi )							{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].phi2 != rbucket[gr].phi2 )							{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].x != rbucket[gr].x )								{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].y != rbucket[gr].y )								{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].z != rbucket[gr].z )								{consistent = false; cout << "Data inconsistency in " << gr << ";" << rbucket[gr].id << endl;}
			if ( wbucket[gr].id != rbucket[gr].id )								{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].NeighbourCount != rbucket[gr].NeighbourCount )		{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].intersectsBoundaryGrain != rbucket[gr].intersectsBoundaryGrain )	{consistent = false; cout << "Data inconsistency in " << gr << endl;}
			if ( wbucket[gr].pad != rbucket[gr].pad )							{consistent = false; cout << "Data inconsistency in " << gr << endl;}
		}
		if ( consistent == true ) cout << "Data transfer entirely consistent!" << endl;

		delete [] wCmsFileName;
		delete [] rCmsFileName;
		delete [] wbucket;
		delete [] rbucket;
	}


	//print results


	//for ( unsigned int i = 0; i < MyMatrixWithIOTestResults.size(); i++ ) {
	//	if ( MyMatrixWithIOTestResults[i].wresults != NULL ) delete [] MyMatrixWithIOTestResults[i].wresults;
	//	if ( MyMatrixWithIOTestResults[i].rresults != NULL ) delete [] MyMatrixWithIOTestResults[i].rresults;
	//}

	stringstream log_fname;
	ofstream log_file;
	log_fname << "IOTest.SimID." << IOTestSimID << "MyRank." << tester->myRank << ".MPIIOTimings.csv";
	log_file.open ( log_fname.str().c_str() );
	//header
	log_file << "FileID;WriteTime;ReadTime\n";
	for ( unsigned int f = 0; f < MyMatrixWithIOTestResults.size(); f++ ) {
		log_file << f << ";" << MyMatrixWithIOTestResults[f].wresults << ";" << MyMatrixWithIOTestResults[f].rresults << endl;
	}
	log_file.flush();
	log_file.close();
*/


/*
	MPI_File ioReadFileHdl;
	MPI_Status ioReadFileStatus;
	//Texture file
	// create C-consistent file name for MPI I/O
	ostringstream ioReadFileNameStream;
	ioReadFileNameStream << "Texture_2.bin"; //"iotest.bin";
	int fnl = ioReadFileNameStream.str().size();
	char* fn = NULL; fn = (char*) new char[fnl+1];
	strcpy(fn, ioReadFileNameStream.str().c_str());

	//if ( filesize % sizeof(struct Face) != 0 ) { cout << "ERR:: Invalid file size!" << endl; delete [] fn; fn = NULL; MPI_Finalize(); return 0; }
	long long filesize[1] = {0};

	MPI_File_open(MPI_COMM_SELF, (char*)fn, MPI_MODE_RDONLY, MPI_INFO_NULL, &ioReadFileHdl);
	cout << "\t\tOpening " << ioReadFileNameStream.str().c_str() << " ..." << endl;

	//##read file size and 
	MPI_File_get_size(ioReadFileHdl, filesize);
	int totalOffset = 0;
	cout << "\t\tFilesize = " << filesize[0] << " Byte" << endl;
	cout << "\t\tsizeof(Texture) = " << sizeof(MPI_3DTextureIO) << " Byte" << endl;

	//###get bucket faces
	long long ngrains = filesize[0] / ( (long long) sizeof(MPI_3DTextureIO) );
	cout << "\t\tngrainsfaces = " << ngrains << endl;
	MPI_3DTextureIO* fb = NULL;
	fb = new MPI_3DTextureIO[ngrains];


	MPI_File_read_at(ioReadFileHdl, totalOffset, fb, ngrains, MPI_3DTextureIO_Type, &ioReadFileStatus);
	totalOffset += ngrains * sizeof(MPI_3DTextureIO);

	cout << endl;
	for (long long f = 0; f < ngrains; ++f ) {
		cout << fb[f].volume << "--" << fb[f].surfaceArea << "--" << fb[f].GBEnergy << "--" << fb[f].BulkEnergy;
		cout << "----" << fb[f].phi1 << ";" << fb[f].Phi << ";" << fb[f].phi2 << "----" << fb[f].x << ";" << fb[f].y << ";" << fb[f].z << "____" << fb[f].id << "--" << fb[f].NeighbourCount << "--" << fb[f].intersectsBoundaryGrain << "--" << "--pad--" << endl;
	}
	cout << endl;


	MPI_File_close(&ioReadFileHdl);
	cout << "\t\tClosing file" << endl;
*/


/*	MPI_File ioReadFileHdl;
	MPI_Status ioReadFileStatus;
	//Face file
	// create C-consistent file name for MPI I/O
	ostringstream ioReadFileNameStream;
	ioReadFileNameStream << "Faces_2.bin"; //"iotest.bin";
	int fnl = ioReadFileNameStream.str().size();
	char* fn = NULL; fn = (char*) new char[fnl+1];
	strcpy(fn, ioReadFileNameStream.str().c_str());


	//if ( filesize % sizeof(struct Face) != 0 ) { cout << "ERR:: Invalid file size!" << endl; delete [] fn; fn = NULL; MPI_Finalize(); return 0; }
	long long filesize[1] = {0};

	MPI_File_open(MPI_COMM_SELF, (char*)fn, MPI_MODE_RDONLY, MPI_INFO_NULL, &ioReadFileHdl);
	cout << "\t\tOpening " << ioReadFileNameStream.str().c_str() << " ..." << endl;

	//##read file size and 
	MPI_File_get_size(ioReadFileHdl, filesize);
	int totalOffset = 0;
	cout << "\t\tFilesize = " << filesize[0] << " Byte" << endl;
	cout << "\t\tsizeof(Face) = " << sizeof(MPI_3DFaceIO) << " Byte" << endl;

	//###get bucket faces
	long long nfaces = filesize[0] / ( (long long) sizeof(MPI_3DFaceIO) );
	cout << "\t\tnfaces = " << nfaces << endl;
	MPI_3DFaceIO* fb = NULL;
	fb = new MPI_3DFaceIO[nfaces];



	MPI_File_read_at(ioReadFileHdl, totalOffset, fb, nfaces, MPI_3DFaceIO_Type, &ioReadFileStatus);
	totalOffset += nfaces * sizeof(MPI_3DFaceIO);

	cout << endl;
	for (unsigned int f = 0; f < nfaces; ++f ) { //###nfaces
		cout << "\t\t" << fb[f].area << "--" << fb[f].gA << "--" << fb[f].gB << endl;
	}


	MPI_File_close(&ioReadFileHdl);
	cout << "\t\tClosing file" << endl;
*/

/*
	delete [] fn; fn = NULL;
	delete [] fb; fb = NULL;

	delete tester;

	MPI_Finalize();
	return 0;
}

*/



	/*cout << "TopologyTracer IO testing..." << endl;

	unsigned int* i1 = NULL;
	i1 = new unsigned int[3];
	i1[0] = 0;
	i1[1] = 11;
	i1[2] = pow(2,32) - 1;
	double* d1 = NULL;
	d1 = new double[3];
	d1[0] = +1.23456789;
	d1[1] = 0.000000000;
	d1[2] = -1.23456789;

	gr2d_props_ioP grains = NULL;
	grains = new struct gr2d_props_io[2];
	//fill grains
	grains[0].gid = 22;
	grains[0].nfaces = 5;
	grains[0].area = 22.3;
	grains[0].dareadt = -22.3;
	grains[1].gid = 12345;
	grains[1].nfaces = 33;
	grains[1].area = 110.3;
	grains[1].dareadt = +77.2;


	FILE* ioTestFile;
	ioTestFile = fopen("iotest.bin", "wb");
	size_t written = 999999;
	written = fwrite(i1, sizeof(unsigned int), 3, ioTestFile);
	cout << "\t\tFile 'iotest.bin' succesfully written to " << written << " unsigned ints, sizeof each = " << sizeof(unsigned int) << endl;
	written = 999999;
	written = fwrite(d1, sizeof(double), 3, ioTestFile);
	cout << "\t\tFile 'iotest.bin' succesfully written to " << written << " doubles, sizeof each = " << sizeof(double) << endl;
	written = 999999;
	written = fwrite(grains, sizeof(gr2d_props_io), 2, ioTestFile);
	cout << "\t\tFile 'iotest.bin' succesfully written to " << written << " grains, sizeof each = " << sizeof(gr2d_props_io) << endl;
	fclose(ioTestFile);

	delete [] i1; i1 = NULL;
	delete [] d1; d1 = NULL;
	delete [] grains; grains = NULL;

	int nranks, rank;
	MPI_Init( NULL, NULL );
	MPI_Comm_size(MPI_COMM_WORLD, &nranks);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	ioHdlP tester = (ioHdlP) new ioHdl;
	tester->myRank = rank;
	tester->nRanks = nranks;


	MPI_File ioReadFileHdl;
	MPI_Status ioReadFileStatus;


	//create MPI datatypes
	MPI_Datatype MPI_Grain2DPropsIO_Type, MPI_SimMetaDataIO_Type;

	int elementCounts[2] = {2, 2};
	MPI_Aint displacements[2] = {0, 2 * MPIIO_OFFSET_INCR_UINT};
	MPI_Datatype oldTypes[2] = {MPI_UNSIGNED, MPI_DOUBLE};
	MPI_Type_create_struct(2, elementCounts, displacements, oldTypes, &MPI_Grain2DPropsIO_Type);

	MPI_Datatype MPI_SimMetaDataIO_Type;
	int elementCounts2[2] = {4, 4};
	MPI_Aint displacements2[2] = {0, 4 * MPIIO_OFFSET_INCR_UINT};
	MPI_Datatype oldTypes2[2] = {MPI_UNSIGNED, MPI_DOUBLE};
	MPI_Type_create_struct(2, elementCounts2, displacements2, oldTypes2, &MPI_SimMetaDataIO_Type);

	MPI_Type_commit(&MPI_Grain2DPropsIO_Type);
	MPI_Type_commit(&MPI_SimMetaDataIO_Type);


	cout << "\t\tMPI IO Types committed ..." << endl;


	// create C-consistent file name for MPI I/O
	ostringstream ioReadFileNameStream;
	ioReadFileNameStream << "iotest.bin";
	int fnl = ioReadFileNameStream.str().size();
	char* fn = NULL; fn = (char*) new char[fnl+1];
	strcpy(fn, ioReadFileNameStream.str().c_str());

	MPI_File_open(MPI_COMM_SELF, (char*)fn, MPI_MODE_RDONLY, MPI_INFO_NULL, &ioReadFileHdl);
	int totalOffset = 0;
	cout << "\t\tOpening " << ioReadFileNameStream.str().c_str() << " ..." << endl;
	unsigned int ir1, ir2, ir3;
	double dr1, dr2, dr3;
	MPI_Grain2DPropsIO* rg = NULL; rg = new MPI_Grain2DPropsIO[2];
	rg[0].gid = 0; rg[0].nfaces = 0; rg[0].area = 0.0; rg[0].dareadt = 0.0;
	rg[1].gid = 0; rg[1].nfaces = 0; rg[1].area = 0.0; rg[1].dareadt = 0.0;


	MPI_File_read_at(ioReadFileHdl, totalOffset, &ir1, 1, MPI_UNSIGNED, &ioReadFileStatus);
	totalOffset += MPIIO_OFFSET_INCR_UINT;
	cout << "\t\tui1=__" << ir1 << "___" << endl;

	MPI_File_read_at(ioReadFileHdl, totalOffset, &ir2, 1, MPI_UNSIGNED, &ioReadFileStatus);
	totalOffset += MPIIO_OFFSET_INCR_UINT;
	cout << "\t\tui2=__" << ir2 << "___" << endl;

	MPI_File_read_at(ioReadFileHdl, totalOffset, &ir3, 1, MPI_UNSIGNED, &ioReadFileStatus);
	totalOffset += MPIIO_OFFSET_INCR_UINT;
	cout << "\t\tui3=__" << ir3 << "___" << endl;

	MPI_File_read_at(ioReadFileHdl, totalOffset, &dr1, 1, MPI_DOUBLE, &ioReadFileStatus);
	totalOffset += MPIIO_OFFSET_INCR_DOUBLE;
	cout << "\t\tdbl1=__" << dr1 << "___" << endl;

	MPI_File_read_at(ioReadFileHdl, totalOffset, &dr2, 1, MPI_DOUBLE, &ioReadFileStatus);
	totalOffset += MPIIO_OFFSET_INCR_DOUBLE;
	cout << "\t\tdbl2=__" << dr2 << "___" << endl;

	MPI_File_read_at(ioReadFileHdl, totalOffset, &dr3, 1, MPI_DOUBLE, &ioReadFileStatus);
	totalOffset += MPIIO_OFFSET_INCR_DOUBLE;
	cout << "\t\tdbl3=__" << dr3 << "___" << endl;

	MPI_File_read_at(ioReadFileHdl, totalOffset, rg, 2, MPI_Grain2DPropsIO_Type, &ioReadFileStatus);
	totalOffset += MPIIO_OFFSET_INCR_GRAIN2D;
	cout << "\t\tgr1=___" << rg[0].gid << ";" << rg[0].nfaces << ";" << rg[0].area << ";" << rg[0].dareadt << "__" << endl;
	cout << "\t\tgr2=___" << rg[1].gid << ";" << rg[1].nfaces << ";" << rg[1].area << ";" << rg[1].dareadt << "__" << endl;

	//MPI_File_read_at(msMyFileHdl, totalOffset, myiraw[m], tNuclei, MPI_IO_NucStateTag_Type, &msFileStatusIn);
	MPI_File_close(&ioReadFileHdl);
	cout << "\t\tClosing file" << endl;

	delete [] fn; fn = NULL;
	delete [] rg; rg = NULL;

	delete tester;

	MPI_Finalize();

	return 0;

	double m = -1.0/2.0;

	unsigned int j = floor( ((double) thecdf->size())*p + m );
	double g = ((double) thecdf->size())*p + m - j;
	//g=pn+m-j

	double gamma = 1.0;
	if ( (fabs((double) (j % 2)) <= EPSILONLIMIT) && ( fabs(g) <= EPSILONLIMIT ) ) //g = 0 and j even
		gamma = 0.0;

	if ( j >= thecdf->size() ) {
		double Q3 = thecdf->at(thecdf->size()-1);
		return Q3;
	}

	double Q3 = (1.0 - gamma) * thecdf->at(j) + gamma * thecdf->at(j+1);
	return Q3;
*/

