/*
	Copyright Markus K�hbach, 2015-2017

	TopologyTracer is an MPI-parallel datamining tool for the conducting of spatiotemporal 
	analyses of microstructural element dynamics. Its purpose is the quantification of correlations
	--- spatial and temporal --- between individual microstructural elements and their 
	higher-order neighboring elements. Specifically, its current functionalities allow to 
	study the volume evolution of individual grains over time and set their growth history into 
	relation to the evolution of the higher-order neighbors. The tool is unique insofar as it 
	allows processing these individual surveys in a parallelized manner. Thus, enabling the 
	post-processing of so far intractable large datasets.

	The source code was developed by Markus K�hbach during his PhD time with Luis A. Barrales-Mora 
	and G�nter Gottstein at the Institute of Physical Metallurgy and Metal Physics with RWTH Aachen University. 
	Being now with the Max-Planck-Institut fur Eisenforschung GmbH in Dusseldorf, I maintain the code, 
	though at disregular intervals. Nonetheless, feel free to utilize the tool, do not hesitate contacting 
	me for sharing thoughts, suggesting improvements, or reporting your experiences.
	markus.kuehbach at rwth-aachen.de and m.kuehbach at mpie.de


	The authors gratefully acknowledge the financial support from the Deutsche Forschungsgemeinschaft
	(DFG) within the Reinhart Koselleck-Project (GO 335/44-1) and computing time grants kindly provided
	by RWTH Aachen University and the FZ J�lich within the scope of the JARAHPC project JARA0076.


	This file is part of TopologyTracer.

	TopologyTracer is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TopologyTracer is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with SCORE.  If not, see <http://www.gnu.org/licenses/>.
*/


//MK::these files list deprecated functions, BE CAREFUL SOME OF THESE HAVE NOT BEEN UPDATED
//MK::there are only meant as flesh to inspire potential modifications to the code!


//bool read_contours( unsigned int gnuid );

#ifdef COMPILE_IN_IF_DESIRED
	std::vector<std::vector<point2d>*> trial;
	struct barycenter2d calc_polygon_bary( std::vector<point2d>* thecontour, unsigned int cid );
	void test( void );
	void test_polytri( void );
	void test_pqsolve( double a, double b, double c );
	void test_circular_cap( double hh, double rr );
	void test_intersection( double x1, double y1, double x2, double y2, double x3, double y3, double xc, double yc, double r );
#endif

#ifdef COMPILE_IN_IF_DESIRED
//MK::check very carefully...!

struct barycenter2d arealanaHdl::calc_polygon_bary( std::vector<point2d>* thecontour, unsigned int cid ) {
	//if ( thecontour == NULL ) return res;
	//if ( thecontour->size() == 0 ) return res;
	double A = 0.0;
	double tmp = 0.0;

	struct barycenter2d res;
	for ( unsigned int i = 0; i < thecontour->size() - 1; i++ ) { //was - 1
		tmp = (thecontour->at(i).x * thecontour->at(i+1).y) - (thecontour->at(i+1).x * thecontour->at(i).y);
		A = A + tmp;
		//res.x = res.x + ( (thecontour->at(i).x + thecontour->at(i+1).x) * tmp );
		//res.y = res.y + ( (thecontour->at(i).y + thecontour->at(i+1).y) * tmp );
		res.x += thecontour->at(i).x;
		res.y += thecontour->at(i).y;
	}
	A = 0.5*A; //MK::see Beyer 1987 because of still counter-clockwise definition
	//res.x = 1.0 / (6.0 * A) * res.x;
	//res.y = 1.0 / (6.0 * A) * res.y;
	res.x = res.x / (double) (thecontour->size()-1);
	res.y = res.y / (double) (thecontour->size()-1);
	res.gid = cid;

//cout << "Grain " << res.gid << " A/x/y = " << setprecision(16) << fabs(A) << ";" << setprecision(16) << res.x << ";" << setprecision(16) << res.y << ";" << endl;

	return res;
}


void arealanaHdl::test( void ) {
	//##MK::dummy functionality
	//add some points to test
	this->trial.push_back( NULL );
	this->trial[this->trial.size()-1] = new std::vector<point2d>;
	struct point2d ap;
	ap.x = 0.0;			ap.y = 0.0;
	this->trial[this->trial.size()-1]->push_back( ap );
	ap.x = 1.0;			ap.y = 0.0;
	this->trial[this->trial.size()-1]->push_back( ap );
	ap.x = 1.0;			ap.y = 1.0;
	this->trial[this->trial.size()-1]->push_back( ap );
	ap.x = 0.0;			ap.y = 1.0;
	this->trial[this->trial.size()-1]->push_back( ap );

	struct barycenter2d bc;
	bc = this->calc_polygon_bary( this->trial[this->trial.size()-1], 0 );
}


void arealanaHdl::test_polytri( void ) {
	//verifies whether polytri works within TopologyTracer2D3D
	cout << "\t\tTesting PolyTri functions..." << endl;

	vector<double>* thepoints = NULL;
	thepoints = new vector<double>;
	//dummy points, clock-wise definition of points
	/*thepoints->push_back(1.0);		thepoints->push_back(0.0);
	thepoints->push_back(1.0);		thepoints->push_back(1.0);
	thepoints->push_back(0.0);		thepoints->push_back(0.0);*/

	//exemplary contour
	thepoints->push_back(0.384784); thepoints->push_back(0.221374);
	thepoints->push_back(0.389313); thepoints->push_back(0.216241);
	thepoints->push_back(0.396947); thepoints->push_back(0.220516);
	thepoints->push_back(0.398282); thepoints->push_back(0.221374);
	thepoints->push_back(0.40458); thepoints->push_back(0.225419);
	thepoints->push_back(0.410589); thepoints->push_back(0.229008);
	thepoints->push_back(0.412214); thepoints->push_back(0.229978);
	thepoints->push_back(0.419847); thepoints->push_back(0.234319);
	thepoints->push_back(0.424243); thepoints->push_back(0.236641);
	thepoints->push_back(0.427481); thepoints->push_back(0.238352);
	thepoints->push_back(0.435115); thepoints->push_back(0.242167);
	thepoints->push_back(0.439491); thepoints->push_back(0.244275);
	thepoints->push_back(0.442748); thepoints->push_back(0.245843);
	thepoints->push_back(0.450382); thepoints->push_back(0.249475);
	thepoints->push_back(0.455269); thepoints->push_back(0.251908);
	thepoints->push_back(0.458015); thepoints->push_back(0.253275);
	thepoints->push_back(0.465649); thepoints->push_back(0.257389);
	thepoints->push_back(0.469157); thepoints->push_back(0.259542);
	thepoints->push_back(0.473282); thepoints->push_back(0.262076);
	thepoints->push_back(0.480916); thepoints->push_back(0.266523);
	thepoints->push_back(0.481566); thepoints->push_back(0.267176);
	thepoints->push_back(0.482688); thepoints->push_back(0.274809);
	thepoints->push_back(0.483189); thepoints->push_back(0.282443);
	thepoints->push_back(0.482745); thepoints->push_back(0.290076);
	thepoints->push_back(0.481532); thepoints->push_back(0.29771);
	thepoints->push_back(0.480916); thepoints->push_back(0.300384);
	thepoints->push_back(0.479774); thepoints->push_back(0.305344);
	thepoints->push_back(0.477629); thepoints->push_back(0.312977);
	thepoints->push_back(0.475233); thepoints->push_back(0.320611);
	thepoints->push_back(0.473282); thepoints->push_back(0.326485);
	thepoints->push_back(0.472698); thepoints->push_back(0.328244);
	thepoints->push_back(0.470024); thepoints->push_back(0.335878);
	thepoints->push_back(0.467268); thepoints->push_back(0.343511);
	thepoints->push_back(0.465649); thepoints->push_back(0.347937);
	thepoints->push_back(0.464475); thepoints->push_back(0.351145);
	thepoints->push_back(0.461693); thepoints->push_back(0.358779);
	thepoints->push_back(0.459355); thepoints->push_back(0.366412);
	thepoints->push_back(0.458015); thepoints->push_back(0.367755);
	thepoints->push_back(0.450382); thepoints->push_back(0.372074);
	thepoints->push_back(0.447481); thepoints->push_back(0.374046);
	thepoints->push_back(0.442748); thepoints->push_back(0.377262);
	thepoints->push_back(0.436194); thepoints->push_back(0.381679);
	thepoints->push_back(0.435115); thepoints->push_back(0.382406);
	thepoints->push_back(0.427481); thepoints->push_back(0.387478);
	thepoints->push_back(0.424608); thepoints->push_back(0.389313);
	thepoints->push_back(0.419847); thepoints->push_back(0.392353);
	thepoints->push_back(0.412381); thepoints->push_back(0.396947);
	thepoints->push_back(0.412214); thepoints->push_back(0.397049);
	thepoints->push_back(0.40458); thepoints->push_back(0.401568);
	thepoints->push_back(0.39927); thepoints->push_back(0.40458);
	thepoints->push_back(0.396947); thepoints->push_back(0.405898);
	thepoints->push_back(0.389313); thepoints->push_back(0.410149);
	thepoints->push_back(0.384879); thepoints->push_back(0.412214);
	thepoints->push_back(0.381679); thepoints->push_back(0.413714);
	thepoints->push_back(0.38018); thepoints->push_back(0.412214);
	thepoints->push_back(0.374046); thepoints->push_back(0.405774);
	thepoints->push_back(0.372916); thepoints->push_back(0.40458);
	thepoints->push_back(0.366412); thepoints->push_back(0.39783);
	thepoints->push_back(0.36556); thepoints->push_back(0.396947);
	thepoints->push_back(0.358779); thepoints->push_back(0.389848);
	thepoints->push_back(0.358268); thepoints->push_back(0.389313);
	thepoints->push_back(0.351145); thepoints->push_back(0.381839);
	thepoints->push_back(0.350993); thepoints->push_back(0.381679);
	thepoints->push_back(0.343736); thepoints->push_back(0.374046);
	thepoints->push_back(0.343511); thepoints->push_back(0.373808);
	thepoints->push_back(0.336505); thepoints->push_back(0.366412);
	thepoints->push_back(0.335878); thepoints->push_back(0.365747);
	thepoints->push_back(0.329312); thepoints->push_back(0.358779);
	thepoints->push_back(0.328244); thepoints->push_back(0.357638);
	thepoints->push_back(0.322167); thepoints->push_back(0.351145);
	thepoints->push_back(0.320611); thepoints->push_back(0.349473);
	thepoints->push_back(0.31506); thepoints->push_back(0.343511);
	thepoints->push_back(0.312977); thepoints->push_back(0.341261);
	thepoints->push_back(0.308001); thepoints->push_back(0.335878);
	thepoints->push_back(0.305344); thepoints->push_back(0.33297);
	thepoints->push_back(0.301002); thepoints->push_back(0.328244);
	thepoints->push_back(0.30201); thepoints->push_back(0.320611);
	thepoints->push_back(0.305344); thepoints->push_back(0.316196);
	thepoints->push_back(0.30777); thepoints->push_back(0.312977);
	thepoints->push_back(0.312977); thepoints->push_back(0.306036);
	thepoints->push_back(0.313496); thepoints->push_back(0.305344);
	thepoints->push_back(0.319323); thepoints->push_back(0.29771);
	thepoints->push_back(0.320611); thepoints->push_back(0.296054);
	thepoints->push_back(0.325258); thepoints->push_back(0.290076);
	thepoints->push_back(0.328244); thepoints->push_back(0.286325);
	thepoints->push_back(0.331335); thepoints->push_back(0.282443);
	thepoints->push_back(0.335878); thepoints->push_back(0.276869);
	thepoints->push_back(0.337556); thepoints->push_back(0.274809);
	thepoints->push_back(0.343511); thepoints->push_back(0.267693);
	thepoints->push_back(0.343944); thepoints->push_back(0.267176);
	thepoints->push_back(0.350482); thepoints->push_back(0.259542);
	thepoints->push_back(0.351145); thepoints->push_back(0.258787);
	thepoints->push_back(0.357179); thepoints->push_back(0.251908);
	thepoints->push_back(0.358779); thepoints->push_back(0.250111);
	thepoints->push_back(0.363974); thepoints->push_back(0.244275);
	thepoints->push_back(0.366412); thepoints->push_back(0.241573);
	thepoints->push_back(0.370866); thepoints->push_back(0.236641);
	thepoints->push_back(0.374046); thepoints->push_back(0.23313);
	thepoints->push_back(0.377775); thepoints->push_back(0.229008);
	thepoints->push_back(0.381679); thepoints->push_back(0.224745);
	//thepoints->push_back(0.384784); thepoints->push_back(0.221374);
	//Miessen has closed contour last point is duplicate!

	Polygon* contour = new Polygon( thepoints ); //parse constructor

	contour->triangulation();
	contour->result();

	delete contour;
	delete thepoints;
}


void arealanaHdl::test_pqsolve( double a, double b, double c )
{
	cout << "PQSOLVE a/b/c = " << setprecision(18) << a << ";" << setprecision(18) << b << ";" << setprecision(18) << c << endl;
	struct pqsolve test;
	cout << "nSolutions = " << test.nsol << "\t" << setprecision(18) << test.sol1 << ";" << setprecision(18) << test.sol2 << endl;
	test = stable_pqsolver(a,b,c);
	cout << endl << "nSolutions = " << test.nsol << "\t" << setprecision(18) << test.sol1 << ";" << setprecision(18) << test.sol2 << endl;
}


void arealanaHdl::test_circular_cap( double hh, double rr )
{
	double aa = this->circular_cap_area( hh, rr );
	cout << "Testing cap h/r = " << setprecision(18) << hh << ";" << setprecision(18) << rr << "\t" << aa << endl;
}


void arealanaHdl::test_intersection( double x1, double y1, double x2, double y2, double x3, double y3, double xc, double yc, double r )
{
#ifdef DEBUG_TRIANGLE
	cout << "Triangle = x1y1x2y2x3y3 = " << setprecision(18) << x1 << ";" << setprecision(18) << y1 << ";" << setprecision(18) << x2 << ";" << setprecision(18) << y2 << ";" << setprecision(18) << x3 << ";" << setprecision(18) << y3 << endl;
	cout << "Circle = xc/yc/r = " << setprecision(18) << xc << ";" << setprecision(18) << yc << ";" << setprecision(18) << r << endl;
#endif
	double area = this->intersection_area_triangle_circle( x1,y1,x2,y2,x3,y3,xc,yc,r);
	if ( this->intersection_area_triangle_check( area, x1,y1,x2,y2,x3,y3,xc, yc, r ) == true ) {
		cout << "Intersection = " << setprecision(18) << area << endl;
	}
	else { cout << "ERROR::Result is inconsistent!" << endl; }	
}
#endif




/*
bool arealanaHdl::read_contours( unsigned int gnuid ) {
	//the key idea of the radial growth prospensity analysis is as follows
	//one assumes that a prediction of the survival of a sub-grain can be made
	//solely based on the properties to an initial structure,i.e. the disorientation
	//an dislocation density difference to the neighbors, however, along the boundary surface
	//different neighbors are seen, therefore one has to incorporate all in a scalar value
	//one could weight for instance the product mobility * 0.5Gb^2 * (rho_neighbor - rho_me) by the
	//boundary face area or by the area of the neighbor, both approaches however are biased:
	//the first does because a very large grain with these properties may be connect over the boundary or
	//additionally then the area over which one integrates to make a prediction of the sub-grains fate varies
	//as the size of the local cluster of sub-grain + its 1-order neighbors varies...
	//the second, i.e. the vica versa argument there is a large neighbor close to the sub-grain but only 
	//with a small boundary segment
	
	//the solution is weight by the area of neighbor but considering only a spherical region about the sub-grain
	//this requires to compute the fractional area/volume of a neighbor in a circle/sphere of radius r
	//considering a circle with radius r and obvious area B = \pi r^2 located at the barycenter of the 
	//polygon of neighbors j with polygonal area A_j we shall denote 
	//chi(r) = \frac{1}{\pi r^2} \cdot \sum_{j=1}^N (A_j \cup B) * m_ij * 0.5*Gb^2 ( \rho_j - \rho_i)
	//based on the barycenter for all grains whose circle B do not touch the simulation domain boundary, we
	//construct a marked point process \mathbb{P} \in \mathbb{R}^2 with the barycenter (x_i, y_i) as the point
	//locations and chi(r)_i as the mark
	//now we have anmeasure available that allows to identify not only the how advantageous the instantaneous 
	//environment is perceived for the sub-grain to growth but in particular we are able as well to identify the spatial
	//aggregat of sub-grains with similar beneficial growth conditions
	//###location of the point as the consequence of directional/location of neighbors offering beneficial environment

	//reads in a ASCII *.gnu plot contour file with the following format <x> <y> <grain-id> ..... <ignored>
	//organizes the contour positions in an ID hash
	double timer = MPI_Wtime();

	//##MK::check old code::if ( read_gnufile( gnuid ) == false ) { cout << "ERR::Unable to locate or read gnufile" << endl; return false; }
	//if ( read_mpiio_gnu_binary_2d( gnuid ) == false ) { cout << "ERR::Unable to locate or read gnufile" << endl; return false; }

	string tname = "ReadContours" + to_string(gnuid);
	myprofiler.logev( tname, (double) (MPI_Wtime() - timer) );

	cout << Settings::GNUDataFromFilename << gnuid << ".gnu contour line file was loaded successfully in " << (double) (MPI_Wtime() - timer) << " seconds" << endl;
	return true;
}
*/


//bool read_mpiio_gnu_binary_2d( unsigned int gnufid );
/*
bool arealanaHdl::read_mpiio_gnu_binary_2d( unsigned int gnufid ) {
	double rtimer = MPI_Wtime();

	//check size if file exists by system call
	stringstream fn;
	double filesize[1] = {0.0};
	unsigned long ncontourpoints[1] = {0};
	struct stat buf;
	fn.str( std::string() );
	fn << Settings::GNUDataFromFilename << gnufid << ".gnu.bin";

	if ( stat( fn.str().c_str() , &buf ) != -1 ) {
		filesize[0] = buf.st_size;
		ncontourpoints[0] = (double) (filesize[0] / sizeof(MPI_GNUInfo)); //binary contains only complete contour points
	}
	else { cout << "ERROR::GNUFile " << fn << " unable to read!" << endl; return false; }

	//plan reading process...
	unsigned int TotalBlocksToRead = ( filesize[0] / Settings::MPIReadBlockLength) + 1;
	unsigned int ElementsPerBlock = Settings::MPIReadBlockLength / sizeof(MPI_GNUInfo);
	unsigned int elementsTotal = ncontourpoints[0];
	unsigned int elementsRead = 0;
	unsigned int elementsNow = 0;

	MPI_File ioReadFileHdl;
	MPI_Status ioReadFileStatus;
	MPI_File_open(MPI_COMM_SELF, fn.str().c_str(), MPI_MODE_RDONLY, MPI_INFO_NULL, &ioReadFileHdl);
	MPI_File_seek(ioReadFileHdl, 0, MPI_SEEK_SET);

	//cout << "\t\tReading file in " << TotalBlocksToRead << " blocks with " << ElementsPerBlock << " elements each" << endl;
	unsigned int disjointcontours = 0;
	for ( unsigned int b = 0; b < TotalBlocksToRead; b++ ) {
		elementsNow = ElementsPerBlock;
		if ( (elementsTotal - elementsRead) < elementsNow ) elementsNow = elementsTotal - elementsRead;
		if ( elementsNow > 0 ) {
			MPI_GNUInfo* rbuf = NULL;
			rbuf = (MPI_GNUInfo*) new MPI_GNUInfo[elementsNow];
			if ( rbuf == NULL ) { cout << "Allocation error in read_mpiio_gnu_binary_2d!" << endl; break; MPI_File_close(&ioReadFileHdl); return false; }

			MPI_File_read( ioReadFileHdl, rbuf, elementsNow, MPI_GNUInfo_Type, &ioReadFileStatus);

			//explicit datatransfer
			struct point2d ap;
			unsigned int ggid = 0;

			for ( unsigned int e = 0; e < elementsNow; e++ ) {
				ap.x = rbuf[e].bx;
				ap.y = rbuf[e].by;
				ggid = rbuf[e].gid;
//cout << ap.x << "\t\t" << ap.y << "\t\t" << ggid << endl;

				if ( gcontour2d[ggid] != NULL ) { //not the first time to initialize contourpoints for this grain
					gcontour2d[ggid]->push_back( ap );
					continue;
				}
				//init else
				disjointcontours++;
				std::vector<point2d>* contourpoints = NULL;
				contourpoints = new vector<point2d>;
				gcontour2d[ggid] = contourpoints;
				gcontour2d[ggid]->push_back( ap );
			}

			elementsRead = elementsRead + elementsNow;
//cout << "\t\tBlockID/elementsRead/elementsNow/elementsTotal--time = " << b << "/" << elementsRead << "/" << elementsNow << "/" << elementsTotal << "\t\t\t" << (MPI_Wtime() - rtimer) << "\t\tseconds" << endl;
			delete [] rbuf; rbuf = NULL;
		}
	} //data read
	MPI_File_close(&ioReadFileHdl);

	cout << "\t\tWorker " << this->get_Rank() << " read GNUInfo " << fn.str().c_str() << " of size " << filesize[0] << " Bytes with " << ncontourpoints[0] << " contour points on a total of " << disjointcontours << " polygon contours took " << setprecision(6) << (MPI_Wtime() - rtimer) << " seconds" << endl;

	return true;
}
*/

/*
bool topoHdl::classical_nucmodel_generic( void ) {
	//default nuc model, for instance consider as a nucleus each grain with a specific critical size
	//and specific disorientation angle over the perimeter to the matrix

	//if yes return true;
	//if no return false;
}
*/

/*
std::vector<unsigned int>* topoHdl::analyze_elimbnd_one( std::string logfn_method, unsigned int extID ) {
	//the function filters for time step extID which grains never touched the boundary, call only by one
	unsigned int ntargets = 0;
	std::vector<unsigned int>* targets = NULL;

	//collect Grains in Snapshot extID that have no boundary contact
	unsigned int starget = NOT_YET_FOUND;
	for ( unsigned int s = 0; s < this->LocalDB.size(); s++ ) {
		if ( LocalDB[s]->meta.extID == extID ) {
			starget = s;
			break;
		}
	}
	if ( starget == NOT_YET_FOUND ) { targets = NULL; return targets; }

cout << "Worker " << this->get_Rank() << " identifies targets on LocalDB " << starget << endl;

	targets = (std::vector<unsigned int>*) new std::vector<unsigned int>;

	//write the details
	stringstream log_fn;
	log_fn << "TopoTracer2D3D.SimID." << Settings::SimID << "." << logfn_method << ".GrainElimbnd.Rank." << this->myRank << ".csv";
	ofstream loglast;
	loglast.open( log_fn.str().c_str() );
	loglast << "GrainID;Area(allPropsTimeStep=" << extID << ");SEE;Phi1;PHI;Phi2;x;y;z\n";

	unsigned int ngr = 0;
	for ( unsigned int mr = 0; mr < this->LocalDB[starget]->mrg.size(); mr++ ) {
		MemRegion* themr = this->LocalDB[starget]->mrg[mr];
		for ( unsigned int g = 0; g < themr->GrainBucket.size(); g++ ) {
			if ( themr->GrainBucket[g].extGID != THE_DOMAIN_ITSELF && themr->GrainBucket[g].boundary != BOUNDARY_CONTACT ) {
				ntargets++;
				targets->push_back( themr->GrainBucket[g].extGID );
				loglast << themr->GrainBucket[g].extGID << ";" << themr->GrainBucket[g].size << ";" << themr->GrainBucket[g].see << ";" << themr->GrainBucket[g].phi1 << ";" << themr->GrainBucket[g].Phi << ";" << themr->GrainBucket[g].phi2 << ";" << themr->GrainBucket[g].x << ";" << themr->GrainBucket[g].y << ";" << themr->GrainBucket[g].z << endl;
			}
		}
	}

	loglast.flush();
	loglast.close();

	return targets;
}
*/


//double DisoriAngleToOtherGrain( double b1, double b2, double b3, unsigned int gid );
	
/*
std::vector<unsigned int>* topoHdl::analyze_elimbnd_all( std::string logfn_method )
{
	//cooperatively over all processes compiles a list of all grains in all time steps which never touched the boundary
	//the order of the list values is the same for each process
	//which do not touch the boundary, one rank distributes to all other
	//MK::size of the boundary bucket has to be 1+Settings::LargestGrainID because it is used as a hash with extGID...

	//find the max(GID) over all datasets
	unsigned int ngr = 0;
	for ( unsigned int s = 0; s < this->LocalDB.size(); s++ ) {
		for ( unsigned int mr = 0; mr < this->LocalDB[s]->mrg.size(); mr++ ) {
			unsigned int mrngr = this->LocalDB[s]->mrg[mr]->GrainBucket.size();
			for ( unsigned int g = 0; g < mrngr; ++g ) {
				if ( this->LocalDB[s]->mrg[mr]->GrainBucket[g].extGID >= ngr ) //automatically the zero grain is expelled as it has ID = 0
					ngr = this->LocalDB[s]->mrg[mr]->GrainBucket[g].extGID;
	}}}
	unsigned int worldngr = 0;
	MPI_Allreduce( &ngr, &worldngr, 1, MPI_UNSIGNED, MPI_MAX, MPI_COMM_WORLD );
	std::cout << "Worker " << myRank << " my maximum ID is " << ngr << " world maximum ID is " << worldngr << endl;

	//1+worldngr because accounting for zero grain
	//recvbuffer and sendbuf are utilized as bitflag fields which indicate BOUNDARY_CONTACT or not
	//##MK::further optimatization pack 8bits at once...
	char* recvbuf = NULL;
	char* sendbuf = NULL; //##MK::minimalistic it is fact that only MASTER needs a recvbuffer but not a sendbuf as he places the data directly in the recvbuffer
	//how we initialize a recv and sendbuf in allow all ranks to work on a recvbuf to compile the list of targets on their own while all others do the same
	//these are ID state fields
	recvbuf = (char*) new char[1+worldngr]; for (unsigned int c = 0; c < 1+worldngr; c++ ) { recvbuf[c] = DO_ANALYZE; }
	sendbuf = (char*) new char[1+worldngr]; for (unsigned int c = 0; c < 1+worldngr; c++ ) { sendbuf[c] = DO_ANALYZE; }

	//detect in local portion of dataset whether a grain at some point touches the boundary
	unsigned int nelim = 0;
	if ( myRank == MASTER ) {
		for ( unsigned int s = 0; s < this->LocalDB.size(); s++ ) {
			for ( unsigned int mr = 0; mr < this->LocalDB[s]->mrg.size(); mr++ ) {
				unsigned int mrngr = this->LocalDB[s]->mrg[mr]->GrainBucket.size();
				for ( unsigned int g = 0; g < mrngr; ++g ) {
					if ( this->LocalDB[s]->mrg[mr]->GrainBucket[g].boundary != BOUNDARY_CONTACT )
						continue;
					if ( recvbuf[this->LocalDB[s]->mrg[mr]->GrainBucket[g].extGID] != DO_NOT_ANALYZE ) nelim++; //prevent multiple counting
					recvbuf[this->LocalDB[s]->mrg[mr]->GrainBucket[g].extGID] = DO_NOT_ANALYZE; //because of BOUNDARY_CONTACT
//					if ( this->LocalDB[s]->mrg[mr]->GrainBucket[g].boundary == BOUNDARY_CONTACT ) {
//						recvbuf[this->LocalDB[s]->mrg[mr]->GrainBucket[g].extGID] = DO_NOT_ANALYZE; //because of BOUNDARY_CONTACT
//cout << "Kicking " << this->LocalDB[s]->mrg[mr]->GrainBucket[g].extGID << endl; }

				}
	}}}
	else {
		for ( unsigned int s = 0; s < this->LocalDB.size(); s++ ) {
			for ( unsigned int mr = 0; mr < this->LocalDB[s]->mrg.size(); mr++ ) {
				unsigned int mrngr = this->LocalDB[s]->mrg[mr]->GrainBucket.size();
				for ( unsigned int g = 0; g < mrngr; ++g ) {
					if ( this->LocalDB[s]->mrg[mr]->GrainBucket[g].boundary != BOUNDARY_CONTACT )
						continue;
					if ( sendbuf[this->LocalDB[s]->mrg[mr]->GrainBucket[g].extGID] != DO_NOT_ANALYZE ) nelim++; //to prevent double counting
					sendbuf[this->LocalDB[s]->mrg[mr]->GrainBucket[g].extGID] = DO_NOT_ANALYZE;
				}
		}}
	}
	//separation into master and not the master allows to use the MPI_IN_PLACE option during the MPI_Reduce process

cout << "Worker " << this->get_Rank() << " eliminated " << nelim << " grains." << endl;

	if ( nRanks > 1 ) {
		if ( myRank == MASTER ) {
			MPI_Reduce( MPI_IN_PLACE, recvbuf, 1+worldngr, MPI_CHAR, MPI_BAND, MASTER, MPI_COMM_WORLD ); 
			//BAND in combination with 0x00 for DO_NOT_ANALYZE and 0x01 for DO_ANALYZE sets all bits to 0 and therefore the entire chars in sendbuf to 0x00 if not all bits in all chars for one grain in the processes are set to 0x01
			//i.e. any process with the buffer[] entry being set to DO_NOT_ANALYZE will expell the grain
		} 
		else {
			MPI_Reduce( sendbuf, NULL, 1+worldngr, MPI_CHAR, MPI_BAND, MASTER, MPI_COMM_WORLD );
		}
		//now the MASTER knows in recvbuf which targets to consider and which not

		MPI_Barrier( MPI_COMM_WORLD ); //##MK::may be obsolete
		MPI_Bcast( recvbuf, 1+worldngr, MPI_CHAR, MASTER, MPI_COMM_WORLD );
	}
	else {
		//MASTER already has all pieces of information
	}

	//analyze which ids whom to consider
	unsigned int ntargets = 0;
	std::vector<unsigned int>* targets = NULL;
	targets = (std::vector<unsigned int>*) new std::vector<unsigned int>;

	stringstream log_fn; //write targets to file
	log_fn << "TopoTracer2D3D.SimID." << Settings::SimID << "." << logfn_method << ".GrainElimbnd.Rank." << this->myRank << ".csv";
	ofstream loglast;
	loglast.open( log_fn.str().c_str() );
	loglast << "GrainID\n";

	for ( unsigned int c = 1; c <= (1 + worldngr); c++ ) { //start at 1 to exclude THE_DOMAIN_ITSELF,i.e. the zero grain explicitly
		if ( recvbuf[c] == DO_ANALYZE ) {
			targets->push_back( c );
			loglast << c << endl;
		}
	}

	loglast.flush();
	loglast.close();

	delete [] recvbuf; recvbuf = NULL;
	delete [] sendbuf; sendbuf = NULL;

	return targets;
	//MK::DO NOT FORGET TO "delete targets" OUTSIDE THIS FUNCTION!
}
*/



/*
double topoHdl::DisoriAngleToOtherGrain( double b1, double b2, double b3, unsigned int gid )
{
	double disori = MEANDISORI_ON_ERROR;
	unsigned int luid = gid / Settings::LookupMaxGrainIDRange;
	unsigned int lu_size = this->LocalDB[lsid]->LookupTable[luid].size;
	GrainHash* thebucket = this->LocalDB[lsid]->LookupTable[luid].bucket;
	unsigned int whichmr = NOT_ASSIGNED_YET;
	unsigned int whichidx = NOT_ASSIGNED_YET;

	for ( unsigned int g = 0; g < lu_size; g++ ) { //scan most interesting candidates
		if ( thebucket[g].gid == gid ) {
			whichmr = thebucket[g].mrg_idx;
			whichidx = thebucket[g].idx;
			break;
		}
	}

	if ( whichmr == NOT_ASSIGNED_YET || whichidx == NOT_ASSIGNED_YET ) {
//cout << "ERROR detected during determination of number of faces per grain " << gid << endl;
		return MEANDISORI_ON_ERROR;
	}

	return ( this->misorientationCubic( b1, b2, b3, this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].phi1 );
}
*/

/*
double topoHdl::getMeanDisori( unsigned int gid, unsigned int lsid )
{
	//MK::the function computes the surface area-weighted (in 3D), i.e. the perimeter-weighted (2D)
	//disorientation angle the grain faces to its instantaneous environment of the NN-neighbors
	unsigned int luid = gid / Settings::LookupMaxGrainIDRange;
	unsigned int lu_size = this->LocalDB[lsid]->LookupTable[luid].size;
	GrainHash* thebucket = this->LocalDB[lsid]->LookupTable[luid].bucket;
	unsigned int whichmr = NOT_ASSIGNED_YET;
	unsigned int whichidx = NOT_ASSIGNED_YET;

	for ( unsigned int g = 0; g < lu_size; g++ ) { //scan most interesting candidates
		if ( thebucket[g].gid == gid ) {
			whichmr = thebucket[g].mrg_idx;
			whichidx = thebucket[g].idx;
			break;
		}
	}

	if ( whichmr == NOT_ASSIGNED_YET || whichidx == NOT_ASSIGNED_YET ) {
//cout << "ERROR detected during determination of number of faces per grain " << gid << endl;
		return MEANDISORI_ON_ERROR;
	}

	Grain* ag = &this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx];

	double dsum = 0.0;
	double wsum = 0.0;
	for ( unsigned int nb = 0; nb < ag->nfaces_identified; nb++ ) {
		if ( ag->neighbors[nb].extNBID != THE_DOMAIN_ITSELF ) {
			wsum = wsum + ag->neighbors[nb].size; 

			whichmr = ag->neighbors[nb].mrg_idx;
			whichidx = ag->neighbors[nb].idx;
			dsum = dsum + ( ag->neighbors[nb].size * misorientationCubic( ag->phi1, ag->Phi, ag->phi2, this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].phi1, this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].Phi, this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].phi2 ) );
		}
	}

	if ( wsum <= DBL_EPSILON ) { return MEANDISORI_ON_ERROR; }

	return dsum/wsum;
}


double topoHdl::getMeanSEE(unsigned int gid, unsigned int lsid)
{
	//MK::the function computes the surface area-weighted (in 3D), i.e. the perimeter-weighted (2D)
	//stored elastic energy difference for  the grain faces to their instantaneous environment of the NN-neighbors
	unsigned int luid = gid / Settings::LookupMaxGrainIDRange;
	unsigned int lu_size = this->LocalDB[lsid]->LookupTable[luid].size;
	GrainHash* thebucket = this->LocalDB[lsid]->LookupTable[luid].bucket;
	unsigned int whichmr = NOT_ASSIGNED_YET;
	unsigned int whichidx = NOT_ASSIGNED_YET;

	for ( unsigned int g = 0; g < lu_size; g++ ) { //scan most interesting candidates
		if ( thebucket[g].gid == gid ) {
			whichmr = thebucket[g].mrg_idx;
			whichidx = thebucket[g].idx;
			break;
		}
	}

	if ( whichmr == NOT_ASSIGNED_YET || whichidx == NOT_ASSIGNED_YET ) {
//cout << "ERROR detected during determination of number of faces per grain " << gid << endl;
		return MEANSEE_ON_ERROR;
	}

	Grain* ag = &this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx];
	double ownSEE = ag->see;

	double dsum = 0.0;
	double wsum = 0.0;
	for ( unsigned int nb = 0; nb < ag->nfaces_identified; nb++ ) {
		if ( ag->neighbors[nb].extNBID != THE_DOMAIN_ITSELF ) {
			wsum = wsum + ag->neighbors[nb].size;

			whichmr = ag->neighbors[nb].mrg_idx;
			whichidx = ag->neighbors[nb].idx;
			dsum = dsum + ( ag->neighbors[nb].size * ( this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].see - ownSEE) );
		}
	}

	if ( wsum <= DBL_EPSILON ) { return MEANSEE_ON_ERROR; }

	return dsum/wsum;
}
*/


/*
double topoHdl::getGrainVolume(unsigned int gid, unsigned int lsid)
{
	unsigned int luid = gid / Settings::LookupMaxGrainIDRange;

	//find grain with the local hashtable
	unsigned int lu_size = this->LocalDB[lsid]->LookupTable[luid].size;
	GrainHash* thebucket = this->LocalDB[lsid]->LookupTable[luid].bucket;
	unsigned int whichmr = NOT_ASSIGNED_YET;
	unsigned int whichidx = NOT_ASSIGNED_YET;

	for ( unsigned int g = 0; g < lu_size; g++ ) { //scan most interesting candidates
		if ( thebucket[g].gid == gid ) {
			whichmr = thebucket[g].mrg_idx;
			whichidx = thebucket[g].idx;
			break;
		}
	}

	if ( whichmr == NOT_ASSIGNED_YET || whichidx == NOT_ASSIGNED_YET ) {
//cout << "ERROR detected during determination of volume for grain " << gid << endl;
		return GRAINVOLUME_ON_ERROR;
	}

	double res = 0.0;
	res = this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].size;
	return res;
}
*/

/*
unsigned int topoHdl::getNumberOfFaces(unsigned int gid, unsigned int lsid)
{
	unsigned int luid = gid / Settings::LookupMaxGrainIDRange;

	//find grain with the local hashtable
	unsigned int lu_size = this->LocalDB[lsid]->LookupTable[luid].size;
	GrainHash* thebucket = this->LocalDB[lsid]->LookupTable[luid].bucket;
	unsigned int whichmr = NOT_ASSIGNED_YET;
	unsigned int whichidx = NOT_ASSIGNED_YET;

	for ( unsigned int g = 0; g < lu_size; g++ ) { //scan most interesting candidates
		if ( thebucket[g].gid == gid ) {
			whichmr = thebucket[g].mrg_idx;
			whichidx = thebucket[g].idx;
			break;
		}
	}

	if ( whichmr == NOT_ASSIGNED_YET || whichidx == NOT_ASSIGNED_YET ) {
//cout << "ERROR detected during determination of number of faces per grain " << gid << endl;
		return NFACES_ON_ERROR;
	}

	unsigned int res = 0;
	res = this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].nfaces_identified;
	return res;
}
*/


/*
double topoHdl::getHAGBFraction( unsigned int gid, unsigned int lsid )
{
	//MK::the function computes fraction of HAGB along the perimeter to the 1-th order neighbors
	unsigned int luid = gid / Settings::LookupMaxGrainIDRange;
	unsigned int lu_size = this->LocalDB[lsid]->LookupTable[luid].size;
	GrainHash* thebucket = this->LocalDB[lsid]->LookupTable[luid].bucket;
	unsigned int whichmr = NOT_ASSIGNED_YET;
	unsigned int whichidx = NOT_ASSIGNED_YET;

	for ( unsigned int g = 0; g < lu_size; g++ ) { //scan most interesting candidates
		if ( thebucket[g].gid == gid ) {
			whichmr = thebucket[g].mrg_idx;
			whichidx = thebucket[g].idx;
			break;
		}
	}

	if ( whichmr == NOT_ASSIGNED_YET || whichidx == NOT_ASSIGNED_YET ) {
//cout << "ERROR detected during determination of number of faces per grain " << gid << endl;
		return HAGBFRACTION_ON_ERROR;
	}

	Grain* ag = &(this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx]);

	double peri = 0.0;
	double perithreshold = 0.0;

	for ( unsigned int nb = 0; nb < ag->nfaces_identified; nb++ ) {
		if ( ag->neighbors[nb].extNBID != THE_DOMAIN_ITSELF ) {
			whichmr = ag->neighbors[nb].mrg_idx;
			whichidx = ag->neighbors[nb].idx;
			double disori = misorientationCubic( ag->phi1, ag->Phi, ag->phi2,  this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].phi1, this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].Phi, this->LocalDB[lsid]->mrg[whichmr]->GrainBucket[whichidx].phi2 );

			peri = peri + ag->neighbors[nb].size;

			if ( disori >= Settings::HAGBDetectionThreshold )
				perithreshold = perithreshold + ag->neighbors[nb].size;
		}
	}

	if ( peri <= DBL_EPSILON ) { return HAGBFRACTION_ON_ERROR; }

	return (perithreshold / peri);
}
*/


//filegood = initializeGrainZero();
//if ( filegood == false ) { cout << "Snapshot class from worker " << this->mytopohdl->get_Rank() << " failed to initialize grain zero!" << endl; return false; }


//bool initializeGrainZero( void );
/*bool Snapshot::initializeGrainZero( void )
{
	//grain zero is a dummy grain which enables a grain close to the boundary to share a face to the domain boundary
	return true;
}*/


/*
	bool transfer_to_database( MPI_3DGrainIO* buf );
*/

//void analyze_Kest_for_targets( void );

//double getGrainVolume( unsigned int gid, unsigned int lsid );
//unsigned int getNumberOfFaces( unsigned int gid, unsigned int lsid );
//double getHAGBFraction( unsigned int gid, unsigned int lsid );
//double getPeriWeightedMobSEE( unsigned int gid, unsigned int lsid );
//double getMeanDisori( unsigned int gid, unsigned int lsid );
//double getMeanSEE( unsigned int gid, unsigned int lsid );
//std::vector<unsigned int>* analyze_elimbnd_all( std::string logfn_method );

//topoHdl
//bool read_binary_grains( unsigned int ngr, MPI_3DGrainIO* buf, double fsize, unsigned int id );

//unsigned int mcxyz2intID ( unsigned int mcx, unsigned int mcy, unsigned int mcz, unsigned int nx, unsigned int ny );
//void ompindividually_initMemRegion( unsigned int which, unsigned int mx, unsigned int my, unsigned int mz, unsigned int nnx, unsigned int nny, unsigned int nnz);

std::vector<double>* test = new std::vector<double>;
test->push_back(1.0);
test->push_back(3.0);
test->push_back(4.0);
test->push_back(6.7);
test->push_back(8.9);
test->push_back(10.0);
double tmp = worker->quantile_asc_sorted_dbl( test, atof(pargv[3]) );
tmp = worker->quantile_asc_sorted_dbl( test, 0.8 );
tmp = worker->quantile_asc_sorted_dbl( test, 1.0 );
tmp = worker->quantile_asc_sorted_dbl( test, 0.0 );
delete test;

void spatQueryHdl::arrivaltime_quantiles( unsigned int fd )
{
	double tic = MPI_Wtime();

	//for all neighbors with measured neighbors compute arrival time distribution
	std::vector<double>* tau = NULL;
	try { tau = new vector<double>; }
	catch (std::bad_alloc &exc) {
		cerr << "ERROR::Worker " << this->get_Rank() << " allocation of tau failed!" << endl;
		return;
	}
	
	/*double* integrator = NULL;
	try { integral = new double[2*QUANT_WIDTH]; }
	catch (std::bad_alloc &exc) {
		cerr << "ERROR::Worker " << this->get_Rank() << " unable to allocate memory for the integrator!" << endl;
		if ( tau != NULL ) { delete tau; tau = NULL; }
		return;
	}*/

	#pragma omp parallel
	{

	std::vector<arrivaltime_results>* localbuffer = NULL;

	string logfname = "TopoTracer2D3D.SimID.509500.Competitiveness.FID." + std::to_string(fd) + ".csv";
	ofstream logfile;
	logfile.open( logfname.c_str(), std::ofstream::out | std::ofstream::trunc );
	if ( logfile.is_open() == false ) {
		cerr << "ERROR::Worker " << this->get_Rank() << " unable to open " << logfname.c_str() << endl;
		if ( tau != NULL ) { delete tau; tau = NULL; }
		//if ( integrator != NULL ) { delete integrator; integrator = NULL; };
		return;
	}

	logfile << "GrainID;NeighborsProbed;IntegralValue;MaxSizeObtainedEver\n"; //Quantile1;";
	//for ( unsigned int q = 1; q <= 99; q++ ) { logfile << "Quantile" << q << ";"; } logfile << endl;
	
	std::vector<sqkey>* nb = NULL;
	unsigned int ngr = 1 + Settings::LargestGrainID;
	for ( unsigned int gid = 0; gid < ngr; ++gid ) {
		nb = nbors.at(gid);
		if ( nb != NULL && process[gid] == true ) { //only for grains for which neighbors were found neighbors found
			tau->clear();
			
			double gid_speed = ARTIFICIAL_DRIVINGFORCE * chi[gid];
			if ( gid_speed > 0.0 ) {
				double nb_speed = std::numeric_limits<double>::lowest();
			
				unsigned int nc = nb->size();
				for ( unsigned int c = 1; c < nc; ++c ) { //start at one to jump over myself
					nb_speed = ARTIFICIAL_DRIVINGFORCE * chi[nb->at(c).pid];
					if ( nb_speed > 0.0 ) { //valid value
						//model 1 choose difference
						//double arrdiff1 = (nb->at(c).dist / gid_speed) - (nb->at(c).dist / nb_speed); //difference in arrival time
						
						//model 2 choose quotient
						double arrdiff2 = (nb->at(c).dist / gid_speed) / (nb->at(c).dist / nb_speed);
						//negative means gid has a growth advantage
						
						tau->push_back( arrdiff2 );
					}
					//invalid chi means most likely grain died between the previous and this timestep
				}

				if ( tau->size() > 0 ) { //at least any values found?
					std::sort( tau->begin(), tau->end() );

					//DEBUG
					/*if ( gid == 1 ) {
						for (unsigned int t = 0; t < tau->size(); t++ ) 
							cout << tau->at(t) << endl;
					}*/

					//integration trapezoidal
					/*for ( unsigned int q = QUANT_MIN; q <= QUANT_MAX; q++ ) { 
						integrator[2*(q-QUANT_MIN)+0] = quantile_asc_sorted_dbl( tau, (((double) q)/100.0) ); //qx value corresponding to CDF=q/100
						integrator[2*(q-QUANT_MIN)+1] = (double) q / 100.0; //CDF q/100
					}
					double integralval = 0.0;
					for (unsigned int q = 1+QUANT_MIN-QUANT_MIN; q <= QUANT_MAX-QUANT_MIN; q++ ) {
						double qxl = integrator[2*(q-1)+0];
						double qxr = integrator[2*q+0];
						double qyl = integrator[2*(q-1)+1];
						double qyr = integrator[2*q+1];

						integralval = integralval + 0.5*(qxr-qxl)*(qyr-qyl) + (qxr-qxl)*qyl ); //triangle on top of rectangle strip
					}*/

					//integration "Matano-Boltzmann style"
					unsigned int nt = tau->size();
					double dy = 1.0/((double) nt);
					double integralval = 0.0;
					for ( unsigned int t = 0; t < nt; ++t ) {
						integralval += dy * tau->at(t);
					}
									
					logfile << gid << ";" << tau->size() << ";" << integralval << ";" << mxsz[gid] << "\n";
					//logfile << quantile_asc_sorted_dbl( tau, (((double) 1)/100.0) ) << ";";
				//	for ( unsigned int q = 1; q <= 99; q++ ) { 
				//		logfile << quantile_asc_sorted_dbl( tau, (((double) q)/100.0) ) << ";";
				//	} logfile << endl;
				}
			}
		}

		//MK::Debug
		if ( gid % 10000 != 0 ) 
			continue;
		else
			cout << gid << endl;
	}

	if ( tau != NULL ) { delete tau; tau = NULL; }

	double toc = MPI_Wtime();
	cout << "...Worker " << this->get_Rank() << " characterize arrival time in " << (toc - tic) << " seconds" << endl;
}