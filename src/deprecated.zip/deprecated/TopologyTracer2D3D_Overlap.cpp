/*
	Copyright Markus K�hbach, 2015-2017

	TopologyTracer is an MPI-parallel datamining tool for the conducting of spatiotemporal 
	analyses of microstructural element dynamics. Its purpose is the quantification of correlations
	--- spatial and temporal --- between individual microstructural elements and their 
	higher-order neighboring elements. Specifically, its current functionalities allow to 
	study the volume evolution of individual grains over time and set their growth history into 
	relation to the evolution of the higher-order neighbors. The tool is unique insofar as it 
	allows processing these individual surveys in a parallelized manner. Thus, enabling the 
	post-processing of so far intractable large datasets.

	The source code was developed by Markus K�hbach during his PhD time with Luis A. Barrales-Mora 
	and G�nter Gottstein at the Institute of Physical Metallurgy and Metal Physics with RWTH Aachen University. 
	Being now with the Max-Planck-Institut fur Eisenforschung GmbH in Dusseldorf, I maintain the code, 
	though at disregular intervals. Nonetheless, feel free to utilize the tool, do not hesitate contacting 
	me for sharing thoughts, suggesting improvements, or reporting your experiences.
	markus.kuehbach at rwth-aachen.de and m.kuehbach at mpie.de


	The authors gratefully acknowledge the financial support from the Deutsche Forschungsgemeinschaft
	(DFG) within the Reinhart Koselleck-Project (GO 335/44-1) and computing time grants kindly provided
	by RWTH Aachen University and the FZ J�lich within the scope of the JARAHPC project JARA0076.


	This file is part of TopologyTracer.

	TopologyTracer is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TopologyTracer is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with SCORE.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>
#include <limits>
#include <iomanip>

//thirdparty
#include "thirdparty/Overlap/CircleTriangle_Overlap.h"
#include "thirdparty/Overlap/SphereTetrahedron_Overlap.hpp"
#include "thirdparty/Overlap/Eigen/Core"
#include "thirdparty/Overlap/Eigen/Geometry"


using namespace std;
using namespace Eigen;

struct circle {
	double x;
	double y;
	double r;
	circle() : x(0.0), y(0.0), r(0.0) {}
};


struct triangle
{
	double x1;		//clock-wise ordering
	double y1;
	double x2;
	double y2;
	double x3;
	double y3;
	triangle() : x1(0.0), y1(0.0), x2(0.0), y2(0.0), x3(0.0), y3(0.0) {}
};


struct rectangle {
	double ox;	//origin, i.e. xmin,ymin
	double oy;
	double dx;	//diagonal upper edge xmax, ymax, i.e. clock-wise ordering
	double dy;
	rectangle() : ox(0.0), oy(0.0), dx(0.0), dy(0.0) {}
};


class Intersection
{
public:
	Intersection(){};
	~Intersection(){};
	
	void set_circle ( double x, double y, double r ){
		cir.x = x;
		cir.y = y;
		cir.r = r;
	}
	void set_triangle( double x1, double y1, double x2, double y2, double x3, double y3 ) {
		tri.x1 = x1;
		tri.y1 = y1;
		tri.x2 = x2;
		tri.y2 = y2;
		tri.x3 = x3;
		tri.y3 = y3;
	}
	void overlap();
private:
	void calc_aabb0();			//determines AABB to the triangle and the circle
	void scale_translate();		//scales AABB such that the circle gets radius 1.0 and into the center
	void retranslate_rescale();
	
	circle cir;
	triangle tri;
	rectangle aabb0;
	double alpha;				//scaling constant
	double trslx;				//translation vector to place the unit circle in the center
	double trsly;
};
typedef class Intersection * IntersectionP;


void Intersection::overlap()
{
	calc_aabb0();
	
	//calculate uniform image scaling constant such that the circle has a radius of 1.0
	alpha = 1.0 / cir.r;
	cout << "Alpha = " << alpha << endl;
	
	scale_translate();
	
	cout << "Overlap = " << setprecision(35) << triangle_unitcircle_overlap( tri.x1, tri.y1, tri.x2, tri.y2, tri.x3, tri.y3 ) << endl;
	
	retranslate_rescale();
}


void Intersection::calc_aabb0()
{
	aabb0.ox = std::numeric_limits<double>::max();
	aabb0.oy = std::numeric_limits<double>::max();
	aabb0.dx = std::numeric_limits<double>::lowest();
	aabb0.dy = std::numeric_limits<double>::lowest();
	
	cout << aabb0.ox << "\t\t" << aabb0.oy << "\t\t" << aabb0.dx << "\t\t" << aabb0.dy << endl;
	
	if ( (cir.x - cir.r) < aabb0.ox ) 
		aabb0.ox = cir.x - cir.r;
	if ( (cir.x + cir.r) > aabb0.dx ) 
		aabb0.dx = cir.x + cir.r;
	if ( (cir.y - cir.r) < aabb0.oy ) 
		aabb0.oy = cir.y - cir.r;
	if ( (cir.y + cir.r) > aabb0.dy ) 
		aabb0.dy = cir.y + cir.r;
		
	if ( tri.x1 < aabb0.ox ) 
		aabb0.ox = tri.x1;
	if ( tri.x2 < aabb0.ox )
		aabb0.ox = tri.x2;
	if ( tri.x3 < aabb0.ox )
		aabb0.ox = tri.x3;
	
	if ( tri.x1 > aabb0.dx ) 
		aabb0.dx = tri.x1;
	if ( tri.x2 > aabb0.dx )
		aabb0.dx = tri.x2;
	if ( tri.x3 > aabb0.dx )
		aabb0.dx = tri.x3;
	
	if ( tri.y1 < aabb0.oy ) 
		aabb0.oy = tri.y1;
	if ( tri.y2 < aabb0.oy )
		aabb0.oy = tri.y2;
	if ( tri.y3 < aabb0.oy )
		aabb0.oy = tri.y3;
	
	if ( tri.y1 > aabb0.dy ) 
		aabb0.dy = tri.y1;
	if ( tri.y2 > aabb0.dy )
		aabb0.dy = tri.y2;
	if ( tri.y3 > aabb0.dy )
		aabb0.dy = tri.y3;

	cout << aabb0.ox << "\t\t" << aabb0.oy << "\t\t" << aabb0.dx << "\t\t" << aabb0.dy << endl;
}


void Intersection::scale_translate()
{
	//begin with origin at aabb0.ox, aabb0.oy, get tc as the stretch of the circle
	cout << "Cir\t\t" << cir.x << ";" << cir.y << endl;
	cout << "Tri\t\t" << tri.x1 << ";" << tri.y1 << ";" << tri.x2 << ";" << tri.y2 << ";" << tri.x3 << ";" << tri.y3 << endl;
	double td[2] = {alpha*(aabb0.dx - aabb0.ox), alpha*(aabb0.dy - aabb0.oy)};
	double tc[3] = {alpha*(cir.x - aabb0.ox), alpha*(cir.y - aabb0.oy), alpha*cir.r};
	double tt[6] = { alpha*(tri.x1 - aabb0.ox), alpha*(tri.y1 - aabb0.oy), alpha*(tri.x2 - aabb0.ox), alpha*(tri.y2 - aabb0.oy), alpha*(tri.x3 - aabb0.ox), alpha*(tri.y3 - aabb0.oy) };
	
	//now tc is the flipped translation vector to get the unit circle into the origin 0,0
	trslx = 1.0*tc[0];
	trsly = 1.0*tc[1];
	
	cir.x = aabb0.ox + trslx;
	cir.y = aabb0.oy + trsly;
	
	
	//###
	//relocate also all other objects
	tri.x1 = tt[0] +aabb0.ox; //+ trslx - aabb0.ox;
	tri.y1 = tt[1] +aabb0.oy; //+ trsly - aabb0.oy;
	tri.x2 = tt[2] +aabb0.ox; //+ trslx - aabb0.ox;
	tri.y2 = tt[3] +aabb0.oy; //+ trsly - aabb0.oy;
	tri.x3 = tt[4] +aabb0.ox; //+ trslx - aabb0.ox;
	tri.y3 = tt[5] +aabb0.oy; //+ trsly - aabb0.oy;
	
	//back-transformation simply add -trslx and -trsly and stretch by 1.0/alpha
	//uniform stretch with or without translation preserve volume ratio because all objects are scaled by alpha^2	
	
	cout << "td=" << td[0] << "\t\t" << td[1] << endl;
	cout << "tc=" << tc[0] << "\t\t" << tc[1] << "\t\t" << tc[2] << endl;
	cout << "tt=" << tt[0] << "\t\t" << tt[1] << "\t\t" << tt[2] << "\t\t" << tt[3] << "\t\t" << tt[4] << "\t\t" << tt[5] << "\t\t" << endl;
	
	cout << "Cir\t\t" << cir.x << ";" << cir.y << endl;
	cout << "Tri\t\t" << tri.x1 << ";" << tri.y1 << ";" << tri.x2 << ";" << tri.y2 << ";" << tri.x3 << ";" << tri.y3 << endl;
}


void Intersection::retranslate_rescale()
{
}

int main(int argc, char** argv)
{
	
	cout << "Circle/Triangle overlap..." << endl;
	IntersectionP iHdl = NULL;
	iHdl = new Intersection;
	
	iHdl->set_circle( 0.0, 0.0, 1.0 );
	iHdl->set_triangle( -3.0, -3.0, +3.0, -3.0, 0.0, 3.0);
	iHdl->overlap();
	delete iHdl;

	cout << "Sphere/Tetrahedron overlap..." << endl;
	vector_t v0(-1, -1, -1);
	vector_t v1( 1, -1, -1);
	vector_t v2( 1,  1, -1);
	vector_t v3(-1,  1, -1);

	vector_t v4(-1, -1,  1);
	vector_t v5( 1, -1,  1);
	vector_t v6( 1,  1,  1);
	vector_t v7(-1,  1,  1);

	vector_t origin( atof(argv[1]), atof(argv[2]), atof(argv[3]) ); //1, 0, 0 );

	Tetrahedron tet(v0, v1, v2, v3);
	//Sphere s(vector_t::Constant(1), 1.0);
	Sphere s(origin, 1.0);
	std::cout << "Overlap sphere/tetrahedron: " << overlap(s, tet) << std::endl;

	cout << "Sphere/Hexahedron overlap ..." << endl;

	Hexahedron hex(v0, v1, v2, v3, v4, v5, v6, v7);
	std::cout << "Overlap sphere/tetrahedron: " << overlap(s, hex) / ((4.0/3.0)*PI) << std::endl;

	return 0;
}